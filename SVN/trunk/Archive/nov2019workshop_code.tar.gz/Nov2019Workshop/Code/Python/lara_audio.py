
import lara_split_and_clean
import lara_config
import lara_utils
import lara_replace_chars
import lara_parse_utils

def count_recorded_files(Params):
    return { 'segments': count_recorded_segments(Params),
             'words': count_recorded_words(Params)
             }

# In general, we might have more than one segment audio directory
def make_recording_file(SplitFile, RecordingFile, NewOrFull, Params):
    if not check_new_or_full_arg(NewOrFull):
        return False
    read_and_store_ldt_metadata_files(all_segment_audio_dirs(Params), 'segments')
    InList = [ Chunk for ( PageInfo, Chunks ) in lara_split_and_clean.read_split_file(SplitFile, Params) for Chunk in Chunks ]
    OutList = make_recording_file1(InList, NewOrFull)
    write_recording_file(OutList, RecordingFile)

def count_recorded_segments(Params):
    read_and_store_ldt_metadata_files(all_segment_audio_dirs(Params), 'segments')
    InList = [ Chunk for ( PageInfo, Chunks ) in lara_split_and_clean.read_split_file(Params.split_file, Params) for Chunk in Chunks ]
    OutList = make_recording_file1(InList, 'full')
    return count_recorded_and_missing_lines(OutList)

def make_word_recording_file(SplitFile, RecordingFile, NewOrFull, Params):
    if not check_new_or_full_arg(NewOrFull):
        return False
    read_and_store_ldt_metadata_files(all_word_audio_dirs(Params), 'word')
    Words = get_words_from_page_oriented_split_list(lara_split_and_clean.read_split_file(SplitFile, Params))
    OutList = make_word_recording_file1(Words, NewOrFull)
    write_recording_file(OutList, RecordingFile)

def count_recorded_words(Params):
    read_and_store_ldt_metadata_files(all_word_audio_dirs(Params), 'word')
    Words = get_words_from_page_oriented_split_list(lara_split_and_clean.read_split_file(Params.split_file, Params))
    OutList = make_word_recording_file1(Words, 'full')
    return count_recorded_and_missing_lines(OutList)

def check_new_or_full_arg(NewOrFull):
    if not NewOrFull in ( 'new_only', 'full' ):
        printf(f'*** Error: illegal argument "NewOrFull" when trying to make recording file, must be "new_only" or "full"')
        return False
    else:
        return True

def all_segment_audio_dirs(Params):
    OwnSegmentDirList = [] if Params.segment_audio_directory == '' else [ Params.segment_audio_directory ]
    return OwnSegmentDirList 

def all_word_audio_dirs(Params):
    OwnDirList = [] if Params.word_audio_directory == '' else [ Params.word_audio_directory ]
    return OwnDirList 

def process_recorded_audio_directory(Params, SplitList, WordsOrSegments):
    AudioDirs = all_segment_audio_dirs(Params) if WordsOrSegments == 'segments' else all_word_audio_dirs(Params)
    WordsDict = { Word: True for Word in get_words_from_page_oriented_split_list(SplitList) }
    read_and_store_ldt_metadata_files(AudioDirs, WordsOrSegments)
    MultimediaDir = lara_utils.get_multimedia_dir_from_params(Params)
    for AudioDir in AudioDirs:
        if lara_utils.directory_exists(AudioDir):
            copy_audio_files(['wav', 'mp3'], AudioDir, MultimediaDir, WordsOrSegments, WordsDict, Params)
        else:
            lara_utils.print_and_flush(f'*** Warning: audio directory {AudioDir} not found')
            
def copy_audio_files(Extensions, AudioDir, MultimediaDir, WordsOrSegments, WordsDict, Params):
    for Extension in Extensions:
        copy_audio_files_with_extension(Extension, AudioDir, MultimediaDir, WordsOrSegments, WordsDict, Params)

##def copy_audio_files_with_extension(Extension, AudioDir, MultimediaDir, WordsDict, Params):
##    Files = lara_utils.files_with_given_extension_in_directory(AudioDir, Extension)
##    if len(Files) > 0:
##        Command = f'cp {AudioDir}/*.{Extension} {MultimediaDir}'
##        lara_utils.print_and_flush(f'--- Copying {len(Files)} audio files of type "{Extension}" from {AudioDir}... ')
##        Status = lara_utils.execute_lara_os_call(Command, Params)
##        if Status == 0:
##            lara_utils.print_and_flush('--- done')
##        else:
##            lara_utils.print_and_flush(f'*** Warning: Copying of whole directory failed, trying to copy files one at a time')
##            lara_utils.copy_directory_one_file_at_a_time(AudioDir, MultimediaDir, [Extension])

def copy_audio_files_with_extension(Extension, AudioDir, MultimediaDir, WordsOrSegments, WordsDict, Params):
    Files = relevant_files_in_audio_directory(AudioDir, WordsOrSegments, WordsDict, Extension)
    if len(Files) > 0:
        lara_utils.copy_named_files_between_directories(Files, AudioDir, MultimediaDir)

def relevant_files_in_audio_directory(AudioDir, WordsOrSegments, WordsDict, Extension):
    AllFiles = lara_utils.files_with_given_extension_in_directory(AudioDir, Extension)
    # We want to include all the segment audio files - some of them may be embedded audio
    if WordsOrSegments == 'segments':
        return AllFiles
    # But we only take the word audio files for words that occur in the text
    else:
        return [ File for File in AllFiles if File in ldt_words_for_files and ldt_words_for_files[File] in WordsDict ]

# --------------------------------------

def make_recording_file1(Chunks, NewOrFull):
    if NewOrFull == 'full':
        return [ recording_file_line_for_chunk(Chunk) for Chunk in Chunks if not null_chunk(Chunk) ]
    else:
        return [ recording_file_line_for_chunk(Chunk) for Chunk in Chunks
                 if not audio_for_chunk_exists(Chunk) and not null_chunk(Chunk) ]

def null_chunk(Chunk):
    return Chunk[1].isspace() or Chunk[1] == ''
             
def write_recording_file(List, File):
    lara_utils.write_unicode_text_file('\n'.join(List), File)
    lara_utils.print_and_flush(f'--- Written recording file ({len(List)} lines) {File}')

def get_words_from_page_oriented_split_list(SplitList):
    AllChunks = [ Chunk for ( PageInfo, Chunks ) in SplitList for Chunk in Chunks ]
    return get_words_from_split_file_contents(AllChunks)

def get_words_from_split_file_contents(ChunksList):
    Words = [ make_word_canonical_for_word_recording(Word) for Chunk in ChunksList for ( Word, Tag ) in Chunk[2] if
              not lara_parse_utils.is_punctuation_string(Word) ]
    return sorted(lara_utils.remove_duplicates(Words))

def make_word_canonical_for_word_recording(Word):
    ( WordMinusHTML, Trace ) = lara_parse_utils.remove_html_annotations_from_string(Word)
    if len(Trace) == 0:
        LowercaseWord = WordMinusHTML.lower()
        LowercaseWord1 = LowercaseWord.replace('\n', '')
        LowercaseWord2 = lara_replace_chars.restore_reserved_chars(LowercaseWord1)
        return lara_parse_utils.remove_initial_and_final_spaces(lara_parse_utils.remove_weird_characters(LowercaseWord2))
    else:
        lara_utils.print_and_flush('\n'.join(Trace))
        return False   

def make_segment_canonical_for_recording(SegmentOrWord):
    return lara_replace_chars.restore_reserved_chars(lara_parse_utils.remove_weird_characters(SegmentOrWord))

def internalise_text_from_audio_metadata_file(SegmentOrWord):
    return lara_replace_chars.replace_reserved_chars(SegmentOrWord)

def make_word_recording_file1(Words, NewOrFull):
    if NewOrFull == 'full':
        return [ recording_file_line_for_word(Word) for Word in Words ]
    else:
        return [ recording_file_line_for_word(Word) for Word in Words if not audio_for_word_exists(Word) ]

def audio_for_chunk_exists(Chunk):
    global ldt_files_for_segments
    return True if Chunk[1] in ldt_files_for_segments else False

def ldt_wavfile_for_chunk(Chunk):
    global ldt_files_for_segments
    Text = Chunk[1]
    return cached_ldt_file_to_base_mp3(ldt_files_for_segments[Text]) if Text in ldt_files_for_segments else 'MISSING_FILE'

def audio_for_word_exists(Word):
    global ldt_files_for_words
    return True if Word in ldt_files_for_words else False

def ldt_wavfile_for_word(Word):
    global ldt_files_for_words
    return cached_ldt_file_to_base_mp3(ldt_files_for_words[Word]) if Word in ldt_files_for_words else 'MISSING_FILE'

def cached_ldt_file_to_base_mp3(File):
    return f"help/{lara_utils.change_extension(File.split('/')[-1], 'wav')}"

## AudioOutput help any_speaker MISSING_FILE Once upon a time there were four little rabbits.# (no trace info)
## AudioOutput help any_speaker help/190284_190926_163736873.wav rabbit# (no trace info)
def recording_file_line_for_chunk(Chunk):
    Text = make_segment_canonical_for_recording(Chunk[1])
    FileOrMissing = ldt_wavfile_for_chunk(Chunk) 
    return f'AudioOutput help any_speaker {FileOrMissing} {Text}# (no trace info)'
 
def recording_file_line_for_word(Word):
    FileOrMissing = ldt_wavfile_for_word(Word) 
    return f'AudioOutput help any_speaker {FileOrMissing} {Word}# (no trace info)'

def count_recorded_and_missing_lines(List):
    NMissing = len([ Line for Line in List if Line.find('MISSING_FILE') > 0 ])
    NRecorded = len(List) - NMissing
    return { 'recorded': NRecorded, 'not_recorded': NMissing }

# -----------------------------------------------

ldt_files_for_segments = {}
ldt_files_for_words = {}
ldt_words_for_files = {}
ldt_urls_for_segment_and_corpus = {}
ldt_urls_for_words = {}

def init_stored_downloaded_audio_metadata():
    ldt_urls_for_segment_and_corpus = {}
    ldt_urls_for_words = {}

def no_audio(SegmentsOrWords, Params):
    CorpusIdTag = lara_utils.get_corpus_id_from_params(Params)
    return no_audio1(CorpusIdTag, SegmentsOrWords)

def no_audio1(CorpusIdTag, SegmentsOrWords):
    global ldt_files_for_segments
    global ldt_files_for_words
    global ldt_urls_for_segment_and_corpus
    global ldt_urls_for_words
    if CorpusIdTag == 'local_files' and SegmentsOrWords == 'segments':
        if ldt_files_for_segments == {}:
            return True
        else:
            return False
    elif CorpusIdTag == 'local_files' and SegmentsOrWords == 'words':
        if ldt_files_for_words == {}:
            return True
        else:
            return False
    elif SegmentsOrWords == 'segments':
        if not CorpusIdTag in ldt_urls_for_segment_and_corpus:
            return True
        else:
            return False
    elif SegmentsOrWords == 'words':
        if ldt_urls_for_words == {}:
            return True
        else:
            return False
    else:
        return True

def ldt_file_for_segment(Segment):
    global ldt_files_for_segments
    if Segment in ldt_files_for_segments:
        return ldt_files_for_segments[Segment]
    else:
        Error = f'*** Warning: No audio file stored for segment "{Segment}"'
        lara_utils.print_and_flush_warning(Error)
        return False

def ldt_file_for_word(Word):
    global ldt_files_for_words
    if Word in ldt_files_for_words:
        return ldt_files_for_words[Word]
    else:
        Error = f'*** Warning: No audio file stored for word "{Word}"'
        lara_utils.print_and_flush_warning(Error)
        return False

# -----------------------------------------------

def read_and_store_ldt_metadata_files(LDTDirs, WordsOrSegments):
    global ldt_files_for_segments
    global ldt_files_for_words
    if WordsOrSegments == 'segments':
        ldt_files_for_segments = {}
    else:
        ldt_files_for_words = {}
        ldt_words_for_files = {}
    for LDTDir in LDTDirs:
        List = read_ldt_metadata_file(LDTDir)
        store_ldt_metadata_file1(List, WordsOrSegments)

def read_ldt_metadata_file(LDTDir):
    LDTMetadataFile = ldt_metadata_file(LDTDir)
    if lara_utils.file_exists(LDTMetadataFile):
        return (lara_utils.read_lara_text_file(LDTMetadataFile)).split('\n')
    else:
        lara_utils.print_and_flush(f'*** Warning: LDT metadata file {LDTMetadataFile} not found.')
        return []
                  
def ldt_metadata_file(LDTDir):
    return f'{LDTDir}/metadata_help.txt'

def store_ldt_metadata_file1(List, WordsOrSegments):
    for Line in List:
        store_ldt_metadata_file_line(Line, WordsOrSegments)

def store_ldt_metadata_file_line(Line, WordsOrSegments):
    global ldt_files_for_segments
    global ldt_files_for_words
    Result = lara_parse_utils.parse_ldt_metadata_file_line(Line)
    if Result:
        ( File, SegmentOrWord ) = Result
        File1 = f'multimedia/{File}'
        SegmentOrWord1 = internalise_text_from_audio_metadata_file(SegmentOrWord)
        if WordsOrSegments == 'segments':
            #ldt_files_for_segments[make_segment_canonical_for_recording(SegmentOrWord)] = File1
            ldt_files_for_segments[SegmentOrWord1] = File1
        else:
            ldt_files_for_words[SegmentOrWord1] = File1
            ldt_words_for_files[File] = SegmentOrWord1

def store_downloaded_audio_metadata(WordsOrSegments, Voice, CorpusId, URL, File):
    global ldt_urls_for_segment_and_corpus
    if lara_utils.file_exists(File):
        List = lara_utils.read_lara_text_file(File).split('\n')
        lara_utils.print_and_flush(f'--- Read LDT metadata file ({len(List)} lines) {File}')
    else:
        lara_utils.print_and_flush(f'*** Warning: LDT metadata file {File} not found.')
        List = []
    if WordsOrSegments == 'segments':
        if CorpusId in ldt_urls_for_segment_and_corpus:
            SubDict = ldt_urls_for_segment_and_corpus[CorpusId]
        else:
            SubDict = {}
        SubDict['*base_url*'] = URL
        ldt_urls_for_segment_and_corpus[CorpusId] = SubDict
    for Line in List:
        store_downloaded_audio_metadata_line(Line, WordsOrSegments, Voice, CorpusId, URL)

## We will in general have multiple corpora, and we could also have multiple language resources
## We will also have multiple voices
def store_downloaded_audio_metadata_line(Line, WordsOrSegments, Voice, CorpusId, URL):
    global ldt_urls_for_segment_and_corpus
    global ldt_urls_for_words
    if Line.isspace() or Line == '':
        return True
    Result = lara_parse_utils.parse_ldt_metadata_file_line(Line)
    if Result:
        ( File, SegmentOrWord ) = Result
        FullURL = f'{URL}/{File}'
        #CanonicalSegmentOrWord = make_segment_canonical_for_recording(SegmentOrWord)
        CanonicalSegmentOrWord = internalise_text_from_audio_metadata_file(SegmentOrWord)
        if WordsOrSegments == 'segments':
            if CorpusId in ldt_urls_for_segment_and_corpus:
                SubDict = ldt_urls_for_segment_and_corpus[CorpusId]
            else:
                SubDict = {}
            if CanonicalSegmentOrWord in SubDict:
                SubSubDict = SubDict[CanonicalSegmentOrWord]
            else:
                SubSubDict = {}
            SubSubDict[Voice] = FullURL
            SubDict[CanonicalSegmentOrWord] = SubSubDict
            ldt_urls_for_segment_and_corpus[CorpusId] = SubDict
        else:
            if CorpusId in ldt_urls_for_words:
                SubDict = ldt_urls_for_words[CorpusId]
            else:
                SubDict = {}
            if CanonicalSegmentOrWord in SubDict:
                SubSubDict = SubDict[CanonicalSegmentOrWord]
            else:
                SubSubDict = {}
            SubSubDict[Voice] = FullURL
            SubDict[CanonicalSegmentOrWord] = SubSubDict
            ldt_urls_for_words[CorpusId] = SubDict

def audio_url_for_corpus_id(CorpusId):
    global ldt_urls_for_segment_and_corpus
    if CorpusId in ldt_urls_for_segment_and_corpus and '*base_url*' in ldt_urls_for_segment_and_corpus[CorpusId]:
        return ldt_urls_for_segment_and_corpus[CorpusId]['*base_url*']
    else:
        lara_utils.print_and_flush_warning(f'*** Warning: base audio URL not defined for "{CorpusId}"')
        return ''

def audio_url_for_language_id(LanguageId):
    global ldt_urls_for_words
    if LanguageId in ldt_urls_for_words and '*base_url*' in ldt_urls_for_words[LanguageId]:
        return ldt_urls_for_words[LanguageId]['*base_url*']
    else:
        lara_utils.print_and_flush_warning(f'*** Warning: base audio URL not defined for "{LanguageId}"')
        return ''

def ldt_url_for_segment_and_corpus(Segment, CorpusId, Params):
    global ldt_urls_for_segment_and_corpus
    if CorpusId in ldt_urls_for_segment_and_corpus:
        SubDict = ldt_urls_for_segment_and_corpus[CorpusId]
        if Segment in SubDict:
            return best_audio_url(SubDict[Segment], Params)
        else:
            Error = f'*** Warning: No audio URL stored for {Segment} in {CorpusId}'
            lara_utils.print_and_flush_warning(Error)
            return Error
    else:
        Error = f'*** Warning: No audio data for {CorpusId}'
        lara_utils.print_and_flush_warning(Error)
        return Error

def ldt_url_for_word(Word, LanguageId, Params):
    global ldt_urls_for_words
    if LanguageId in ldt_urls_for_words:
        SubDict = ldt_urls_for_words[LanguageId]
        if Word in SubDict:
            return best_audio_url(SubDict[Word], Params)
        else:
            Error = f'*** Warning: No audio URL stored for {Word} in {LanguageId}'
            lara_utils.print_and_flush_warning(Error)
            return Error
    else:
        Error = f'*** Warning: No audio data for {LanguageId}'
        lara_utils.print_and_flush_warning(Error)
        return Error

# We should have a dict of URLs indexed by voice. Use the one for the preferred voice
# if it's there, otherwise just pick one.
def best_audio_url(SubSubDict, Params):
    if not isinstance(SubSubDict, dict) or SubSubDict == {}:
        return '*** Warning: No audio data'
    Key = Params.preferred_voice if Params.preferred_voice in SubSubDict else next(iter(SubSubDict))
    return SubSubDict[Key]
        
# -----------------------------------------------

def add_audio_mouseover_to_word(ColouredWord, Word, Params):
    if no_audio('words', Params):
        return ColouredWord
    else:
        AudioURL = get_audio_url_for_chunk_or_word(Word, 'words', Params)
        if AudioURL != '*no_audio_url*':
           return f'<span onmouseover="playSound(\'{AudioURL}\');">{ColouredWord}</span>'
        else:
            lara_utils.print_and_flush(f'*** Warning: unable to find audio for "{Word}"')

def get_audio_url_for_word(Word, Params):
    AudioURL = get_audio_url_for_chunk_or_word(Word, 'words', Params)
    if AudioURL != '*no_audio_url*':
        return AudioURL
    else:
        return False

def get_audio_url_for_chunk_or_word(MinimallyCleaned, WordsOrSegments, Params):
    if no_audio(WordsOrSegments, Params):
        return '*no_audio_url*',
    else:
        CorpusId = lara_utils.get_corpus_id_from_params(Params)
        if CorpusId == 'local_files' and WordsOrSegments == 'segments':
            return ldt_file_for_segment(MinimallyCleaned)
        elif CorpusId == 'local_files' and WordsOrSegments == 'words':
            MinimallyCleaned1 = make_word_canonical_for_word_recording(MinimallyCleaned)
            return ldt_file_for_word(MinimallyCleaned1)
        elif WordsOrSegments == 'segments':
            return ldt_url_for_segment_and_corpus(MinimallyCleaned, CorpusId, Params)
        elif WordsOrSegments == 'words':
            MinimallyCleaned1 = make_word_canonical_for_word_recording(MinimallyCleaned)
            LanguageId = lara_utils.get_language_id_from_params(Params)
            return ldt_url_for_word(MinimallyCleaned1, LanguageId, Params)

# -----------------------------------------------

def process_audio_tags_in_string(RawStr, Params):
    if lara_utils.no_corpus_id_in_params(Params):
        return ( RawStr, [] )
    if lara_utils.get_corpus_id_from_params(Params) == 'local_files' and Params.segment_audio_directory == '':
        return ( RawStr, [] )
    if Params.segment_audio_directory != '':
        Dir = lara_utils.absolute_file_name(Params.segment_audio_directory)
    else:
        Dir = '*no_dir*'
    return process_audio_tags_in_string1(RawStr, Params, Dir)

def audio_files_referenced_in_string(Str):
    audio_tag_start = '<audio'
    audio_tag_end = '/>'
    ( Index, N, audioFiles ) = ( 0, len(Str), [] )
    while True:
        if Index >= N:
            return audioFiles
        if lara_parse_utils.substring_found_at_index(Str, Index, audio_tag_start) > 0:
            EndOfTagIndex = Str.find(audio_tag_end, Index+len(audio_tag_start))
            if EndOfTagIndex > 0:
                ( Components, Errors ) = parse_audio_tag(Str[Index+len(audio_tag_start):EndOfTagIndex])
                Index = EndOfTagIndex + len(audio_tag_end)
                if 'src' in Components:
                    audioFiles += [ Components['src'] ]
            else:
                # We have an open audio tag, but try to carry on anyway
                return audioFiles
        else:
            Index += 1

def process_audio_tags_in_string1(Str, Params, Dir):
    audio_tag_start = '<audio'
    audio_tag_end = '/>'
    ( Index, N, OutStr, AllErrors ) = ( 0, len(Str), '', [] )
    while True:
        if Index >= N:
            return ( OutStr, AllErrors )
        if lara_parse_utils.substring_found_at_index(Str, Index, audio_tag_start) > 0:
            EndOfTagIndex = Str.find(audio_tag_end, Index+len(audio_tag_start))
            if EndOfTagIndex > 0:
                ( TagText1, Errors ) = process_audio_tag(Str[Index+len(audio_tag_start):EndOfTagIndex], Params, Dir)
                OutStr += TagText1
                Index = EndOfTagIndex + len(audio_tag_end)
                AllErrors += Errors
            else:
                return ( OutStr, [f'*** Error: open audio tag: "{Str[Index:Index+100]}"'] )
        else:
            OutStr += Str[Index]
            Index += 1
                         
def process_audio_tag(TagText, Params, Dir):
    ( Components, Errors ) = parse_audio_tag(TagText)
    if len(Errors) > 0:
        return ( '', Errors )
    else:
        if 'src' in Components:
            ( URL, Errors1 ) = url_for_audio_file_in_tag(Components['src'], Params, Dir)
            ( AudioType, Errors2 ) = get_audio_type_for_url(URL)
            audio_id = '' if not 'id' in Components else f'id="{Components["id"]}"'
            return ( f'<audio {audio_id} controls="true"><source src="{URL}" type="audio/{AudioType}">Your browser does not support the HTML5 audio element.</audio>',
                     Errors1 + Errors2 )
        else:
            return ( '', [ '*** Error: malformed audio tag "<audio {TagText}/>"' ] )

def url_for_audio_file_in_tag(Src, Params, Dir):
    CorpusId = lara_utils.get_corpus_id_from_params(Params)
    if CorpusId == 'local_files':
        URL = f'multimedia/{Src}'
        return ( URL, check_if_audio_file_exists(Dir, Src) )
    else:
        CorpusAudioURL = audio_url_for_corpus_id(CorpusId)
        if CorpusAudioURL:
            URL = f'{CorpusAudioURL}/{Src}'
            return ( URL, [] )
        # If we are doing distributed LARA and we can't find the audio, create a bad reference
	# to the local multimedia directory and don't interrupt compilation.
        else:
            lara_utils.print_and_flush(f'*** Warning: missing audio file "{Src}"')
            return ( f'multimedia/{Src}', [] )
                        
def check_if_audio_file_exists(Dir, Src):
    File = f'{Dir}/{Src}'
    if lara_utils.file_exists(File):
        return []
    else:
        return [f'*** Warning: missing audio file "{Src}"']

def get_audio_type_for_url(AudioURL):
    Components = AudioURL.split('.')
    if len(Components) > 1:
        AudioType = Components[-1].lower()
        if known_audio_type_for_audio_tag(AudioType):
            return ( AudioType, [] )
        else:
            return ( AudioType, [ f'*** Error: bad audio URL "{AudioURL}".' ] )
    else:
        return ( False, [ f'*** Error: bad audio URL "{AudioURL}".' ] )

def known_audio_type_for_audio_tag(Type):
    return Type in ['mp3', 'wav']

def parse_audio_tag(Str):
    ( Index, N, OutDict ) = ( 0, len(Str), {} )
    while True:
        Index = lara_parse_utils.skip_spaces(Str, Index)
        if Index >= N:
            return ( OutDict, [] )
        else:
            ( Key, Value, Index1, Errors ) = parse_audio_tag_component(Str, Index)
            if len(Errors) > 0:
                return ( OutDict, Errors )
            elif Key:
                OutDict[Key] = Value
                Index = Index1
            elif lara_parse_utils.skip_spaces(Str, Index1) >= N:
                return ( OutDict, [] )
            else:
                return ( OutDict, [ f'*** Error: unknown text in audio tag: "{Str[Index:]}"' ] )
                
def parse_audio_tag_component(Str, Index):
    for Key in [ 'src', 'id' ]:
        if lara_parse_utils.substring_found_at_index(Str, Index, Key + '="'):
            StartOfValueIndex = Index + len(Key) + 2
            EndOfValueIndex = Str.find('"', StartOfValueIndex)
            if EndOfValueIndex >= StartOfValueIndex:
                Value = Str[StartOfValueIndex:EndOfValueIndex]
                return ( Key, Value, EndOfValueIndex + 1, [] )
            else:
                return ( False, False, False, ['*** Error: malformed audio tag "<audio {Str}/>"' ] )
    # We didn't find any key/value pair
    return ( False, False, False, [] )

# -----------------------------------------------

def convert_lara_audio_directory_to_mp3_format(Dir, ConfigFile):
    if not Dir or Dir == '':
        lara_utils.print_and_flush(f'*** Error: empty directory not allowed')
        return False
    if not lara_utils.directory_exists(Dir):
        lara_utils.print_and_flush(f'*** Error: unable to find directory {Dir}')
        return False
    Params = lara_config.read_lara_local_config_file(ConfigFile)
    if not Params:
        lara_utils.print_and_flush(f'*** Error: unable to find config file {ConfigFile}')
    Dir1 = converted_mp3_dir_for_dir(Dir)
    lara_utils.create_directory_deleting_old_if_necessary(Dir1)
    Files = lara_utils.directory_files(Dir)
    ( AbsDir, AbsDir1 ) = ( lara_utils.absolute_file_name(Dir), lara_utils.absolute_file_name(Dir1) )
    NumFilesSuccessfullyConverted = convert_lara_audio_directory_to_mp3_format1(Files, AbsDir, AbsDir1, Params)
    lara_utils.print_and_flush(f'--- Sucessfully converted {NumFilesSuccessfullyConverted} files to mp3 format or meta file')
    lara_utils.print_and_flush(f'--- Source directory: {AbsDir}')
    lara_utils.print_and_flush(f'--- Target directory: {AbsDir1}')

def converted_mp3_dir_for_dir(Dir):
    return f'{Dir}_mp3'

def convert_lara_audio_directory_to_mp3_format1(Files, Dir, Dir1, Params):
    I = 0
    NumFilesSuccessfullyConverted = 0
    for File in Files:
        if convert_lara_audio_directory_file_to_mp3(File, Dir, Dir1, Params):
            NumFilesSuccessfullyConverted += 1
        I += 1
        lara_utils.print_and_flush_no_newline('.')
        if I%100 == 0:
            lara_utils.print_and_flush_no_newline(f' ({I})')
    return NumFilesSuccessfullyConverted

def convert_lara_audio_directory_file_to_mp3(File, Dir, Dir1, Params):
    ( BaseFile, OldExtension ) = split_pathname_into_base_file_and_extension(File)
    FullFile = f'{Dir}/{File}'
    if OldExtension.lower() == 'wav':
        FullFileTo = f'{Dir1}/{BaseFile}.mp3'
        Command = f'ffmpeg -i {FullFile} -b:a 50k {FullFileTo}'
        Result = execute_ffmpeg_command(Command, FullFileTo, Params)
        if Result:
            return True
        lara_utils.print_and_flush(f'\n*** Error: unable to convert {FullFile}')
        lara_utils.print_and_flush(f'*** with command {Command}')
    elif OldExtension.lower() == 'txt':
        FullFileTo = f'{Dir1}/{File}'
        convert_lara_audio_metadata_file(FullFile, FullFileTo)
        return True
    else:
        lara_utils.print_and_flush(f'\n--- skipping {File} (nothing to convert)')
    return False


def execute_ffmpeg_command(Command, OutFile, Params):
    lara_utils.delete_file_if_it_exists(OutFile)
    Status = lara_utils.execute_lara_os_call(Command, Params)
    if Status == 0:
        return True
    else:
        return False

def convert_lara_audio_metadata_file(File, File1):
    Lines = lara_utils.read_unicode_text_file_to_lines(File)
    Lines1 = [ convert_lara_audio_metadata_file_line(Line) for Line in Lines ]
    lara_utils.write_unicode_text_file(''.join(Lines1), File1)
    lara_utils.print_and_flush(f'\n--- Converted metadata file {File} to {File1}')

def convert_lara_audio_metadata_file_line(Line):
    return Line.replace('.wav ', '.mp3 ')

def split_pathname_into_base_file_and_extension(File):
    Components = File.split('.')
    if len(Components) == 1:
        return ( File, '')
    else:
        return ( '.'.join(Components[:-1]), Components[-1] )
    
# -----------------------------------------------

# Create a copy of an audio dir where the files have mnemonic names
def convert_audio_dir_to_mnemonic_audio_dir(Dir, Dir1):
    if not lara_utils.directory_exists(Dir):
        lara_utils.print_and_flush(f'*** Error: unable to find {Dir}')
        return False
    lara_utils.create_directory_deleting_old_if_necessary(Dir1)
    MetadataLines = read_ldt_metadata_file(Dir)
    if not MetadataLines:
        lara_utils.print_and_flush(f'*** Error: unable to find metadata in {Dir}')
        return False
    MetadataItems = [ lara_parse_utils.parse_ldt_metadata_file_line(Line) for Line in MetadataLines ]
    ( PreviousMnemonicBaseFiles, I, NBad, NCopied ) = ( [], 1, 0, 0 )
    for MetadataItem in MetadataItems:
        if MetadataItem and len(MetadataItem) == 2:
            ( File, Text ) = MetadataItem
            File1 = mnemonic_file_name(Text, I, File, PreviousMnemonicBaseFiles)
            PreviousMnemonicBaseFiles += [ lara_utils.file_to_base_file_and_extension(File1)[0] ]
            Result = lara_utils.copy_file(f'{Dir}/{File}', f'{Dir1}/{File1}')
            NCopied += 1
            I += 1
            if not Result:
                lara_utils.print_and_flush(f'*** Warning: unable to copy {File} to {File1}')
                NBad += 1
    lara_utils.print_and_flush(f'--- Copied {NCopied} files, {NBad} failed')

def mnemonic_file_name(Text, I, File, PreviousMnemonicBaseFiles):
    Extension = lara_utils.extension_for_file(File)
    ThreeDigitI = number_to_three_digit_string(I)
    TextNoPunc = lara_parse_utils.remove_punctuation_marks(Text.lower())
    ShortText = ' '.join(TextNoPunc.split()[:7])
    if not ShortText in PreviousMnemonicBaseFiles:
        return f'{ThreeDigitI}_{ShortText}.{Extension}'
    N = 1
    while True:
        ShortTextN = f'{ThreeDigitI}_{ShortText}_{N}'
        if not ShortTextN in PreviousMnemonicBaseFiles:
            return f'{ThreeDigitI}_{ShortTextN}.{Extension}'
        N += 1

def number_to_three_digit_string(I):
    if I < 10:
        return f'00{I}'
    if I < 100:
        return f'0{I}'
    return f'{I}'
