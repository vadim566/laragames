
import lara
import lara_download_metadata
import lara_html
import lara_images
import lara_audio
import lara_split_and_clean
import lara_translations
import lara_extra_info
import lara_utils
import lara_parse_utils
import lara_replace_chars
import lara_config
import time
import math
import statistics
import copy
import re

# Make the internal json-formatted frequency count file
def count_file(SplitFile, CountFile, Params):
    InList = lara_split_and_clean.read_split_file(SplitFile, Params)
    if not InList:
        lara_utils.print_and_flush(f'*** Error: unable to find {SplitFile} so unable to create count file')
        return False
    Assoc = {}
    count_lara_list(InList, Assoc)
    write_lara_count_file(Assoc, CountFile)
    store_headword_word_table(InList)

# Read the count file. Try to remake it if it doesn't already exist
def read_count_file(CountFile, Params):
    if not lara_utils.file_exists(CountFile) and Params.split_file != '':
        lara_utils.print_and_flush(f'*** Warning: unable to find {CountFile}, trying to remake')
        try:
            count_file(Params.split_file, CountFile, Params)
        except:
            lara_utils.print_and_flush(f'*** Error: something went wrong when trying to remake count file')
            return False
    if not lara_utils.file_exists(CountFile):
        lara_utils.print_and_flush(f'*** Error: unable to find or remake count file')
        return False
    return lara_utils.read_json_file(CountFile)

# Make the full set of compiled word pages (second stage of compilation)
def make_word_pages(Params):
    init_make_word_pages(Params)
    SplitList = init_resources_from_local_files(Params)
    Result = make_word_pages_main(SplitList, Params)
    if Params.compile_cache_file:
        cache_compilation_data(Params)
    return Result

# --------------------------------------

# Processing to create the internal count file
def count_lara_list(InList, Assoc):
    for ( PageInfo, Chunks) in InList:
        for Chunk in Chunks:
            Clean = Chunk[2]
            for ( Surface, Lemma ) in Clean:
                lara_utils.inc_assoc(Assoc, Lemma)

def write_lara_count_file(Assoc, File):
    List = [ [Lemma, Assoc[Lemma] ] for Lemma in Assoc ]
    SortedList = sorted(List, key=lambda x: x[1], reverse=True)
    lara_utils.write_json_to_file(SortedList, File)
    lara_utils.print_and_flush(f'--- Written count file ({len(SortedList)} records) {File}')

headword_word = {}

# Create a table which associates words with lemmas
def store_headword_word_table(InList):
    Pairs0 = [ ( Tag, Word ) for ( PageInfo, Chunks) in InList for Chunk in Chunks
               for ( Word, Tag ) in Chunk[2] if not lara_parse_utils.is_punctuation_string(Word) ]
    Pairs = lara_utils.remove_duplicates(Pairs0)
    store_headword_word_table1(Pairs)
    lara_utils.print_and_flush(f'--- Stored {len(Pairs)} headword/surface-word associations')

def store_headword_word_table1(Pairs):
    global headword_word
    headword_word = {}
    for ( Tag, Word ) in Pairs:
        if Tag in headword_word:
            headword_word[Tag] += [Word]
        else:
            headword_word[Tag] = [Word]

# --------------------------------------

cached_compilation_data_available = False

# Either initialise data or else restore cached data if we're incrementally compiling
def init_make_word_pages(Params):
    WordPagesDir = lara_utils.absolute_file_name(Params.word_pages_directory)
    MultimediaDir = f'{WordPagesDir}/multimedia'
    if not ( Params.recompile and lara_utils.directory_exists(WordPagesDir) ):
        lara_utils.create_directory_deleting_old_if_necessary(WordPagesDir)
    if not ( Params.recompile and lara_utils.directory_exists(MultimediaDir) ):
        lara_utils.create_directory(MultimediaDir)
    if Params.recompile and Params.compile_cache_file and lara_utils.file_exists(Params.compile_cache_file):
        restore_cached_compilation_data(Params)
    else:
        init_compilation_data()

# If we're doing local compilation, initialise audio and translation data from the appropriate directories
def init_resources_from_local_files(Params):
    StartTime = time.time()
    SplitList = lara_split_and_clean.read_split_file(Params.split_file, Params)
    if Params.local_files == 'yes':
        lara_images.process_image_directory(Params)
        lara_audio.process_recorded_audio_directory(Params, SplitList, 'segments')
        lara_audio.process_recorded_audio_directory(Params, SplitList, 'words')
        if Params.segment_translation_spreadsheet:
            lara_translations.process_segment_spreadsheet_file('local_files', Params.segment_translation_spreadsheet)
        else:
            lara_utils.print_and_flush('--- No segment translation spreadsheet defined')
        if Params.translation_spreadsheet:
            lara_translations.process_word_spreadsheet_file('local_files', Params.translation_spreadsheet)
        else:
            lara_utils.print_and_flush('--- No word translation spreadsheet defined')
    if StartTime is not None: 
        lara_utils.print_and_flush_with_elapsed_time('--- Completed initialisation', StartTime)
    return SplitList

# Having done initialisation, make the top-level pages, collect the word-page info, then make the word pages
def make_word_pages_main(PageOrientedSplitList, Params):
    global word_page_info_assoc
    PagesDir = Params.word_pages_directory
    store_vocab_counts(Params.count_file, Params)
    format_count_file_for_word_pages(Params.count_file, PagesDir, Params)
    format_alphabetical_file_for_word_pages(Params.count_file, PagesDir, Params)
    TextFiles = format_main_text_files_for_word_pages(PageOrientedSplitList, PagesDir, Params)
    TopFile = format_hyperlinked_text_file_for_word_pages(Params)
    format_toc_file(f'{PagesDir}/_toc_.html', Params)
    format_default_css_file(f'{PagesDir}/_styles_.css', Params)
    format_custom_css_file(f'{PagesDir}/_custom_styles_.css', Params)
    format_default_script_file(f'{PagesDir}/_script_.js', Params)
    format_custom_script_file(f'{PagesDir}/_custom_script_.js', Params)
    SplitList = [ Chunk for ( PageInfo, Chunks ) in PageOrientedSplitList if is_new_page(PageInfo, Params) for Chunk in Chunks ]
    ( Assoc, ChangedWordsAssoc ) = collect_word_page_info(SplitList, Params, Params.max_examples_per_word_page)
    make_word_pages1(Assoc, ChangedWordsAssoc, PagesDir, Params)
    word_page_info_assoc = Assoc
    return { 'top_file': TopFile, 'text_files': TextFiles }

# Is this the new page when we're doing an incremental compile?
def is_new_page(PageInfo, Params):
    if not Params.recompile or not cached_compilation_data_available:
        return True
    else:
        ( Corpus, PageNumber ) = Params.recompile
        return Corpus == PageInfo['corpus']['corpus'] and PageNumber == PageInfo['page']

# Make the top-level text page (holder for the real pages)
def format_hyperlinked_text_file_for_word_pages(Params):
    File = page_name_for_hyperlinked_text_file(Params)
    format_hyperlinked_text_file(File, Params)
    return File

def page_name_for_hyperlinked_text_file(Params):
    return f'{Params.word_pages_directory}/{formatted_hyperlinked_text_file_for_word_pages_short()}'

# Make the content pages
def format_main_text_files_for_word_pages(PageOrientedSplitList, PagesDir, Params):
    StartTime = time.time()
    AllErrors = []
    AllPageFiles = []
    lara_utils.print_and_flush(f'--- Creating {len(PageOrientedSplitList)} main text pages')
    # We need to do this first so that we can put in forward links
    create_main_page_list(PageOrientedSplitList, PagesDir)
    for ( PageInfo, SplitList ) in PageOrientedSplitList:
        #lara_utils.prettyprint(['--- PageInfo', PageInfo])
        PageParams = add_page_info_to_params(PageInfo, Params)
        #lara_utils.prettyprint(['--- PageParams', PageParams])
        maybe_format_custom_css_file_for_page(PageParams, PageInfo)
        maybe_format_custom_script_file_for_page(PageParams, PageInfo)
        FullPageName = full_page_name_for_page_info(PageInfo)
        LongFile = main_text_page_name_for_page_info_and_compiled_dir(PageInfo, PagesDir)
        ( MadeNewPage, Errors ) = format_main_text_file(SplitList, LongFile, FullPageName, PageParams)
        if MadeNewPage:
            AllPageFiles += [ [ key_for_page_info(PageInfo), LongFile ] ]
        AllErrors += Errors
    print_main_text_file_errors(AllErrors)
    if StartTime is not None: 
        lara_utils.print_and_flush_with_elapsed_time('--- Created main text files', StartTime)
    return AllPageFiles

# In the key/value list of pages, the key is a pair ( <CorpusName>, <PageNumber> )
def key_for_page_info(PageInfo):
    if 'page' in PageInfo and 'corpus' in PageInfo and 'corpus' in PageInfo['corpus']:
        return ( PageInfo['corpus']['corpus'], PageInfo['page'] )
    elif 'page' in PageInfo and 'corpus' in PageInfo:
        return ( PageInfo['corpus'], PageInfo['page'] )
    elif 'page' in PageInfo:
        return ( 'corpus', PageInfo['page'] )
    else:
        lara_utils.print_and_flush(f'*** Error: unable to make PageInfo {PageInfo} into key')
        return False

def corpus_name_for_page_info(PageInfo):
    Key = key_for_page_info(PageInfo)
    return Key[0] if Key else False

# Full pathname for a main content page
def main_text_page_name_for_page_info_and_compiled_dir(PageInfo, PagesDir):
    ShortFile = formatted_main_text_file_for_word_pages_short(full_page_name_for_page_info(PageInfo))
    return f'{PagesDir}/{ShortFile}'

# Filename for main content page, derived from page info
def full_page_name_for_page_info(PageInfo):
    CorpusInfo = PageInfo['corpus']
    CorpusName = CorpusInfo['corpus'] if isinstance(CorpusInfo, dict) else CorpusInfo
    PageName = PageInfo['page']
    return full_page_name_for_corpus_and_page(CorpusName, PageName)

def full_page_name_for_corpus_and_page(CorpusName, PageName):
    #return f'{CorpusName}_{PageName}'
    return PageName if CorpusName == 'local_files' else f'{CorpusName}_{PageName}'

# Create dict and list of content pages (needed for navigation functionality)
def create_main_page_list(PageOrientedSplitList, PagesDir):
    for ( PageInfo, SplitList ) in PageOrientedSplitList:
        FullPageName = full_page_name_for_page_info(PageInfo)
        ShortFile = formatted_main_text_file_for_word_pages_short(FullPageName)
        LongFile = f'{PagesDir}/{ShortFile}'
        add_main_page_to_list(FullPageName, ShortFile, LongFile)

def add_main_page_to_list(Name, ShortPage, FullPage):
    global list_of_main_pages
    global dict_of_main_pages
    list_of_main_pages += [{'name':Name, 'short_page':ShortPage, 'full_page':FullPage}]
    dict_of_main_pages[Name] = {'short_page':ShortPage, 'full_page':FullPage}

# Add the word_audio_voice to the params if it is non-null. We will need it if we are doing distributed LARA
# Add the css file from the page info to the params. We will need it if we have special css files for pages
# Add the script file similarly
def add_page_info_to_params(PageInfo, Params):
    PageParams = copy.copy(Params)
    if 'corpus' in PageInfo and 'corpus' in PageInfo['corpus'] and not PageInfo['corpus']['corpus'] == '':
        lara_utils.add_corpus_id_tag_to_params(PageParams, PageInfo['corpus']['corpus'])
    else:
        lara_utils.add_corpus_id_tag_to_params(PageParams, 'local_files')
    if 'corpus' in PageInfo and 'word_audio_voice' in PageInfo['corpus'] and not PageInfo['corpus']['word_audio_voice'] == '':
        PageParams.preferred_voice = PageInfo['corpus']['word_audio_voice']
    # Use the specific CSS file defined for the page if it's there
    if 'css_file' in PageInfo:
        PageParams.css_file_for_page = PageInfo['css_file']
    # Otherwise the CSS file for the corpus if that's defined
    elif 'corpus' in PageInfo and 'css_file' in PageInfo['corpus'] and not PageInfo['corpus']['css_file'] == '':
        PageParams.css_file_for_page = PageInfo['corpus']['css_file']
    if 'corpus' in PageInfo and 'script_file' in PageInfo['corpus'] and not PageInfo['corpus']['script_file'] == '':
        PageParams.script_file_for_page = PageInfo['corpus']['script_file']
    return PageParams

# Again, if we have a special css or script file for a page we need to take care of it here
def maybe_format_custom_css_file_for_page(Params, PageInfo):
    if Params.css_file_for_page != '':
        PagesDir = Params.word_pages_directory
        CSSFile = lara_html.css_file_for_page(Params)
        CorpusName = corpus_name_for_page_info(PageInfo)
        format_custom_css_file_for_page(f'{PagesDir}/{CSSFile}', CorpusName, Params)

def maybe_format_custom_script_file_for_page(Params, PageInfo):
    if Params.script_file_for_page != '':
        PagesDir = Params.word_pages_directory
        ScriptFile = lara_html.script_file_for_page(Params)
        CorpusName = corpus_name_for_page_info(PageInfo)
        format_custom_script_file_for_page(f'{PagesDir}/{ScriptFile}', CorpusName, Params)

##def format_main_text_file_for_word_pages(SplitList, PagesDir, Params):
##    FormattedFile = f'{PagesDir}/{formatted_main_text_file_for_word_pages_short()}'
##    format_main_text_file(SplitList, FormattedFile, Params)

# Make the frequency-ordered vocabulary file
def format_count_file_for_word_pages(CountFile, PagesDir, Params):
    FormattedFile = f'{PagesDir}/{formatted_count_file_for_word_pages_short()}'
    format_count_file(CountFile, FormattedFile, Params)

# Make the alphabetically ordered vocabulary file 
def format_alphabetical_file_for_word_pages(CountFile, PagesDir, Params):
    FormattedFile = f'{PagesDir}/{formatted_alphabetical_file_for_word_pages_short()}'
    format_alphabetical_file(CountFile, FormattedFile, Params)

# Names of top-level files
def formatted_hyperlinked_text_file_for_word_pages_short():
    return '_hyperlinked_text_.html'

def formatted_main_text_file_for_word_pages_short(PageName):
    return f'_main_text_{PageName}_.html'

def formatted_count_file_for_word_pages_short():
    return '_index_.html'

def formatted_alphabetical_file_for_word_pages_short():
    return '_alphabetical_index_.html'

# --------------------------------------

# Storing vocabulary counts in a dict

word_count_info = {}

def store_vocab_counts(CountFile, Params):
    global word_count_info
    word_count_info = {}
    for (Word, Count) in read_count_file(CountFile, Params):
        word_count_info[Word] = ( Count, math.log(Count) )

def get_word_count_info(Word):
    global word_count_info
    if Word in word_count_info:
        return word_count_info[Word]
    else:
        return False

# --------------------------------------

# Formatting the vocabulary files
def format_count_file(CountFile, OutFile, Params0):
    Params = adapt_params_for_count_and_alphabetical_files(Params0)
    InList = remove_punctuation_words(read_count_file(CountFile, Params0))
    TotalCount = sum([Count for (Word, Count) in InList])
    OutList = count_list_to_formatted_count_lines(InList, TotalCount, Params)
    Header = [lara_config.get_ui_text('index_heading_rank', Params), 
        lara_config.get_ui_text('index_heading_word', Params), 
        lara_config.get_ui_text('index_heading_freq', Params),
        lara_config.get_ui_text('index_heading_cumul', Params)]
    lara_html.print_lara_html_table(lara_config.get_ui_text('frequency_index', Params), Header, OutList, OutFile, Params)

def format_alphabetical_file(CountFile, OutFile, Params0):
    Params = adapt_params_for_count_and_alphabetical_files(Params0)
    InList = remove_punctuation_words(read_count_file(CountFile, Params0))
    SortedInList = order_count_list_alphabetically(InList)
    OutList = count_list_to_formatted_alphabetical_lines(SortedInList, Params)
    Header = [lara_config.get_ui_text('index_heading_word', Params), 
        lara_config.get_ui_text('index_heading_freq', Params)]
    lara_html.print_lara_html_table(lara_config.get_ui_text('alphabetical_index', Params), Header, OutList, OutFile, Params)

# We can't have audio mouseovers in these files, because they are lemmas rather than surface words
def adapt_params_for_count_and_alphabetical_files(Params):
    Params1 = copy.copy(Params)
    Params1.corpus_id = 'local_files'
    Params1.audio_mouseover = 'no'
    return Params1

def order_count_list_alphabetically(InList):
    return sorted(InList, key=lambda x: x[0])

def remove_punctuation_words(InList):
    return [ (Word, Count) for (Word, Count) in InList if not lara_parse_utils.is_punctuation_string(Word) ]

def count_list_to_formatted_count_lines(InList, TotalCount, Params):
    ( Cuml, I, Lines ) = ( 0, 1, [] )
    for (Word, Count) in InList:
        ( FormattedWord, CumlPCField, Cuml ) = count_list_item_to_formatted_count_line(Word, Count, TotalCount, I, Cuml, Params)
        Lines += [[ I, FormattedWord, Count, CumlPCField ]]
        I += 1
    return Lines

def count_list_item_to_formatted_count_line(Word, Count, TotalCount, I, CumlIn, Params):
    CumlOut = CumlIn + Count
    CumlPC = 100.0 * CumlOut / TotalCount
    CumlPCField = '{0:.2f}%'.format(CumlPC)
    # Turns word into a link
    FormattedWord = format_line_for_word_page(Word, [[Word, Word]], '*no_current_word*', Params)
    return ( FormattedWord, CumlPCField, CumlOut )

def count_list_to_formatted_alphabetical_lines(InList, Params):
    return [ count_list_item_to_formatted_alphabetical_line(Word, Count, Params) for (Word, Count) in InList ]

def count_list_item_to_formatted_alphabetical_line(Word, Count, Params):
    # Turns word into a link
    FormattedWord = format_line_for_word_page(Word, [[Word, Word]], '*no_current_word*', Params)
    return [FormattedWord, Count]

# --------------------------------------

# Collect all the info we're going to use to generate the word pages in a dict
# Iterate through the chunks
def collect_word_page_info(SplitList, Params, Limit):
    StartTime = time.time()
    lara_utils.print_and_flush(f'--- Collecting word page info for {len(SplitList)} segments')
    ( I, Assoc, ChangedWordsAssoc ) = ( 0, initial_assoc_for_word_page_info(Params), {} )
    for Chunk in [ Chunk for Chunk in SplitList if not lara_utils.is_page_tag_chunk(Chunk) ]:
        collect_word_page_info1(Chunk, Params, Limit, Assoc, ChangedWordsAssoc)
        I += 1
        if I%500 == 0:
            lara_utils.print_and_flush_no_newline(f'({I}) ')
    if StartTime is not None: 
        lara_utils.print_and_flush_with_elapsed_time('--- Collected word page info', StartTime)
    return ( Assoc, ChangedWordsAssoc )

def initial_assoc_for_word_page_info(Params):
    return word_page_info_assoc if Params.recompile and word_page_info_assoc != {} else {}

# Collect the word page info for a chunk
# Create the example words and calculate the score
def collect_word_page_info1(Chunk, Params0, Limit, Assoc, ChangedWordsAssoc):
    ( Raw, MinimallyCleaned, AnnotatedWords0, CorpusIdTag ) = Chunk
    Params = lara_utils.add_corpus_id_tag_to_params(Params0, CorpusIdTag)
    AnnotatedWords = regularise_html_tags_and_spaces_in_annotated_words(AnnotatedWords0, Params)
    Score = score_for_example(AnnotatedWords)
    collect_word_page_info2(MinimallyCleaned, AnnotatedWords, CorpusIdTag, Score, Params, Limit, Assoc, ChangedWordsAssoc)

# Iterate down the list of words
def collect_word_page_info2(MinimallyCleaned, AnnotatedWords, CorpusIdTag, Score, Params, Limit, Assoc, ChangedWordsAssoc):
    for ( Word, Lemma ) in AnnotatedWords:
        if get_word_count_info(Lemma) and not lara_parse_utils.is_punctuation_string(Lemma):
            CleanedLine = format_line_for_word_page(MinimallyCleaned, AnnotatedWords, Lemma, Params)
            Examples = Assoc[Lemma] if Lemma in Assoc else []
            if len([ Example for Example in Examples if Example[1] == CleanedLine and Example[2] == MinimallyCleaned ]) == 0:
                PossibleNewExample = ( Score, CleanedLine, MinimallyCleaned, CorpusIdTag )
                if len(Examples) < Limit:
                    Assoc[Lemma] = Examples + [ PossibleNewExample ]
                    ChangedWordsAssoc[Lemma] = 'changed'
                else:
                    LowestScoringExample = lowest_scoring_example(Examples)
                    if PossibleNewExample[0] > LowestScoringExample[0]:
                        Examples.remove(LowestScoringExample)
                        Assoc[Lemma] = Examples + [ PossibleNewExample ]
                        ChangedWordsAssoc[Lemma] = 'changed'

def regularise_html_tags_and_spaces_in_annotated_words(AnnotatedWords, Params):
    return [ ( regularise_html_tags_and_spaces(Word, Params), Lemma ) for ( Word, Lemma) in AnnotatedWords ]

def regularise_html_tags_and_spaces(Word, Params):
    return lara_parse_utils.regularise_spaces(lara_parse_utils.remove_hashtag_comment_and_html_annotations(Word, Params)[0])

# Other things being equal, prefer examples with common words
def score_for_example(AnnotatedWords):
    if len(AnnotatedWords) == 0:
        return 100.0
    else:
        LogScores = [ get_word_count_info(Lemma)[1] for ( Word, Lemma ) in AnnotatedWords if get_word_count_info(Lemma) ]
        return statistics.mean(LogScores) - penalty_for_short_example(AnnotatedWords)

# But avoid examples that are too short
def penalty_for_short_example(AnnotatedWords):
    Cutoff = 5
    PenaltyFactor = 1
    if len(AnnotatedWords) < Cutoff:
        return ( Cutoff - len(AnnotatedWords) ) * PenaltyFactor
    else:
        return 0.0

def lowest_scoring_example(Examples):
    return sorted(Examples, key=lambda x: x[0])[0]
	
# --------------------------------------

# Information collected during the compilation that's cached for next time

# Navigation
list_of_main_pages = []

# Navigation
dict_of_main_pages = {}

# Back-pointer arrows in examples
indexes_for_chunks = {}

# Table of contents
toc_for_html = [] # [ ( "plain text", Tag, Page, Segment ), ... ]

# Structure holding examples used to generate word pages
word_page_info_assoc = {}

# Zero all this information
def init_compilation_data():
    global list_of_main_pages
    global dict_of_main_pages
    global indexes_for_chunks
    global toc_for_html
    global word_page_info_assoc
    list_of_main_pages = []
    dict_of_main_pages = {}
    indexes_for_chunks = {}
    toc_for_html = []
    word_page_info_assoc = {}
    cached_compilation_data_available = False

# Cache it for next time
def cache_compilation_data(Params):
    DataToCache = { 'list_of_main_pages': list_of_main_pages,
                    'dict_of_main_pages': dict_of_main_pages,
                    'indexes_for_chunks': indexes_for_chunks,
                    'toc_for_html': toc_for_html,
                    'word_page_info_assoc': word_page_info_assoc }
    CacheFile = Params.compile_cache_file
    if not CacheFile:
        lara_utils.print_and_flush(f'*** Error: compile_cache_file not defined')
        return False
    lara_utils.save_data_to_pickled_gzipped_file(DataToCache, CacheFile)

# Restire from last run
def restore_cached_compilation_data(Params):
    global cached_compilation_data_available 
    global list_of_main_pages
    global dict_of_main_pages
    global indexes_for_chunks
    global toc_for_html
    global word_page_info_assoc
    cached_compilation_data_available = False
    CacheFile = Params.compile_cache_file
    if not CacheFile:
        lara_utils.print_and_flush(f'*** Error: compile_cache_file not defined')
        return False
    CachedData = lara_utils.get_data_from_pickled_gzipped_file(CacheFile)
    if not CachedData:
        lara_utils.print_and_flush(f'*** Error: unable to read cache file {CacheFile}')
        return False
    if not 'list_of_main_pages' in CachedData or \
       not 'dict_of_main_pages' in CachedData or \
       not 'indexes_for_chunks' in CachedData or \
       not 'toc_for_html' in CachedData or \
       not 'word_page_info_assoc' in CachedData:
        lara_utils.print_and_flush(f'*** Error: did not find expected data in cache file {CacheFile}')
        return False
    list_of_main_pages = CachedData['list_of_main_pages']
    dict_of_main_pages = CachedData['dict_of_main_pages']
    indexes_for_chunks = CachedData['indexes_for_chunks']
    toc_for_html = CachedData['toc_for_html']
    word_page_info_assoc = CachedData['word_page_info_assoc']
    cached_compilation_data_available = True

# First page for navigation
def short_name_of_first_main_file():
    global list_of_main_pages
    return list_of_main_pages[0]['short_page']

# Table of contents file
def short_name_of_toc_file():
    return '_toc_.html'

# Preceding file for navigation
def short_name_of_preceding_main_file(PageName):
    global list_of_main_pages
    for i in range(1, len(list_of_main_pages)):
        if list_of_main_pages[i]['name'] == PageName:
            return list_of_main_pages[i-1]['short_page']
    return False

# Following file for navigation
def short_name_of_following_main_file(PageName):
    global list_of_main_pages
    for i in range(0, len(list_of_main_pages)-1):
        if list_of_main_pages[i]['name'] == PageName:
            return list_of_main_pages[i+1]['short_page']
    return False

# Store the index for the minimally cleaned string (in fact, not the chunk)
def store_index_for_chunk(Index, Chunk):
    global indexes_for_chunks
    indexes_for_chunks[Chunk] = Index

# Find the index for the minimally cleaned string (in fact, not the chunk)
def index_for_chunk(Chunk):
    global indexes_for_chunks
    if Chunk in indexes_for_chunks:
        return indexes_for_chunks[Chunk]
    else:
        return False

# Store a line for the table of contents
def store_toc_for_html( Index, HtmlText, Params ):
    Match = re.search("<(h[12])>(.*)", HtmlText, flags=re.DOTALL)
    if Match is not None:
        # replace <tag..> and "speaker" symbol with blank
        PlainText = re.sub( "<[^>]+>", " ", Match.group(2))
        PlainText = re.sub( lara_extra_info.loudspeaker_icon_html_code(Params), " ", PlainText )
        # replace sequence of white space with single blank
        PlainText = re.sub( r"\s+", " ", PlainText)
        toc_for_html.append( ( PlainText, Match.group(1), Index[0], Index[1] ) )

# Make the top-level file
def format_hyperlinked_text_file(File, Params):
    #print(f'lara.py: Params.for_reading_portal = {Params.for_reading_portal}')
    FirstMainFile = short_name_of_first_main_file()
    HeaderLines = lara_html.hyperlinked_text_file_header(FirstMainFile, Params)
    ClosingLines = lara_html.hyperlinked_text_file_closing(Params)
    lara_utils.write_unicode_text_file('\n'.join(HeaderLines + ClosingLines), File)
    lara_utils.print_and_flush(f'--- Written hyperlinked text file {File}')

# Make the table of contents file
def format_toc_file(File, Params):
    Lines = lara_html.toc_lines_intro( lara_config.get_ui_text("table_of_contents", Params), Params ) \
        + [ f"<{Tag} class='toc'><a target='{lara_utils.split_screen_pane_name_for_main_text_screen(Params)}' href='{formatted_main_text_file_for_word_pages_short(PageName)}#{anchor_for_index((PageName, Segment))}'><b>{lara_extra_info.arrow_html_code(Params)}</b> {PlainText}</{Tag}>"
            for ( PlainText, Tag, PageName, Segment ) in toc_for_html ] \
        + lara_html.toc_lines_closing()
    lara_utils.write_unicode_text_file("\n".join( Lines ), File)
    lara_utils.print_and_flush(f'--- Written table of contents file {File}')

# Make a main content file
def format_main_text_file(SplitList, File, PageName, Params):
    if Params.recompile and cached_compilation_data_available and lara_utils.file_exists(File):
        return ( False, [] )
    PrecedingMainFile = short_name_of_preceding_main_file(PageName)
    FollowingMainFile = short_name_of_following_main_file(PageName)
    FirstMainFile = short_name_of_first_main_file()
    HeaderLines = lara_html.main_text_file_header(PrecedingMainFile, FollowingMainFile, FirstMainFile, Params)
    ( BodyLines, Errors ) = format_hyperlinked_text_file_lines(SplitList, PageName, Params)
    ClosingLines = lara_html.main_text_file_closing(PrecedingMainFile, FollowingMainFile, Params)
    lara_utils.write_unicode_text_file('\n'.join(HeaderLines + BodyLines + ClosingLines), File)
    lara_utils.print_and_flush(f'--- Written main text file {File}')
    return ( True, Errors )

# Write out the default css file
def format_default_css_file(File, Params):
    CssText = lara_html.default_styles(Params)
    lara_utils.write_unicode_text_file(CssText, File)
    lara_utils.print_and_flush(f'--- Written css file {File}')

# Write out a custom css file, if we have defined one for a page
def format_custom_css_file(File, Params):
    #lara_utils.prettyprint(['--- format_custom_css_file', File, Params])
    if Params.css_file != '' and Params.corpus != '':
        #SourceFile = Params.css_file
        SourceFile = f'{lara_utils.directory_for_pathname(Params.corpus)}/{Params.css_file}'
        #Result = lara_utils.copy_file( SourceFile, File )
        Result = lara_images.process_img_tags_in_css_or_script_file(SourceFile, File, Params)
        if not Result:
            lara_utils.print_and_flush(f'*** Error: unable to copy file: {SourceFile} to {File}')
            return False
        lara_utils.print_and_flush(f'--- Copied custom css file {SourceFile} to {File}')

# Write out the default script file
def format_default_script_file(File, Params):
    ScriptText = lara_html.default_script(Params)
    lara_utils.write_unicode_text_file(ScriptText, File)
    lara_utils.print_and_flush(f'--- Written script file {File}')

# Write out a custom script file, if we have defined one for a page
def format_custom_script_file(File, Params):
    if Params.script_file != '' and Params.corpus != '':
        #SourceFile = Params.script_file
        SourceFile = f'{lara_utils.directory_for_pathname(Params.corpus)}/{Params.script_file}'
        #Result = lara_utils.copy_file( SourceFile, File )
        Result = lara_images.process_img_tags_in_css_or_script_file(SourceFile, File, Params)
        if not Result:
            lara_utils.print_and_flush(f'*** Error: unable to install script file {SourceFile} to {File}')
            return False
        lara_utils.print_and_flush(f'--- Written custom script file {File}')
        return True

## Often we will use the same style file for many pages, so only copy it once.
## We create a new target directory for each compile, so there should be no danger of
## finding an old version still lying around.
def format_custom_css_file_for_page(File, CorpusName, Params):
    #lara_utils.prettyprint(['--- format_custom_css_file_for_page', File, CorpusName, Params])
    if Params.css_file_for_page != '' and not lara_utils.file_exists(File):
        if lara_download_metadata.downloaded_css_file_name(Params, CorpusName, Params.css_file_for_page):
            SourceFile = lara_download_metadata.downloaded_css_file_name(Params, CorpusName, Params.css_file_for_page)
        elif Params.corpus and not Params.corpus == '':
            SourceFile = f'{lara_utils.directory_for_pathname(Params.corpus)}/{Params.css_file_for_page}'
        else:
            lara_utils.print_and_flush(f'*** Error: unable to find CSS file {File}')
            return False
        #Result = lara_utils.copy_file( SourceFile, File )
        Result = lara_images.process_img_tags_in_css_or_script_file(SourceFile, File, Params)
        if not Result:
            lara_utils.print_and_flush(f'*** Error: unable to copy file: {SourceFile} to {File}')
            return False
        lara_utils.print_and_flush(f'--- Written custom css file for page {File}')

## Similarly for script files
def format_custom_script_file_for_page(File, CorpusName, Params):
    if Params.script_file_for_page != '' and not lara_utils.file_exists(File):
        if lara_download_metadata.downloaded_script_file_name(Params, CorpusName, Params.script_file_for_page):
            SourceFile = lara_download_metadata.downloaded_script_file_name(Params, CorpusName, Params.script_file_for_page)
        else:
            lara_utils.print_and_flush(f'*** Error: unable to find script file {File}')
            return False
        #Result = lara_utils.copy_file( SourceFile, File )
        Result = lara_images.process_img_tags_in_css_or_script_file(SourceFile, File, Params)
        if not Result:
            lara_utils.print_and_flush(f'*** Error: unable to copy file: {SourceFile} to {File}')
            return False
        lara_utils.print_and_flush(f'--- Written script file for page {File}')

# Sort all the errors and warnings and print them separately
def print_main_text_file_errors(ErrorsAndWarnings):
    if len(ErrorsAndWarnings) > 0:
        UniqueErrorsAndWarnings = lara_utils.remove_duplicates(ErrorsAndWarnings)
        ( UniqueErrors, UniqueWarnings ) = separate_errors_and_warnings(UniqueErrorsAndWarnings)
        if len(UniqueErrors) > 0:
            lara_utils.print_and_flush(f'{len(UniqueErrors)} errors:')
            for Error in UniqueErrors:
                lara_utils.print_and_flush(Error)
        if len(UniqueWarnings) > 0:
            lara_utils.print_and_flush(f'{len(UniqueWarnings)} warnings:')
            for Warning in UniqueWarnings:
                lara_utils.print_and_flush(Warning)

def separate_errors_and_warnings(ErrorsAndWarnings):
    Errors = [ Str for Str in ErrorsAndWarnings if (Str.lower()).find('error') >= 0 ]
    Warnings = [ Str for Str in ErrorsAndWarnings if (Str.lower()).find('error') < 0 ]
    return ( Errors, Warnings )

# Format the lines in a main context page
def format_hyperlinked_text_file_lines(SplitList, PageName, Params):
    ( HyperlinkedChunkStrings, Errors ) = format_hyperlinked_text_file_lines1(SplitList, PageName, Params)
    HyperlinkedChunkString = ''.join(HyperlinkedChunkStrings)
    HyperlinkedLines = HyperlinkedChunkString.split('\n')
    HTMLLines = hyperlinked_lines_to_html_lines(HyperlinkedLines)
    return ( HTMLLines, Errors )

# Iterate through the chunks in the list
def format_hyperlinked_text_file_lines1(SplitList, PageName, Params):
    ( N, AllStrings, AllErrors ) = ( 1, [], [] )
    for Chunk in SplitList:
        ( String, Errors ) = format_hyperlinked_text_file_line(Chunk, Params, PageName, N)
        AllStrings += [String]
        AllErrors += Errors
        N += 1
    return ( AllStrings, AllErrors )

# Format a single chunk
# Format the words, then insert the formatted versions into the raw text.
def format_hyperlinked_text_file_line(Chunk, Params0, PageName, N):
    (Raw, MinimallyCleaned, AnnotatedWords, CorpusIdTag) = Chunk
    Params = lara_utils.add_corpus_id_tag_to_params(Params0, CorpusIdTag)
    WordsAndHyperlinkedVersions = words_and_hyperlinked_versions_in_list(AnnotatedWords, Params)
    HyperlinkedRaw0 = add_hyperlinking_to_raw_text(Raw, Params, WordsAndHyperlinkedVersions)
    HyperlinkedRaw1 = remove_intra_word_separators_in_string(HyperlinkedRaw0)
    HyperlinkedRaw = lara_replace_chars.restore_reserved_chars(HyperlinkedRaw1)
    ( HyperlinkedRawWithAudio, Errors ) = lara_extra_info.add_audio_and_translation_to_line(HyperlinkedRaw, MinimallyCleaned, Params)
    Index = [PageName, N]
    HyperlinkedRawWithAudioAndAnchor = add_anchor_to_line(HyperlinkedRawWithAudio, Index)
    store_toc_for_html( Index, HyperlinkedRawWithAudio, Params )
    store_index_for_chunk(Index, MinimallyCleaned)
    return ( HyperlinkedRawWithAudioAndAnchor, Errors )

# Format the words
def words_and_hyperlinked_versions_in_list(AnnotatedWords, Params):
    return [ ( Word, format_hyperlinked_text_file_line_word(Word, Lemma, Params) ) for ( Word, Lemma ) in AnnotatedWords
             if not lara_parse_utils.is_punctuation_string(Lemma) ]

def format_hyperlinked_text_file_line_word(Word, Lemma, Params):
    ( FileName, Count ) = file_name_for_word(Lemma)
    ColouredWord = colour_mark_word_for_count(Word, Params, Count)
    ColouredWord1 = lara_extra_info.maybe_add_translation_and_or_audio_mouseovers_to_word(ColouredWord, Word, Lemma, Params)
    ScreenName = lara_utils.split_screen_pane_name_for_word_page_screen(Params)
    return f'<a href="{FileName}" target="{ScreenName}">{ColouredWord1}</a>'

# insert the formatted versions into the raw text.
# TO DO: reorder this so that comment markers are taken out last, and skip comments when substituting
def add_hyperlinking_to_raw_text(Raw, Params, WordsAndHyperlinkedVersions):
    Raw1 = process_img_and_audio_tags_in_string(Raw, Params)
    Raw2 = remove_intra_word_separators_in_string(Raw1)
    Raw3 = remove_comment_markers_in_string(Raw2)
    Raw4 = lara_parse_utils.remove_hashtag_annotations_from_string(Raw3)
    return add_hyperlinking_to_raw_text1(WordsAndHyperlinkedVersions, Raw4)

# Adjust the img and audio tags
def process_img_and_audio_tags_in_string(Str, Params):
    Str1 = lara_images.process_img_tags_in_string(Str, Params)[0]
    return lara_audio.process_audio_tags_in_string(Str1, Params)[0]

def remove_intra_word_separators_in_string(Str):
    return Str.replace('|', '')

def remove_comment_markers_in_string(Str):
    Str1 = Str.replace('/*', '')
    return Str1.replace('*/', '')

# Iterate down the list of words we're going to substitute
def add_hyperlinking_to_raw_text1(WordHyperlinkedWordPairs, RawStr):
    ( Index, N, HyperlinkedStr ) = ( 0, len(RawStr), '' )
    for ( Word0, HyperlinkedWord ) in WordHyperlinkedWordPairs:
        Word = remove_intra_word_separators_in_string(Word0)
        ( Index, HyperlinkedStr ) = add_hyperlinking_to_raw_text_single(Word, HyperlinkedWord, RawStr, Index, N, HyperlinkedStr)
    return HyperlinkedStr + RawStr[Index:]

# Substitute a single word
def add_hyperlinking_to_raw_text_single(Word, HyperlinkedWord, RawStr, Index, N, HyperlinkedStr):
    InsideTagP = '*not_inside_tag*'
    while True:
        if Index >= N:
            lara_utils.print_and_flush(f'*** Error: unable to find "{Word}" in "{RawStr}"')
            return False
        elif InsideTagP == '*not_inside_tag*' and lara_parse_utils.substring_found_at_index(RawStr, Index, Word):
            return ( Index + len(Word), HyperlinkedStr + HyperlinkedWord )
        else:
            if RawStr[Index] == '<':
                InsideTagP = '*inside_tag*'
            elif RawStr[Index] == '>':
                InsideTagP = '*not_inside_tag*'
            HyperlinkedStr += RawStr[Index]
            Index += 1

# Add an anchor. Put it in a place where highlighting will work well            
def add_anchor_to_line(Line, Index):
    #return f'<a id="{anchor_for_index(Index)}"></a>{Line}'
    return insert_before_first_real_text(f'<a id="{anchor_for_index(Index)}"></a>', Line)

# Insert material in string, skipping initial whitespaces and some tags
def insert_before_first_real_text(ToInsert, StrIn):
    I = 0
    N = len(StrIn)
    StrOut = ''
    while True:
        if I >= N:
            return StrIn + ToInsert
        elif StrIn[I].isspace():
            I += 1
        elif StrIn[I] == "<" and not starts_with_content_tag(StrIn[I:]):
            EndOfTag = StrIn.find(">", I+1)
            I = EndOfTag + 1
        else:
            return StrIn[:I] + ToInsert + StrIn[I:]

# We don't skip over these tags (provisional version, list may well change later)
content_tag_strings = ['<a ', '<span ', '<p>']

def starts_with_content_tag(Str):
    for TagStr in content_tag_strings:
        if Str.startswith(TagStr):
            return True
    return False

# Add the back-arrow link to an example
def add_context_link_to_line(Line, Index, Params):
    MainTextPage = formatted_main_text_file_for_word_pages_short(Index[0])
    Anchor = anchor_for_index(Index)
    ScreenName = lara_utils.split_screen_pane_name_for_main_text_screen(Params)
    return f'<a href="{MainTextPage}#{Anchor}" target="{ScreenName}"><b>{lara_extra_info.arrow_html_code(Params)}</b></a> {Line}'

# Target for back-arrows in examples
def anchor_for_index(Index):
    ( PageName, N ) = Index
    return f'page_{PageName}_segment_{N}'

# Colour word using frequency count
def colour_mark_word_for_count(Word, Params, Count):
    if Params.coloured_words == 'no':
        return Word
    else:
        Colour = colour_id_for_count(Count)
        if Colour == 'black':
            return Word
        else:
            return f'<span class="{Colour}">{Word}</span>'

def colour_id_for_count(Count):
    if Count <= 1:
        return 'red'
    elif 2 <= Count and Count <= 3:
        return 'green'
    elif 4 <= Count and Count <= 5:
        return 'blue'
    else:
        return 'black'

# Turn lines into HTML by adding <p> tags
def hyperlinked_lines_to_html_lines(HyperlinkedLines):
    return [ word_page_line_to_html_line(HyperlinkedLine) for HyperlinkedLine in HyperlinkedLines ]

def word_page_line_to_html_line(HyperlinkedLine):
    if HyperlinkedLine.isspace() or HyperlinkedLine == '':
        HyperlinkedLine1 = '&nbsp;'
    else:
        HyperlinkedLine1 = HyperlinkedLine
    if line_starts_with_tag_not_needing_paragraph(HyperlinkedLine1):
        return HyperlinkedLine1
    else:
        return f'<p>{HyperlinkedLine1}</p>'

tags_not_needing_paragraph = ['<h1', '<h2', '<img', '<audio', '<table', '</table>', '<tr', '<td']

# Don't wrap a <p> around headers, images, embedded audio and table elements
def line_starts_with_tag_not_needing_paragraph(Line):
    Line1 = Line.lstrip().lower()
    for Tag in tags_not_needing_paragraph:
        if Line1.startswith(Tag):
            return True
    return False

# --------------------------------------

# Format examples for the word pages: use code for formatting main text, slightly customised
# Mark the head word on the current page in red and don't use color to mark frequencies
def format_line_for_word_page(Raw, AnnotatedWords, CurrentWord, Params):
    WordsAndHyperlinkedVersions = words_and_hyperlinked_versions_in_list_for_word_page(AnnotatedWords, CurrentWord, Params)
    Line0 = add_hyperlinking_to_raw_text(Raw, Params, WordsAndHyperlinkedVersions)
    return lara_replace_chars.restore_reserved_chars(Line0)

def words_and_hyperlinked_versions_in_list_for_word_page(AnnotatedWords, CurrentWord, Params):
    return [ ( Word, format_hyperlinked_text_file_line_word_for_word_page(Word, Lemma, CurrentWord, Params) )
             for ( Word, Lemma ) in AnnotatedWords
             if not lara_parse_utils.is_punctuation_string(Lemma) ]

def format_hyperlinked_text_file_line_word_for_word_page(Word, Lemma, CurrentWord, Params):
    ( FileName, Count ) = file_name_for_word(Lemma)
    if Lemma == CurrentWord:
        ColouredWord = mark_in_red(Word)
    else:
        ColouredWord = Word
    ColouredWord1 = lara_extra_info.maybe_add_translation_and_or_audio_mouseovers_to_word(ColouredWord, Word, Lemma, Params)
    ScreenName = lara_utils.split_screen_pane_name_for_word_page_screen(Params)
    return f'<a href="{FileName}" target="{ScreenName}">{ColouredWord1}</a>'

def mark_in_red(Word):
    Colour = 'red'
    return f'<span class="{Colour}">{Word}</span>'

# Name of word page file for a given word
def file_name_for_word(Word):
    wordCount = get_word_count_info(Word)
    if not wordCount:
        lara_utils.print_and_flush(f'*** Error: unable to find word count info for "{Word}"')
        return False
    else:
        ( Count, LogCount) = wordCount
        Word1 = lara_split_and_clean.clean_up_word_for_files(Word)
        return ( f'word_{Word1}.html', Count )

def full_file_name_for_word(Word, MultimediaDir):
    ( FileName, Count ) = file_name_for_word(Word)
    return f'{MultimediaDir}/{FileName}'

# --------------------------------------

# Make all the word pages out of the dict created by collect_word_page_info
def make_word_pages1(Assoc, ChangedWordsAssoc, MultimediaDir, Params):
    StartTime = time.time()
    lara_utils.print_and_flush(f'\n--- Printing word pages for {len(ChangedWordsAssoc.keys())} words')
    make_word_pages2(Assoc, ChangedWordsAssoc, MultimediaDir, Params)
    #lara_utils.print_and_flush(f'\n--- Created word pages in {MultimediaDir}')
    if StartTime is not None:
        lara_utils.print_and_flush('\n')
        lara_utils.print_and_flush_with_elapsed_time(f'--- Created word pages in {MultimediaDir}', StartTime)

# Iterate through the assoc. Print an update every 500 pages
def make_word_pages2(Assoc, ChangedWordsAssoc, MultimediaDir, Params):
    I = 0
    for Word in ChangedWordsAssoc:
        make_word_page(Word, Assoc[Word], MultimediaDir, Params)
        I += 1
        if I%500 == 0:
            lara_utils.print_and_flush_no_newline(f'({I}) ')

# Making one word page: make lines, then convert to HTML as with main content pages
def make_word_page(Word, Examples, MultimediaDir, Params):
    HTMLLines = word_page_lines(Word, Examples, Params)
    FileName = full_file_name_for_word(Word, MultimediaDir)
    # We could also write out the lines to a database
    if Params.write_word_pages_to_file == 'yes':
        lara_utils.write_unicode_text_file('\n'.join(HTMLLines), FileName)

# Add header and footer into, format examples which constitute main content
def word_page_lines(Word, Examples, Params):
    Intro = lara_html.word_page_lines_header(Word, Params)
    ExtraInfoTop = lara_extra_info.word_page_lines_extra_info_top(Word, Params)
    Examples = word_page_lines_to_html_lines1(Examples, Params)
    ExtraInfoBottom = lara_extra_info.word_page_lines_extra_info_bottom(Word, Params)
    Closing = lara_html.word_page_lines_closing(formatted_count_file_for_word_pages_short(), formatted_alphabetical_file_for_word_pages_short(), Params)
    return Intro + ExtraInfoTop + Examples + ExtraInfoBottom + Closing

def word_page_lines_to_html_lines1(Examples, Params):
    return [ example_to_html_line(Example, Params) for Example in Examples ]

# Add audio for the whole line + back-arrow pointing to context in main text
def example_to_html_line(Example, Params0):
    ( Score, Clean0, MinimallyCleaned, CorpusIdTag ) = Example
    Params = lara_utils.add_corpus_id_tag_to_params(Params0, CorpusIdTag)
    Clean = remove_intra_word_separators_in_string(Clean0)
    Example = add_audio_and_link_to_line(Clean, MinimallyCleaned, Params)
    return word_page_line_to_html_line(Example)

def add_audio_and_link_to_line(Clean, MinimallyCleaned, Params):
    Index = index_for_chunk(MinimallyCleaned)
    ( CleanWithAudio, Errors) = lara_extra_info.add_audio_and_translation_to_line(Clean, MinimallyCleaned, Params)
    return add_context_link_to_line(CleanWithAudio, Index, Params)


