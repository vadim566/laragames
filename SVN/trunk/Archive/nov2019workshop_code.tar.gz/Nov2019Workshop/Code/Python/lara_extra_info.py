
import lara_audio
import lara_translations
import lara_utils
import lara_parse_utils

def add_audio_and_translation_to_line(Line, MinimallyCleaned, Params):
    if Line.isspace():
        return ( Line, [] )
    else:
        LoudspeakerIconHTMLCode = loudspeaker_icon_html_code(Params)
        ( AudioURL, AudioErrors ) = get_audio_url_for_line_or_add_to_errors(MinimallyCleaned, Params)
        ( Translation, TranslationErrors) = get_translation_for_line_or_add_to_errors(MinimallyCleaned, Params)
        Control = audio_and_translation_control_for_line(LoudspeakerIconHTMLCode, AudioURL, Translation)
        return ( f'{Line} {Control}', AudioErrors + TranslationErrors )

def get_audio_url_for_line_or_add_to_errors(MinimallyCleaned, Params):
    if MinimallyCleaned.isspace() or MinimallyCleaned == '':
        return ( '*no_audio_url*', [] )
    elif Params.audio_segments == 'no' or lara_audio.no_audio('segments', Params):
        return ( '*no_audio_url*', [] )
    else:
        AudioURL = lara_audio.get_audio_url_for_chunk_or_word(MinimallyCleaned, 'segments', Params)
        if AudioURL:
            return ( AudioURL, [] )
        else:
            return ( '*no_audio_url*', [ f'*** Warning: unable to add audio for "{MinimallyCleaned}"' ] )

def get_translation_for_line_or_add_to_errors(MinimallyCleaned, Params):
    if MinimallyCleaned.isspace() or MinimallyCleaned == '':
        return ( '*no_translation*', [] )
    elif Params.segment_translation_mouseover == 'no':
        return ( '*no_translation*', [] )
    elif lara_translations.no_segment_translations(lara_utils.get_corpus_id_from_params(Params)):
        return ( '*no_translation*', [] )
    else:
        CorpusId = lara_utils.get_corpus_id_from_params(Params)
        if lara_translations.translation_for_segment(MinimallyCleaned, CorpusId):
            return ( lara_translations.translation_for_segment(MinimallyCleaned, CorpusId), [] )
        else:
            return ( '*no_translation*', [ f'*** Warning: unable to add translation for "{MinimallyCleaned}"' ] )

def audio_and_translation_control_for_line(LoudspeakerIconHTMLCode, AudioURL, Translation):
    QuotTranslation = Translation.replace("\"", "&quot;")
    # No audio, no translation
    if AudioURL == '*no_audio_url*' and Translation == '*no_translation*':
        return ''
    # No audio, translation
    if AudioURL == '*no_audio_url*':
        return f'<span title="{QuotTranslation}">{LoudspeakerIconHTMLCode}</span>'
    # No translation, audio
    if Translation =='*no_translation*':
        return f'<span onclick="playSound(\'{AudioURL}\');" onmouseover="" style="cursor: pointer;">{LoudspeakerIconHTMLCode}</span>'
    # Audio and translation
    else:
        return f'<span class="sound" onclick="playSound(\'{AudioURL}\');" title="{QuotTranslation}">{LoudspeakerIconHTMLCode}</span>'

def loudspeaker_icon_html_code(Params):
    if Params.text_direction == 'rtl':
        # left-to-right loudspeaker
        return '&#x1f50a;'
    else:
        # left-to-right loudspeaker
        return '&#x1f50a;'    

def arrow_html_code(Params):
    if Params.text_direction == 'rtl':
        # arrow pointing right
        return '&rarr;'
    else:
        # arrow pointing left
        return '&larr;'

def previous_arrow_html_code(Params):
    if Params.text_direction == 'rtl':
        # arrow pointing right
        #return '&#x1F81A;'
        return '&#9654;'
    else:
        # arrow pointing left
        #return '&#x1F818;'
        return '&#9664;'

def next_arrow_html_code(Params):
    if Params.text_direction == 'rtl':
        # arrow pointing right
        #return '&#x1F818;'
        return '&#9664;'
    else:
        # arrow pointing left
        #return '&#x1F81A;'
        return '&#9654;'

def up_arrow_html_code(Params):
        return '&#9650;'

# --------------------------------------
                        
def maybe_add_translation_and_or_audio_mouseovers_to_word(ColouredWord, Word, Lemma, Params):
    if Params.translation_mouseover == 'yes' and \
       Params.audio_mouseover != 'no' and \
       lara_translations.translation_for_headword(Lemma, lara_utils.get_language_id_from_params(Params)) and \
       lara_audio.get_audio_url_for_word(Word, Params):
        Translation = lara_translations.translation_for_headword(Lemma, lara_utils.get_language_id_from_params(Params))
        AudioURL = lara_audio.get_audio_url_for_word(Word, Params)
        ColouredWord1 = maybe_add_colour_for_audio_word(ColouredWord, Params)
        return add_translation_and_audio_mouseovers_to_word(ColouredWord1, Translation, AudioURL, Params.audio_mouseover)
    elif Params.translation_mouseover == 'yes' and \
         lara_translations.translation_for_headword(Lemma, lara_utils.get_language_id_from_params(Params)):
        return add_translation_mouseover_to_word(ColouredWord, Lemma, Params)
    else:
        ColouredWord1 = maybe_add_colour_for_audio_word(ColouredWord, Params)
        return maybe_add_audio_mouseover_to_word(ColouredWord1, Word, Params)

## If we aren't using colour for frequencies, we might want to use it to mark audio words
def maybe_add_colour_for_audio_word(ColouredWord, Params):
    if Params.audio_words_in_colour != 'no' and \
       Params.audio_mouseover != 'no' and \
       Params.coloured_words == 'no':
        Colour = Params.audio_words_in_colour
        return f'<span class="{Colour}">{ColouredWord}</span>'
    else:
        return ColouredWord

def add_translation_and_audio_mouseovers_to_word(ColouredWord, Translation, AudioFile, AudioMouseover):
    PlaySoundCall = f'playSound(\'{AudioFile}\');'
    if AudioMouseover == 'yes':
        return f'<span title="{Translation}" onmouseover="{PlaySoundCall}">{ColouredWord}</span>'  
    if AudioMouseover == 'both':
        return f'<span title="{Translation}" ontouchstart="{PlaySoundCall}" onmouseover="{PlaySoundCall}">{ColouredWord}</span>'  
    return f'<span title="{Translation}">{ColouredWord}</span>'  

def maybe_add_audio_mouseover_to_word(ColouredWord, Word, Params):
    if Params.audio_mouseover != 'no':
        return lara_audio.add_audio_mouseover_to_word(ColouredWord, Word, Params)
    else:
        return ColouredWord

# --------------------------------------

def add_translation_mouseover_to_word(ColouredWord, Lemma, Params):
    if lara_translations.translation_for_headword(Lemma, lara_utils.get_language_id_from_params(Params)):
        Translation = lara_translations.translation_for_headword(Lemma, lara_utils.get_language_id_from_params(Params))
        return f'<span title="{Translation}">{ColouredWord}</span>'
    else:
        return ColouredWord

def word_page_lines_extra_info_top(Word, Params):
    return word_page_lines_language_specific_extra_info(Word, Params)

def word_page_lines_extra_info_bottom(Word, Params):
    return []

def word_page_lines_language_specific_extra_info(Word, Params):
    if Params.extra_page_info == 'yes' and Params.language == 'icelandic':
        return icelandic_extra_info(Word)
    if Params.extra_page_info == 'yes' and Params.language == 'japanese':
        return japanese_extra_info(Word)
    else:
        return []

# --------------------------------------

icelandic_uninflected_words_file = '$LARA/Content/icelandic/corpora/icelandic_uninflected_words.txt'

icelandic_info_initialised = 'no'

icelandic_uninflected_words = {}

def icelandic_uninflected_word_info(Word):
    global icelandic_uninflected_words
    maybe_initialise_icelandic_info()
    if Word in icelandic_uninflected_words:
        return icelandic_uninflected_words[Word]
    else:
        return False

def maybe_initialise_icelandic_info():
    global icelandic_info_initialised
    if icelandic_info_initialised == 'no':
        icelandic_uninflected_words = {}
        AllInfo = get_uninflected_word_info()
        initialise_icelandic_info(AllInfo)
        lara_utils.print_and_flush(f'--- Stored information for {len(AllInfo)} uninflected Icelandic words')
        icelandic_info_initialised = 'yes'

def get_uninflected_word_info():
    global icelandic_uninflected_words_file
    File = icelandic_uninflected_words_file
    if not lara_utils.file_exists(icelandic_uninflected_words_file):
        print(f'*** Warning: unable to find file: {icelandic_uninflected_words_file}')
        return []
    try:
        return lara_utils.read_ascii_text_file_to_lines(File)
    except:
        print(f'*** Warning: unable to read file: {icelandic_uninflected_words_file}')
        return []

def initialise_icelandic_info(AllInfo):
    for Line in AllInfo:
        initialise_icelandic_info_for_line(Line)

def initialise_icelandic_info_for_line(Line):
    global icelandic_uninflected_words
    Line1 = lara_parse_utils.remove_initial_and_final_spaces(Line)
    Components = Line1.split()
    ( Word, Categories ) = ( Components[0], Components[1:] )
    Categories1 = [ convert_icelandic_uninflected_word_category(Category) for Category in Categories ]
    Info = ' '.join([ Word, '-'] + Categories1)
    icelandic_uninflected_words[Word] = Info

# The word classes are
# adverbs (ao, atviksorð),
# preposition (fs, forsetning),
# infinitive particle (nhm, nafnháttarmerki),
# conjunction (st, samtenging),
# numeral (töl, töluorð), 
# exclamations (uh, upphrópun).

icelandic_uninflected_word_categories = {'ao': 'adverb',
                                         'fs': 'preposition',
                                         'nhm': 'infinitive-particle',
                                         'st': 'conjunction',
                                         'töl': 'numeral',
                                         'uh': 'exclamation'}

def convert_icelandic_uninflected_word_category(Cat):
    global icelandic_uninflected_word_categories
    if Cat in icelandic_uninflected_word_categories:
        return icelandic_uninflected_word_categories[Cat]
    else:
        return Cat
    
# --------------------------------------

def icelandic_extra_info(Word):
    UninflectedWordInfo = icelandic_uninflected_word_info(Word)
    if UninflectedWordInfo:
        return [f'<p><b>{UninflectedWordInfo}</b></p>']
    else:
        LookupWord = icelandic_lookup_word_for_word(Word)
        Action = f'window.open(\'http://bin.arnastofnun.is/leit/?q={LookupWord}\', \'newWin\', \'width=800, height=600\')'
        return [f'<a href="javascript:void(0)" onclick="{Action}"><b><u>Grammar information</u></b></a>']

def icelandic_lookup_word_for_word(Word):
    Components = Word.split()
    if len(Components) == 2 and Components[0] == 'að':
        return Components[1]
    else:
        return Word

# --------------------------------------

def japanese_extra_info(Word):
    LookupWord = japanese_lookup_word_for_word(Word)
    Action = f'window.open(\'https://jisho.org/search/{LookupWord}\', \'newWin\', \'width=800, height=600\')'
    return [f'<a href="javascript:void(0)" onclick="{Action}"><b><u>Jisho.org information</u></b></a>']

def japanese_lookup_word_for_word(Word):
    return Word

# -----------------------------------------------
#
# French
#
# Example for écrire: http://www.french-linguistics.co.uk/verbs/table/%E9crire.html
#
#
# -----------------------------------------------
#
#
# English
# 
# Example for go: http://www.french-linguistics.co.uk/verbs/table/%E9crire.html


