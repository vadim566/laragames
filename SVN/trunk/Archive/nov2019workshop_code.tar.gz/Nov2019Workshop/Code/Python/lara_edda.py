import lara_utils
import xml.etree.ElementTree as ET

##    import lara_edda
##    lara_edda = importlib.reload(lara_edda)
##    poems = lara_edda.get_poems()
##    first_poem = poems[0]
##    verses = lara_edda.get_verses_from_poem(first_poem)
##    first_verse = verses[0]
##    print(lara_edda.get_lara_form_from_verse(first_verse))

#edda_xml_file = '$LARA/Content/edda/corpus/Codex Regius 2019-03-28.xml'
edda_xml_file = '$LARA/Content/edda/corpus/Codex Regius 2019-03-28_v2.xml'
edda_xml_tree = None
edda_corpus_file = '$LARA/Content/edda/corpus/edda_converted.txt'

def convert_edda():
    poems = get_poems()
    converted_text = '\n\n'.join([get_lara_form_from_poem(poem) for poem in poems ])
    lara_utils.write_lara_text_file(converted_text, edda_corpus_file)

def get_poems():
    body = get_body()
    return [ child for child in body if child.tag == '{http://www.tei-c.org/ns/1.0}div' ]

def read_xml_file():
    global edda_xml_file
    global edda_xml_tree
    edda_xml_tree = ET.parse(lara_utils.absolute_file_name(edda_xml_file))
    lara_utils.print_and_flush(f'--- Read and internalised {edda_xml_file}')

def get_body():
    read_xml_file()
    root = edda_xml_tree.getroot()
    text = root[1]
    body = text[0]
    return body

def get_lara_form_from_poem(poem):
    title = get_title_from_poem(poem)
    verses = get_verses_from_poem(poem)
    verses_text = '\n\n'.join([ get_lara_form_from_verse(verse) for verse in verses ])
    return f'<h1>{title}||</h1>\n{verses_text}'

def get_title_from_poem(poem):
    if '{http://www.w3.org/XML/1998/namespace}id' in poem.attrib:
        return poem.attrib['{http://www.w3.org/XML/1998/namespace}id']
    else:
        return '??'

def get_verses_from_poem(poem):
    top_level_verses = [ verse for verse in poem
                         if verse.tag == '{http://www.tei-c.org/ns/1.0}lg' ]
    subpoem_verses = [ verse for subpoem in poem
                       if subpoem.tag == '{http://www.tei-c.org/ns/1.0}div'
                       for verse in subpoem
                       if verse.tag == '{http://www.tei-c.org/ns/1.0}lg' ]
    return top_level_verses + subpoem_verses

def get_lara_form_from_verse(verse):
    title = get_title_from_verse(verse)
    body_lines = get_lines_from_verse(verse)
    title_lines = [ f'/*{title}*/' ] if title else []
    return '\n'.join(title_lines + body_lines) + '||'

def get_title_from_verse(verse):
    if '{http://www.w3.org/XML/1998/namespace}id' in verse.attrib:
        return verse.attrib['{http://www.w3.org/XML/1998/namespace}id']
    else:
        return ''

def get_lines_from_verse(verse):
    return [ get_words_from_line(line) for line in verse if line.tag == '{http://www.tei-c.org/ns/1.0}l' ]

# Handle segs as well
def get_words_from_line(line):
    out = ''
    for component in line:
        lara_component = get_lara_form_from_line_component(component)
        if lara_component:
            ( word_or_punct, lara_text ) = lara_component
            if not lara_text:
                True
            elif out == '':
                out = lara_text
            elif word_or_punct in ( 'word', 'seg' ):
                out += f' {lara_text}'
            else:
                out += lara_text
    return out

def get_lara_form_from_line_component(component):
    if component.tag == '{http://www.tei-c.org/ns/1.0}seg':
        return ( 'seg', get_words_from_line(component) )
    elif component.tag == '{http://www.tei-c.org/ns/1.0}w':
        surface = get_surface_form_from_word(component)
        lemma = get_lemma_from_word(component)
        if not surface:
            return False
        if not lemma or surface == lemma and surface.islower():
            return ( 'word', surface )
        else:
            return ( 'word', f'{surface}#{lemma}#' )
    elif component.tag == '{http://www.menota.org/ns/1.0}punct':
        return ( 'punct', get_surface_form_from_word(component) )
    else:
        return False

def get_lemma_from_word(word):
    if 'lemma' in word.attrib:
        return word.attrib['lemma']
    else:
        return False

def get_surface_form_from_word(word):
    choices = get_choices_from_word(word)
    if choices:
        for choice in choices:
            if choice.tag == '{http://www.menota.org/ns/1.0}norm' and len(choice) > 0 and choice[0].text:
                return choice[0].text
            elif choice.tag == '{http://www.menota.org/ns/1.0}norm' and choice.text:
                return choice.text
    return False

def get_choices_from_word(word):
    for component in word:
        if component.tag == '{http://www.tei-c.org/ns/1.0}choice':
            return component
    return False

    
