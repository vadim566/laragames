
import lara_utils
import lara_top
import re
import copy

# --------------------------------------------------------

# Declarations

_language_ui_fallback = 'english'

# all fixed texts that are written to the HTML files should be routed through here
# (see function get_ui_text below)

ui_texts = {
    'english': {
        'toggle_translation_button' : 'toggle segment translations',
        'frequency_index': 'Frequency index',
        'alphabetical_index': 'Alphabetical index',
        'table_of_contents': 'Table of Contents',
        'index_heading_rank' : 'Rank', 
        'index_heading_word': 'Word', 
        'index_heading_freq': 'Freq', 
        'index_heading_cumul': 'Cumul',
        'next_page_title': 'next page',
        'prev_page_title': 'previous page',
        'first_page_title': 'first page',
        'set_bookmark': 'set bookmark',
        'goto_bookmark': 'go to bookmark',
        'unknown': '(unknown text id)'
    },
    'german': {
        'toggle_translation_button' : 'Übersetzungen umschalten',
        'frequency_index': 'Häufigkeitsindex',
        'alphabetical_index': 'Alphabetischer Index',
        'table_of_contents': 'Inhaltsverzeichnis',
        'index_heading_rank' : 'Rang', 
        'index_heading_word': 'Wort', 
        'index_heading_freq': 'Häufigk.', 
        'index_heading_cumul': 'kumuliert',
        'next_page_title': 'nächste Seite',
        'prev_page_title': 'vorherige Seite',
        'first_page_title': 'erste Seite',
        'set_bookmark': 'Lesez. setzen',
        'goto_bookmark': 'zu Lesez.',
        'unknown': '(unbekannte Textmarke)'
    },
    # TODO: same entries for other languages...
}

_permitted_bool_values = [ 'yes', 'no' ]
# Should allow uppercase and lowercase accented characters
_lara_id_pattern = '[A-Za-z\u00C0-\u017F][A-Za-z\u00C0-\u017F0-9_-]*'
_supported_mt_engines = [ 'google' ]

# Required = 'l'/'d' means for local/distributed
items_in_lara_local_config_data = {
        # ----- required items -----
		'id'                                : { 'required' : True,  'default' : '',    'pattern': _lara_id_pattern },
		'corpus'                            : { 'required' : False, 'default' : '',    'file_or_directory': True },
                'resource_file'                     : { 'required' : 'd',   'default' : '',    'file_or_directory': True },
                'reading_history'                   : { 'required' : 'd',   'default' : '',    },
        # ----- optional items -----
		'add_postags_to_lemma'              : { 'required' : False, 'default' : 'no',  'permitted' : _permitted_bool_values },
                'allow_bookmark'                    : { 'required' : False, 'default' : 'no',  'permitted' : _permitted_bool_values },
                'allow_table_of_contents'           : { 'required' : False, 'default' : 'no',  'permitted' : _permitted_bool_values },
		'audio_mouseover'                   : { 'required' : False, 'default' : 'no',  'permitted' : [ 'yes', 'both', 'no'] },
                'audio_segments'                    : { 'required' : False, 'default' : 'yes',  'permitted' : [ 'yes', 'no'] },
		'audio_tracking'                    : { 'required' : False, 'default' : None    }, # this is a dict by itself!
		'audio_words_in_colour'             : { 'required' : False, 'default' : 'no',  'permitted' : ['no', 'red'] },
		'author_name'                       : { 'required' : False, 'default' : '',    },
		'author_url'                        : { 'required' : False, 'default' : '',    },
		'author_email'                      : { 'required' : False, 'default' : '',    },
		'coloured_words'                    : { 'required' : False, 'default' : 'yes', 'permitted' : _permitted_bool_values },
                'compiled_directory'                : { 'required' : False, 'default' : '$LARA/compiled' },
		'comments_by_default'               : { 'required' : False, 'default' : 'no',  'permitted' : _permitted_bool_values },
		'css_file'                          : { 'required' : False, 'default' : '',    'file_or_directory': True },
		'script_file'                       : { 'required' : False, 'default' : '',    'file_or_directory': True },
		'extra_page_info'                   : { 'required' : False, 'default' : 'yes'      },
		'font'                              : { 'required' : False, 'default' : 'serif', 'permitted' : ['serif', 'sans-serif', 'monospace'] },
		'frequency_lists_in_main_text_page' : { 'required' : False, 'default' : 'no',  'permitted' : _permitted_bool_values },
		'hide_images'                       : { 'required' : False, 'default' : 'no',  'permitted' : _permitted_bool_values },
		'image_directory'                   : { 'required' : False, 'default' : '',    'file_or_directory': True},
		'keep_comments'                     : { 'required' : False, 'default' : 'no',  'permitted' : _permitted_bool_values },
                'l1'                                : { 'required' : False, 'default' : ''     },
		'language'                          : { 'required' : False, 'default' : ''     },
		'language_ui'                       : { 'required' : False, 'default' : _language_ui_fallback },
                'lara_tmp_directory'                : { 'required' : False, 'default' : '$LARA/tmp_resources' },
		'linguistics_article_comments'      : { 'required' : False, 'default' : 'no',  'permitted' : _permitted_bool_values },
                'lemma_dictionary_spreadsheet'      : { 'required' : False, 'default' : '',    'file_or_directory': True },
		'max_examples_per_word_page'        : { 'required' : False, 'default' : 10,   'integer' : True},
                'mt_engine'                         : { 'required' : False, 'default' : 'google',  'permitted' : _supported_mt_engines },
 		'postags_file'                      : { 'required' : False, 'default' : '',    'file_or_directory': True },
                'preferred_translator'              : { 'required' : False, 'default' : '',    },
                'preferred_voice'                   : { 'required' : False, 'default' : '',    },
		'segment_audio_directory'           : { 'required' : False, 'default' : '',    'file_or_directory': True },
		'segment_translation_mouseover'     : { 'required' : False, 'default' : 'yes', 'permitted' : _permitted_bool_values },
		'segment_translation_spreadsheet'   : { 'required' : False, 'default' : '',    'file_or_directory': True },
                'tagged_corpus'                     : { 'required' : False, 'default' : '',    'file_or_directory': True },
		'text_direction'                    : { 'required' : False, 'default' : 'ltr', 'permitted': ['rtl', 'ltr'] },
		'title'                             : { 'required' : False, 'default' : ''     },
		'toggle_translation_button'         : { 'required' : False, 'default' : 'no',  'permitted' : _permitted_bool_values },
		'translation_mouseover'             : { 'required' : False, 'default' : 'no',  'permitted' : _permitted_bool_values },
		'translation_spreadsheet'           : { 'required' : False, 'default' : '',    'file_or_directory': True },
                'unsegmented_corpus'                : { 'required' : False, 'default' : '',    'file_or_directory': True },
		'untagged_corpus'                   : { 'required' : False, 'default' : '',    'file_or_directory': True },
		'word_audio_directory'              : { 'required' : False, 'default' : '',    'file_or_directory': True },
                #'word_audio_voice'                  : { 'required' : False, 'default' : '' },
                'working_tmp_directory'             : { 'required' : False, 'default' : '$LARA/tmp' },
        # ----- for internal use -----
                'corpus_id'                         : { 'required' : False, 'default' : ''     },
		'local_files'                       : { 'required' : False, 'default' : 'no',  'permitted' : _permitted_bool_values, 'internal': True },
                'for_reading_portal'                : { 'required' : False, 'default' : 'no',  'permitted' : _permitted_bool_values, 'internal': True },
                'split_file'                        : { 'required' : False, 'default' : '',    'file_or_directory': True, 'internal': True },
                'count_file'                        : { 'required' : False, 'default' : '',    'file_or_directory': True, 'internal': True },
                'compile_cache_file'                : { 'required' : False, 'default' : '',    'file_or_directory': True, 'internal': True },
                'word_pages_directory'              : { 'required' : False, 'default' : '',    'file_or_directory': True, 'internal': True },
                'metadata_directory'                : { 'required' : False, 'default' : '',    'file_or_directory': True, 'internal': True },
		'css_file_for_page'                 : { 'required' : False, 'default' : '',    'file_or_directory': True, 'internal': True },
                'script_file_for_page'              : { 'required' : False, 'default' : '',    'file_or_directory': True, 'internal': True },
                'recompile'                         : { 'required' : False, 'default' : ''     },
                'write_word_pages_to_file'          : { 'required' : False, 'default' : 'yes', 'permitted' : _permitted_bool_values },
        }

right_to_left_languages = ['arabic',
                           'farsi',
                           'hebrew']

# --------------------------------------------------------

# Wrapper for dict() so that instead of Params["key"] you can now write Params.key
class LARAConfigDict(dict):
    def __init__(self, initialDict):
        super().__init__()
        for k,v in initialDict.items():
            self[k] = v 
            setattr(self, k, v)

def default_params():
    Dict = {}
    fill_in_missing_keys_and_values(Dict)
    return LARAConfigDict(Dict)

# Read the config data, check that it is consistent, and check/create env vars and directories

def read_lara_local_config_file_dont_check_directories(ConfigFile):
    return read_lara_config_file(ConfigFile, 'l', 'dont_check')

def read_lara_local_config_file(ConfigFile):
    return read_lara_config_file(ConfigFile, 'l', 'check')

def read_lara_distributed_config_file(ConfigFile):
    return read_lara_config_file(ConfigFile, 'd', 'check')

def read_lara_config_file(ConfigFile, LorD, CheckP):
    if not lara_utils.file_exists(ConfigFile):
        lara_utils.print_and_flush(f'*** Error: unable to find config file {ConfigFile}')
        return False
    if not lara_utils.extension_for_file(ConfigFile) == 'json':
        lara_utils.print_and_flush(f'*** Error: extension of config file {ConfigFile} has to be ".json"')
        return False
    Data = lara_utils.read_json_file(ConfigFile)
    if not Data:
        lara_utils.print_and_flush(f'*** Error: cannot internalise config file {ConfigFile}')
    OrigData = copy.copy(Data)
    if check_minimal_requirements_for_lara_local_config_data(Data, LorD):
        fill_in_missing_keys_and_values(Data)
        Params = LARAConfigDict(Data)
        if CheckP == 'dont_check' or check_environment_variables_and_working_directories(Params):
            return Params
        else:
            lara_utils.print_and_flush(f'*** Error: cannot internalise config file {ConfigFile}')
            lara_utils.print_and_flush(f'*** Error: contents {OrigData}')
            return False
    else:
        return False

def check_environment_variables_and_working_directories(Params):
    if not lara_utils.check_environment_variable_directory('LARA'):
        lara_utils.print_and_flush(f'*** Error: environment variable LARA not set')
        return False
    if not lara_utils.create_directory_if_it_doesnt_exist(Params.lara_tmp_directory):
        lara_utils.print_and_flush(f'*** Error: cannot create lara_tmp_directory {Params.lara_tmp_directory}')
        return False
    if not lara_utils.create_directory_if_it_doesnt_exist(Params.working_tmp_directory):
        lara_utils.print_and_flush(f'*** Error: cannot create working_tmp_directory {Params.working_tmp_directory}')
        return False
    if not lara_utils.create_directory_if_it_doesnt_exist(Params.compiled_directory):
        lara_utils.print_and_flush(f'*** Error: cannot create compiled_directory {Params.compiled_directory}')
        return False
    lara_utils.print_and_flush('--- Environment variables and working directories look okay')
    return True

def fill_in_missing_keys_and_values(Data):
    for key in items_in_lara_local_config_data.keys():
        if key in Data: continue
        Data[key] = items_in_lara_local_config_data[key]['default']

def check_minimal_requirements_for_lara_local_config_data(Data, LocalOrDistributed):
    return check_required_items(Data, LocalOrDistributed) and check_keys(Data) and check_values(Data)

def check_required_items(Data, LocalOrDistributed):
    MissingItems = [ Item for Item in items_in_lara_local_config_data if
                     items_in_lara_local_config_data[Item]['required'] in ( True, LocalOrDistributed ) and not Item in Data ]
    if len(MissingItems) == 0:
        return True
    else:
        lara_utils.print_and_flush(f'*** Error: config file does not define following keys: "{" ".join(MissingItems)}"')
        return False   

# Use this in lara_import_export to check whether there are any bad values in the data
def bad_values_in_config_data(Data):
    BadValuesFound = False
    UnknownKeys = [ Item for Item in Data if unknown_key(Item) ]
    if len(UnknownKeys) > 0:
        lara_utils.print_and_flush(f'*** Error: config file contains unknown or deprecated keys: "{" ".join(UnknownKeys)}"')
        BadValuesFound = True
    InvalidKeyValues = [ [Item, Data[Item] ] for Item in Data if invalid_value_for_key(Item, Data[Item]) ]
    if len(InvalidKeyValues) > 0:
        BadValuesFound = True
    return BadValuesFound

# Version for top-level call
def check_config_file_and_print(ConfigFile, LocalOrDistributed0, ReplyFile):
    try:
        Data = check_config_file(ConfigFile, LocalOrDistributed0)
    except:
        Data = { 'internal_error': 'yes' }
    lara_utils.write_json_to_file(Data, ReplyFile)

def check_config_file(ConfigFile, LocalOrDistributed0):
    if LocalOrDistributed0 == 'local':
        LocalOrDistributed = 'l'
    elif LocalOrDistributed0 == 'distributed':
        LocalOrDistributed = 'd'
    else:
        lara_utils.print_and_flush('*** Error: bad second argument {LocalOrDistributed0} to check_config_file. Needs to be "local" or "distributed"')
        return False                 
    if not lara_utils.file_exists(ConfigFile):
        return { 'status': 'bad', 'config_file_missing': 'yes' }
    Data = lara_utils.read_json_file(ConfigFile)
    if not Data:
        return { 'status': 'bad', 'config_file_unable_to_read': 'yes' }
    Feedback = { 'status': 'good' }
    UnknownKeys = [ Item for Item in Data if unknown_key(Item) ]
    if len(UnknownKeys) > 0:
        Feedback['unknown_keys'] = UnknownKeys
        Feedback['status'] = 'bad'
    InvalidKeyValues = [ [Item, Data[Item] ] for Item in Data if invalid_value_for_key(Item, Data[Item]) ]
    if len(InvalidKeyValues) > 0:
        Feedback['invalid_key_values'] = InvalidKeyValues
        Feedback['status'] = 'bad'
    MissingItems = [ Item for Item in items_in_lara_local_config_data if
                     items_in_lara_local_config_data[Item]['required'] in ( True, LocalOrDistributed ) and not Item in Data ]
    if len(MissingItems) > 0:
        Feedback['missing_items'] = MissingItems
        Feedback['status'] = 'bad'
    return Feedback

def check_keys(Data):
    UnknownKeys = [ Item for Item in Data if unknown_key(Item) ]
    if len(UnknownKeys) == 0:
        return True
    else:
        lara_utils.print_and_flush(f'*** Warning: config file contains unknown or deprecated keys: "{" ".join(UnknownKeys)}"')
        return True

def unknown_key(Key):
    return not Key in items_in_lara_local_config_data

def check_values(Data):
    InvalidKeyValues = [ [Item, Data[Item] ] for Item in Data if invalid_value_for_key(Item, Data[Item]) ]
    return len(InvalidKeyValues) == 0

def invalid_value_for_key(Key, Value):
    if not Key in items_in_lara_local_config_data: return False # allow unknown keys at this point!
    ConfigItem = items_in_lara_local_config_data[Key] 
    # check permitted values
    if 'permitted' in ConfigItem and not Value in ConfigItem['permitted']:
        lara_utils.print_and_flush(f'*** Error: invalid value "{Value}" for config file item "{Key}". Permitted values are {items_in_lara_local_config_data[Key]["permitted"]}')
        return True
    # match against pattern
    if 'pattern' in ConfigItem and not re.search(f'^({ConfigItem["pattern"]})$', str(Value)):
        lara_utils.print_and_flush(f'*** Error: invalid value "{Value}" for config file item "{Key}". Value must match this pattern: {ConfigItem["pattern"]}')
        return True
    # Check integer if required
    if 'integer' in ConfigItem and ConfigItem['integer'] and not isinstance(Value, int):
        lara_utils.print_and_flush(f'*** Error: invalid value "{Value}" for config file item "{Key}". Value must be an integer')
        return True
    # directory or file entries must not be empty            
    if not Value and 'file_or_directory' in ConfigItem and ConfigItem['file_or_directory']:
        lara_utils.print_and_flush(f'*** Error: unknown value "{Value}" for config file item "{Key}". Files or directories must not be empty')
        return True
    return False
                  
# --------------------------------------------------------

# Create config data for "distributed LARA" from reader data file and other sources

def right_to_left_language(L2):
    global right_to_left_languages
    return L2 in right_to_left_languages

def get_ui_text( id, Params ):
    Language = Params.language_ui
    if Language not in ui_texts or id not in ui_texts[Language]:
        Language = _language_ui_fallback
    if id not in ui_texts[Language]:
        lara_utils.print_and_flush( '*** warning: no translation found for {id} in UI texts' );
        return get_ui_text( 'unknown', Params )
    return ui_texts[Language][id]
