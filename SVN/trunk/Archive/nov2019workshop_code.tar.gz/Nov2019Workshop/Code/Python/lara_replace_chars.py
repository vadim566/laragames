
import lara_utils

_replace_chars_enabled = True
#_replace_chars_enabled = False

_replacements = { '#': '☩',
                  '<': '☾'
                  }

_inverse_replacements = { _replacements[Char]: Char for Char in _replacements }

_replacement_regex = lara_utils.make_multiple_replacement_regex(_replacements)

_restore_regex = lara_utils.make_multiple_replacement_regex(_inverse_replacements)

def replace_reserved_chars(Str):
    if not _replace_chars_enabled:
        return Str
    return lara_utils.apply_multiple_replacement_regex(_replacements, _replacement_regex, Str)

def restore_reserved_chars(Str):
    if not _replace_chars_enabled:
        return Str
    return lara_utils.apply_multiple_replacement_regex(_inverse_replacements, _restore_regex, Str)


