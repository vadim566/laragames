
# Data adapted from TreeTagger preprocessing script:
# French
# $PClitic = '[dcjlmnstDCJLNMST][\'’]|[Qq]u[\'’]|[Jj]usqu[\'’]|[Ll]orsqu[\'’]';
# $FClitic = '-t-elles?|-t-ils?|-t-on|-ce|-elles?|-ils?|-je|-la|-les?|-leur|-lui|-mmes?|-m[\'’]|-moi|-nous|-on|-toi|-tu|-t[\'’]|-vous|-en|-y|-ci|-l';
# English
# $FClitic = '[\'’](s|re|ve|d|m|em|ll)|n[\'’]t';
# Italian
# $PClitic = '[dD][ae]ll[\'’]|[nN]ell[\'’]|[Aa]ll[\'’]|[cClLDd][\'’]|[Ss]ull[\'’]|[Qq]uest[\'’]|[Uu]n[\'’]|[Ss]enz[\'’]|[Tt]utt[\'’]';

clitics = { ('english', 'post' ): {'APOSTROPHEs': 'be/have/s',
                                   'APOSTROPHEre': 'be',
                                   'APOSTROPHEve': 'have',
                                   'APOSTROPHEd': 'have/would',
                                   'APOSTROPHEm': 'be',
                                   'APOSTROPHEem': 'them',
                                   'APOSTROPHEll': 'will',
                                   'nAPOSTROPHEt': 'not'
                                   },
            ('italian', 'pre'): {'dAPOSTROPHE': 'di',
                                 'dalAPOSTROPHE': 'dalla',
                                 'delAPOSTROPHE': 'della',
                                 'cAPOSTROPHE': 'ci',
                                 'nellAPOSTROPHE': 'nella',
                                 'allAPOSTROPHE': 'alla',
                                 'lAPOSTROPHE': 'lo',
                                 'sullAPOSTROPHE': 'sulla',
                                 'questAPOSTROPHE': 'questo',
                                 'unAPOSTROPHE': 'uno',
                                 'senzAPOSTROPHE': 'senza',
                                 'tuttAPOSTROPHE': 'tutte'
                                },
            ('catalan', 'pre'): {'dAPOSTROPHE': 'de',
                                 'lAPOSTROPHE': 'el',
                                 'mAPOSTROPHE': 'mi',
                                 'nAPOSTROPHE': 'ne',
                                 'sAPOSTROPHE': 'si',
                                 'tAPOSTROPHE': 'tu',
                                 'quAPOSTROPHE': 'que'
                                },
            ('french', 'pre'): {'cAPOSTROPHE': 'ce',
                                'dAPOSTROPHE': 'de',
                                'jAPOSTROPHE': 'je',
                                'lAPOSTROPHE': 'le',
                                'mAPOSTROPHE': 'me',
                                'nAPOSTROPHE': 'ne',
                                'sAPOSTROPHE': 'se',
                                'tAPOSTROPHE': 'te',
                                'quAPOSTROPHE': 'que',
                                'jusquAPOSTROPHE': 'jusque',
                                'lorsquAPOSTROPHE': 'jusque',
                                },
            ('french', 'post'): {'HYPHENt-elles': 'ils',
                                 'HYPHENt-ils': 'ils',
                                 'HYPHENt-on': 'on',
                                 'HYPHENce': 'ce',
                                 'HYPHENils': 'ils',
                                 'HYPHENje': 'je',
                                 'HYPHENla': 'le',
                                 'HYPHENles': 'le',
                                 'HYPHENleur': 'le',
                                 'HYPHENlui': 'lui',
                                 'HYPHENmoi': 'moi',
                                 'HYPHENnous': 'nous',
                                 'HYPHENon': 'on',
                                 'HYPHENtoi': 'toi',
                                 'HYPHENtu': 'tu',
                                 'HYPHENvous': 'vous',
                                 'HYPHENen': 'en',
                                 'HYPHENy': 'y',
                                 'HYPHENci': 'ci'}
            }

internalised_clitics_cache = {}

apostrophes = "'’"

hyphens = "-"

def is_clitic(Word, Lang):
    PreClitics = internalised_clitics(Lang, 'pre')
    PostClitics = internalised_clitics(Lang, 'post')
    if Word in PreClitics:
        return ( PreClitics[Word], 'pre' )
    elif Word in PostClitics:
        return ( PostClitics[Word], 'post' )
    else:
        return ( False, False )

def internalised_clitics(Lang, PreOrPost):
    global clitics
    global internalised_clitics_cache
    if (Lang, PreOrPost) in internalised_clitics_cache:
        return internalised_clitics_cache[(Lang, PreOrPost)]
    if not ( Lang, PreOrPost ) in clitics:
        return []
    Orig = clitics[( Lang, PreOrPost )]  
    if PreOrPost == 'pre':
        Internalised = { maybe_capitalize(ExpandedClitic, YOrN): Orig[Clitic] for
                         Clitic in Orig for
                         ExpandedClitic in expand_word(Clitic) for
                         YOrN in ['yes', 'no'] for
                         Apostrophe in apostrophes }
    elif PreOrPost == 'post':
        Internalised = { ExpandedClitic : Orig[Clitic] for
                         Clitic in Orig for
                         ExpandedClitic in expand_word(Clitic) }
    internalised_clitics_cache[(Lang, PreOrPost)] = Internalised
    return Internalised

def expand_word(Clitic):
    if Clitic.find('APOSTROPHE') >= 0:
        return [ Clitic.replace('APOSTROPHE', Char) for Char in apostrophes ]
    elif Clitic.find('HYPHEN') >= 0:
        return [ Clitic.replace('HYPHEN', Char) for Char in hyphens ]
    else:
        return [ Clitic ]

def maybe_capitalize(Str, YOrN):
    return Str.capitalize() if YOrN == 'yes' else Str


