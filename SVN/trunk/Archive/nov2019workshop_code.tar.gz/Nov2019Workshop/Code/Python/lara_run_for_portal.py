
import lara_reading_portal
import lara_top
import lara_treetagger
import lara_add_metadata
import lara_config
import lara_audio
import lara_segment
import lara_merge_resources
import lara_download_resource
import lara_import_export
import lara_utils
import sys
import time

def print_usage():
    print(f'Usage: {lara_utils.python_executable()} $LARA/Code/Python/lara_run_for_portal.py <Mode> <ConfigFile>')
    print(f'       where <Mode> is "treetagger", "minimaltagger", "minimaltagger_spreadsheet", "resources", "word_pages" or "distributed"')
    print(f'or     {lara_utils.python_executable()} $LARA/Code/Python/lara_run_for_portal.py extract_css_img_and_audio_files <ConfigFile> <ResultFile>')
    print(f'or     {lara_utils.python_executable()} $LARA/Code/Python/lara_run_for_portal.py extract_css_img_and_audio_files_basic <CorpusFile> <ResultFile>')
    print(f'or     {lara_utils.python_executable()} $LARA/Code/Python/lara_run_for_portal.py install_ldt_zipfile <Zipfile> <RecordingScript> <Type> [ <ConfigFile> ]')
    print(f'       where <Type> is "words" or "segments"')
    print(f'or     {lara_utils.python_executable()} $LARA/Code/Python/lara_run_for_portal.py install_non_ldt_audio_zipfile <Zipfile> [ <ConfigFile> ]')
    print(f'or     {lara_utils.python_executable()} $LARA/Code/Python/lara_run_for_portal.py add_metadata <ResourcesDir> <Type>')
    print(f'       where <Type> is "corpus" or "language"')
    print(f'or     {lara_utils.python_executable()} $LARA/Code/Python/lara_run_for_portal.py audio_dir_to_mp3 <AudioDir> [ <ConfigFile> ]')
    print(f'or     {lara_utils.python_executable()} $LARA/Code/Python/lara_run_for_portal.py treetagger_basic <Language> <InFile> <OutFile>')
    print(f'or     {lara_utils.python_executable()} $LARA/Code/Python/lara_run_for_portal.py resources_basic <ConfigFile> <WordRecordingFile>')
    print('                                                        <SegmentRecordingFile> <WordTranslationCSV> <SegmentTranslationCSV>')
    print(f'or     {lara_utils.python_executable()} $LARA/Code/Python/lara_run_for_portal.py minimaltagger_spreadsheet_and_copy <ConfigFile> <SpreadsheetFile>')
    print(f'or     {lara_utils.python_executable()} $LARA/Code/Python/lara_run_for_portal.py segment_file <InFile> <OutFile>')
    print(f'or     {lara_utils.python_executable()} $LARA/Code/Python/lara_run_for_portal.py merge_language_resources <Dir1> <Dir2> <DirMerged> <ConfigFile>')
    print(f'or     {lara_utils.python_executable()} $LARA/Code/Python/lara_run_for_portal.py get_voices_and_l1s_for_resource <ResourceId> <ConfigFile> <ResultFile>')
    print(f'or     {lara_utils.python_executable()} $LARA/Code/Python/lara_run_for_portal.py get_voices_and_l1s_for_resource_file <ConfigFile> <ResultFile>')
    print(f'or     {lara_utils.python_executable()} $LARA/Code/Python/lara_run_for_portal.py count_audio_and_translation_files <ConfigFile> <ResultFile>')
    print(f'or     {lara_utils.python_executable()} $LARA/Code/Python/lara_run_for_portal.py check_config_file <ConfigFile> <Type> <ReplyFile>')
    print(f'       where <Type> is "local" or "distributed"')
    print(f'or     {lara_utils.python_executable()} $LARA/Code/Python/lara_run_for_portal.py download_resource <URL> <Dir>')
    print(f'or     {lara_utils.python_executable()} $LARA/Code/Python/lara_run_for_portal.py make_export_zipfile <SourceConfigFile> <TargetZipfile>')
    print(f'or     {lara_utils.python_executable()} $LARA/Code/Python/lara_run_for_portal.py import_zipfile <Zipfile> <CorpusDir> <LanguageRootDir> <ConfigFile>')
    print(f'or     {lara_utils.python_executable()} $LARA/Code/Python/lara_run_for_portal.py diff_tagged_corpus <OldTaggedCorpus> <ConfigFile> <Zipfile>')
    # Operations for reader portal
    print(f'or     {lara_utils.python_executable()} $LARA/Code/Python/lara_run_for_portal.py get_page_names_for_resource <ResourceId> <ConfigFile> <ReplyFile>')
    print(f'or     {lara_utils.python_executable()} $LARA/Code/Python/lara_run_for_portal.py compile_reading_history <ConfigFile> <ReplyFile>')
    print(f'or     {lara_utils.python_executable()} $LARA/Code/Python/lara_run_for_portal.py compile_next_page_in_history <ResourceId> <LanguageResourceId> <ConfigFile> <ReplyFile>')
    print(f'or     {lara_utils.python_executable()} $LARA/Code/Python/lara_run_for_portal.py clean_reading_portal_cache <ConfigFile>')

def get_config_file_from_args( Args, i = 0 ):
    return lara_top.find_config_file( False if len(Args) <= i else Args[i])

full_args = sys.argv
StartTime = time.time()
lara_utils.init_stored_timings()

if len(full_args) >= 2:
    ( Mode, Args, NArgs ) = ( full_args[1], full_args[2:], len(full_args[2:]) )
    if Mode == 'treetagger' and NArgs == 1:
        lara_top.treetag_untagged_corpus(Args[0])
    elif Mode == 'treetagger_basic' and NArgs == 3:
        Params = lara_config.default_params()
        Params.language = Args[0]
        lara_top.treetag_lara_file_main(Args[0], Args[1], Params, Args[2])
    elif Mode == 'minimaltagger' and NArgs <= 1:
        configFile = get_config_file_from_args(Args)
        if configFile: lara_top.minimal_tag_untagged_corpus(configFile)
    elif Mode == 'minimaltagger_spreadsheet' and NArgs <= 1:
        configFile = get_config_file_from_args(Args)
        if configFile: lara_top.lara_make_minimaltag_spreadsheet(configFile)
    elif Mode == 'minimaltagger_spreadsheet_and_copy' and NArgs == 2:
        configFile = get_config_file_from_args(Args)
        if configFile: lara_top.lara_make_minimaltag_spreadsheet_and_copy(configFile, Args[1])
    elif Mode == 'resources' and NArgs == 1:
        lara_top.compile_lara_local_resources(Args[0])
    elif Mode == 'resources_basic' and NArgs == 5:
        lara_top.compile_lara_local_resources_explicit(Args[0], Args[1], Args[2], Args[3], Args[4])
    elif Mode == 'extract_css_img_and_audio_files' and NArgs == 2:
        lara_top.find_css_img_and_audio_files(Args[0], Args[1])
    elif Mode == 'extract_css_img_and_audio_files_basic' and NArgs == 2:
        lara_top.find_css_img_and_audio_files_explicit(Args[0], Args[1])
    elif Mode == 'word_pages' and NArgs == 1:
        lara_top.compile_lara_local_word_pages(Args[0])
    elif Mode == 'add_metadata' and NArgs == 2:
        lara_add_metadata.add_metadata_to_lara_resource_directory(Args[0], Args[1])
    elif Mode == 'distributed' and NArgs == 1:
        lara_top.compile_lara_reading_history_from_config_file(Args[0])
    elif Mode == 'install_ldt_zipfile' and NArgs <= 4:
        configFile = get_config_file_from_args(Args, 3)
        if configFile: lara_top.install_audio_zipfile(Args[0], Args[1], Args[2], configFile)
    elif Mode == 'install_non_ldt_audio_zipfile' and NArgs <= 2:
        configFile = get_config_file_from_args(Args, 1)
        if configFile: lara_top.install_non_ldt_audio_zipfile(Args[0], configFile)
    elif Mode == 'count_audio_and_translation_files' and NArgs == 2:
        lara_top.count_audio_and_translation_files_and_print(Args[0], Args[1])
    elif Mode == 'check_config_file' and NArgs == 3:
        lara_config.check_config_file_and_print(Args[0], Args[1], Args[2])
    elif Mode == 'audio_dir_to_mp3' and NArgs <= 2:
        configFile = get_config_file_from_args(Args, 1)
        lara_audio.convert_lara_audio_directory_to_mp3_format(Args[0], configFile)
    elif Mode == 'segment_file' and NArgs == 2:
        lara_segment.segment_file(Args[0], Args[1])
    elif Mode == 'merge_language_resources' and NArgs == 4:
        lara_merge_resources.merge_language_resources(Args[0], Args[1], Args[2], Args[3])
    elif Mode == 'get_voices_and_l1s_for_resource' and NArgs == 3:
        lara_reading_portal.get_voices_and_l1s_for_resource_and_write(Args[0], Args[1], Args[2])
    elif Mode == 'get_voices_and_l1s_for_resource_file':
        lara_reading_portal.get_voices_and_l1s_for_resource_file_and_write(Args[0], Args[1])
    elif Mode == 'download_resource' and NArgs == 2:
        lara_download_resource.download_resource(Args[0], Args[1])
    elif Mode == 'unzip' and NArgs == 2:
        lara_utils.unzip_file(Args[0], Args[1])
    elif Mode == 'make_export_zipfile' and NArgs == 2:
        lara_import_export.make_export_zipfile(Args[0], Args[1])
    elif Mode == 'import_zipfile' and NArgs == 4:
        lara_import_export.import_zipfile(Args[0], Args[1], Args[2], Args[3])
    elif Mode == 'diff_tagged_corpus' and NArgs == 3:
        lara_top.diff_tagged_corpus(Args[0], Args[1], Args[2])  
    # Operations for reading portal
    elif Mode == 'get_page_names_for_resource' and NArgs == 3:
        lara_reading_portal.get_page_names_for_resource_and_write(Args[0], Args[1], Args[2])
    elif Mode == 'compile_reading_history' and NArgs == 2:
        lara_reading_portal.compile_reading_history(Args[0], Args[1])
    elif Mode == 'compile_next_page_in_history' and NArgs == 4:
        lara_reading_portal.compile_next_page_in_history_and_write(Args[0], Args[1], Args[2], Args[3])
    elif Mode =='clean_reading_portal_cache' and NArgs == 1:
        lara_reading_portal.clean_distributed_cache_data(Args[0])
    else:
        print_usage()
else:
    print_usage()

if StartTime is not None: 
    lara_utils.print_and_flush_with_elapsed_time('--- lara_run_for_portal command executed', StartTime)
lara_utils.print_stored_timings()


