
import lara_images
import lara_split_and_clean
import lara_audio
import lara_translations
import lara_config
import lara_utils
import lara_parse_utils
import time

def store_downloaded_metadata(MetaMetaData):
    lara_images.init_stored_downloaded_image_metadata()
    lara_audio.init_stored_downloaded_audio_metadata()
    lara_translations.init_stored_downloaded_translations_metadata()
    store_downloaded_metadata1(MetaMetaData)

def store_downloaded_metadata1(MetaMetaData):
    I = 0
    for MetaMetaDataItem in MetaMetaData:
        if store_downloaded_metadata_item(MetaMetaDataItem):
            I += 1
    lara_utils.print_and_flush(f'--- Stored content for {I} metadata files')

def store_downloaded_metadata_item(MetaMetaDataItem):
    ( CorpusOrLanguage, CorpusId, Type, URL, File ) = MetaMetaDataItem
    if not File or not URL or File == '*no_file*':
        return False
    elif CorpusOrLanguage == 'corpus' and Type == 'config':
        return False
    elif CorpusOrLanguage == 'corpus' and Type == 'corpus':
        return False
    elif CorpusOrLanguage == 'corpus' and Type == 'images':
        lara_images.store_downloaded_image_metadata(CorpusId, URL, File)
        return True
    elif CorpusOrLanguage == 'corpus' and isinstance(Type, list) and Type[0] == 'audio':
        Voice = Type[1]
        lara_audio.store_downloaded_audio_metadata('segments', Voice, CorpusId, URL, File)
        return True
    elif CorpusOrLanguage == 'language' and isinstance(Type, list) and Type[0] == 'audio':
        Voice = Type[1]
        lara_audio.store_downloaded_audio_metadata('words', Voice, CorpusId, URL, File)
        return True
    elif CorpusOrLanguage == 'corpus' and Type == 'translation':
        lara_translations.store_downloaded_segment_translations(CorpusId, File)
        return True
    elif CorpusOrLanguage == 'language' and Type == 'translation':
        lara_translations.store_downloaded_word_translations(CorpusId, File)
        return True

# -----------------------------------------------

# [ "peter_rabbit", "english_geneva", [ 1, 26 ] ],
# [ "alice_in_wonderland", "english_geneva", [ 1, 49 ] ]

def make_split_corpus_from_downloaded_metadata(ReadingHistory, MetaMetaData, SplitFile, ConfigData):
    if not ConfigData:
        lara_utils.print_and_flush('*** Error: cannot internalise corpus since unable to read config file')
        return False
    StartTime = time.time()
    FullSplitCorpusContent = make_split_corpus_from_downloaded_metadata1(ReadingHistory, MetaMetaData, ConfigData)
    lara_utils.print_and_flush('\n--------------------------------------~')
    lara_utils.print_and_flush('STATISTICS FOR COMBINED CORPUS')
    lara_split_and_clean.print_split_file_statistics(FullSplitCorpusContent)
    lara_utils.print_and_flush('\n--------------------------------------~')
    lara_utils.write_json_to_file(FullSplitCorpusContent, SplitFile)
    lara_utils.print_and_flush_with_elapsed_time(f'--- Written split corpus ({len(FullSplitCorpusContent)} segments) to {SplitFile}', StartTime)
    return True
 
def make_split_corpus_from_downloaded_metadata1(ReadingHistory, MetaMetaData, ConfigData):
    OutList = []
    for Item in ReadingHistory:
        OutList += make_split_corpus_from_downloaded_metadata2(Item, MetaMetaData, ConfigData)
    return OutList

def make_split_corpus_from_downloaded_metadata2(ReadingHistoryItem, MetaMetaData, ConfigData):
    if not valid_reading_history_item(ReadingHistoryItem):
        lara_utils.print_and_flush(f'*** Error: bad item {str(ReadingHistoryItem)} in reading history')
        return False
    ( CorpusId, LanguageId, Range ) = ReadingHistoryItem
    CachedTaggedPageOrientedSplitList = get_cached_downloaded_split_corpus(CorpusId, ConfigData)
    if CachedTaggedPageOrientedSplitList:
        TaggedPageOrientedSplitList = CachedTaggedPageOrientedSplitList
    else:
        ( ConfigFile, CorpusFile ) = ( False, False )
        for ( CorpusOrLanguage, OtherCorpusId, Type, URL, File ) in MetaMetaData:
            if ( CorpusOrLanguage, CorpusId, Type ) == ( 'corpus', OtherCorpusId, 'config' ):
                ConfigFile = File
            elif ( CorpusOrLanguage, CorpusId, Type ) == ( 'corpus', OtherCorpusId, 'corpus' ):
                CorpusFile = File
        if not ConfigFile:
            lara_utils.print_and_flush(f'*** Warning: no config file found for corpus ID {CorpusId}')
            return []
        if not CorpusFile:
            lara_utils.print_and_flush(f'*** Warning: no corpus file found for corpus ID {CorpusId}')
            return []
        Params = lara_config.read_lara_local_config_file_dont_check_directories(ConfigFile)
        # Use 'minimal' version since we probably aren't interested in getting trace feedback here
        #( PageOrientedSplitList, Trace ) = lara_split_and_clean.clean_lara_file_main(CorpusFile, Params)
        ( PageOrientedSplitList, Trace ) = lara_split_and_clean.clean_lara_file_main_minimal(CorpusFile, Params)
        Tag = { 'corpus': CorpusId, 'language': LanguageId,
                'word_audio_voice': get_word_audio_voice(Params),
                'css_file': Params.css_file, 'script_file': Params.script_file }
        TaggedPageOrientedSplitList = lara_split_and_clean.add_tags_to_chunks(PageOrientedSplitList, Tag)
        cache_downloaded_split_corpus(CorpusId, TaggedPageOrientedSplitList, ConfigData)
    return select_range_from_page_oriented_split_list(TaggedPageOrientedSplitList, Range)

# This assumes that the last component of the word_audio_directory will either be the name of the voice or 'audio' if there is none
def get_word_audio_voice(Params):
    if Params.word_audio_directory == '':
        return ''
    LastComponentInDir = Params.word_audio_directory.split('/')[-1]
    return LastComponentInDir if LastComponentInDir != 'audio' else ''   

def valid_reading_history_item(ReadingHistoryItem):
    return lara_utils.is_n_item_list(ReadingHistoryItem, 3) and \
           ReadingHistoryItem[2] == 'all' or lara_utils.is_n_item_list(ReadingHistoryItem[2], 2)

def select_range_from_page_oriented_split_list(List, Range):
    if Range == 'all':
        return List
    elif lara_utils.is_n_item_list(Range, 2) and type(Range[0]) == int and type(Range[1]) == int:
        return List[Range[0]-1:Range[1]]
    else:
        lara_utils.print_and_flush(f'*** Warning: bad range {Range} in reading history')
        return []

def cache_downloaded_split_corpus(CorpusId, TaggedPageOrientedSplitList, ConfigData):
    CacheFile = cache_file_for_downloaded_split_corpus(CorpusId, ConfigData)
    if CacheFile:
        lara_utils.save_data_to_pickled_gzipped_file(TaggedPageOrientedSplitList, CacheFile)

def get_cached_downloaded_split_corpus(CorpusId, ConfigData):
    CacheFile = cache_file_for_downloaded_split_corpus(CorpusId, ConfigData)
    if ConfigData.recompile != '' and CacheFile and lara_utils.file_exists(CacheFile):
        return lara_utils.get_data_from_pickled_gzipped_file(CacheFile)
    else:
        return False

def cache_file_for_downloaded_split_corpus(CorpusId, ConfigData):
    #( TmpDir, Recompile ) = ( ConfigData.metadata_directory, ConfigData.recompile )
    #return f'{TmpDir}/{CorpusId}_cached.data.gz' if TmpDir and Recompile else False
    ( TmpDir, ForReadingPortal ) = ( ConfigData.metadata_directory, ConfigData.for_reading_portal )
    return f'{TmpDir}/{CorpusId}_cached.data.gz' if TmpDir and ForReadingPortal == 'yes' else False




    
