
import lara
import lara_config
import lara_distributed
import lara_download_metadata
import lara_segment
import lara_treetagger
import lara_minimal_tag
import lara_split_and_clean
import lara_images
import lara_audio
import lara_translations
import lara_utils
import lara_parse_utils
import time

## Sample config files for testing
config_files = {'minimal': '$LARA/Content/minimal/corpus/local_config.json',
                'lorem_ipsum': '$LARA/Content/lorem_ipsum/corpus/local_config.json',
                'peter_rabbit': '$LARA/Content/peter_rabbit/corpus/local_config.json',
                'alice_in_wonderland': '$LARA/Content/alice_in_wonderland/corpus/local_config.json',
                'tina': '$LARA/Content/tina_fer_i_fri/corpus/local_config.json',
                'ungaretti': '$LARA/Content/ungaretti/corpus/local_config.json',
                'dante': '$LARA/Content/dante/corpus/local_config.json',
                'edda': '$LARA/Content/edda/corpus/local_config.json',
                'hyakumankai_ikita_neko': '$LARA/Content/hyakumankai_ikita_neko/corpus/local_config.json',
                'abba': '$LARA/Content/abba/corpus/local_config.json',
                'revivalistics': '$LARA/Content/revivalistics/corpus/local_config.json',
                'EbneSina': '$LARA/Content/EbneSina/corpus/local_config.json',
                'Choopan': '$LARA/Content/the_boy_who_cried_wolf/corpus/local_config.json',
                'Arash': '$LARA/Content/Arash/corpus/local_config.json',
                'bozboz_ghandi': '$LARA/Content/bozboz_ghandi/corpus/local_config.json',
                'molana': '$LARA/Content/molana/corpus/local_config.json',
                'le_petit_prince': '$LARA/Content/le_petit_prince_small/corpus/local_config.json',
                'mary': '$LARA/Content/mary_had_a_little_lamb/corpus/mary_had_a_little_lamb.json',
                'tex': '$LARA/Content/texs_french_course/corpus/local_config.json',
                'edward_lear': '$LARA/Content/edward_lear/corpus/local_config.json',
                'ogden_nash': '$LARA/Content/ogden_nash/corpus/local_config.json',
                'hur_gick_det_sen': '$LARA/Content/hur_gick_det_sen/corpus/local_config.json',
                'litli_prinsinn': '$LARA/Content/litli_prinsinn/corpus/local_config.json',
                'barngarla_alphabet': '$LARA/Content/barngarla_alphabet/corpus/local_config.json',
                'wilhelmbusch': '$LARA/Content/wilhelmbusch/corpus/wilhelmbusch.json',    
                'animal_farm': '$LARA/Content/animal_farm/corpus/local_config.json',
                'le_chien_jaune': '$LARA/Content/le_chien_jaune/corpus/local_config.json',
                'kallocaine': '$LARA/Content/kallocaine/corpus/local_config.json',
                'nasreddin_small': '$LARA/Content/turkish_toy/corpus/local_config.json',
                'genesis_icelandic': '$LARA/Content/sample_icelandic/corpus/local_config.json',
                # Distributed
                'reader1_english': '$LARA/Content/reader1_english/distributed_config.json',
                'reader1_english_small': '$LARA/Content/reader1_english/distributed_config_small.json',
                'reader1_german': '$LARA/Content/reader1_german/distributed_config_german.json',
                }

## Test functions
def lara_do_segment(Id):
    if Id in config_files:
        segment_unsegmented_corpus(config_files[Id])
    else:
        lara_utils.print_and_flush(f'*** Error: unknown ID: {Id}')

def lara_treetag(Id):
    if Id in config_files:
        treetag_untagged_corpus(config_files[Id])
    else:
        lara_utils.print_and_flush(f'*** Error: unknown ID: {Id}')

def lara_minimaltag_spreadsheet(Id):
    if Id in config_files:
        lara_make_minimaltag_spreadsheet(config_files[Id])
    else:
        lara_utils.print_and_flush(f'*** Error: unknown ID: {Id}')

def lara_minimaltag(Id):
    if Id in config_files:
        minimal_tag_untagged_corpus(config_files[Id])
    else:
        lara_utils.print_and_flush(f'*** Error: unknown ID: {Id}')

def lara_compile_local1(Id):
    if Id in config_files:
        compile_lara_local_resources(config_files[Id])
    else:
        lara_utils.print_and_flush(f'*** Error: unknown ID: {Id}')

def lara_compile_local2(Id):
    if Id in config_files:
        compile_lara_local_word_pages(config_files[Id])
    else:
        lara_utils.print_and_flush(f'*** Error: unknown ID: {Id}')

def lara_compile_distributed(Id):
    if Id in config_files:
        compile_lara_reading_history_from_config_file(config_files[Id])
    else:
        lara_utils.print_and_flush(f'*** Error: unknown ID: {Id}')

# --------------------------------------------------------

## TOP-LEVEL CALLS

def segment_unsegmented_corpus(ConfigFile):
    ConfigData = lara_config.read_lara_local_config_file(ConfigFile)
    if ConfigData:
        segment_unsegmented_corpus1(ConfigData)

# Treetag the untagged corpus file
def treetag_untagged_corpus(ConfigFile):
    ConfigData = lara_config.read_lara_local_config_file(ConfigFile)
    if ConfigData:
        treetag_untagged_corpus_file1(ConfigData)

# Create a "blank" minimaltag spreadsheet
def lara_make_minimaltag_spreadsheet(ConfigFile):
    ConfigData = lara_config.read_lara_local_config_file(ConfigFile)
    if ConfigData:
        compile_lara_local_make_lemma_dictionary_spreadsheet(ConfigData)

# Create a "blank" minimaltag spreadsheet and copy it to a designated location
def lara_make_minimaltag_spreadsheet_and_copy(ConfigFile, SpreadsheetFile):
    ConfigData = lara_config.read_lara_local_config_file(ConfigFile)
    if ConfigData:
        ResultFile = lara_tmp_file('lemma_dictionary_file', ConfigData)
        if compile_lara_local_make_lemma_dictionary_spreadsheet(ConfigData) and lara_utils.file_exists(ResultFile):
            lara_utils.copy_file(ResultFile, SpreadsheetFile)
            lara_utils.print_and_flush(f'--- Copied new version of lemma spreadsheet to {SpreadsheetFile}')

# Minimal-tag the untagged corpus file
def minimal_tag_untagged_corpus(ConfigFile):
    ConfigData = lara_config.read_lara_local_config_file(ConfigFile)
    if ConfigData:
        minimal_tag_untagged_corpus_file1(ConfigData)

# Treetag without using config file
def treetag_lara_file_main(Language, InFile, Params, OutFile):
    lara_treetagger.treetag_lara_file_main(Language, InFile, Params, OutFile)

# Local compile (i.e. all resources on local machine), part 1
def compile_lara_local_resources(ConfigFile):
    ConfigData = lara_config.read_lara_local_config_file(ConfigFile)
    if ConfigData:
        ConfigData.local_files = 'yes'
        compile_lara_local_resources1(ConfigData)

##def compile_lara_local_resources_full_only(ConfigFile):
##    ConfigData = lara_config.read_lara_local_config_file(ConfigFile)
##    if ConfigData:
##        compile_lara_local_resources_full_only1(ConfigData)

# Version for portal 
def compile_lara_local_resources_explicit(ConfigFile, WordRecordingFile, SegmentRecordingFile, WordCSV, SegmentCSV):
    Params = lara_config.read_lara_local_config_file(ConfigFile)
    compile_lara_local_resources(ConfigFile)
    FullWordCSV = lara_utils.get_tmp_csv_file(Params)
    copy_tmp_files_if_they_exist(ConfigFile,
                                 {'ldt_word_recording_file_full': WordRecordingFile,
                                  'ldt_segment_recording_file_full': SegmentRecordingFile,
                                  'tmp_translation_spreadsheet': FullWordCSV,
                                  'tmp_segment_translation_spreadsheet': SegmentCSV
                                  })
    lara_translations.make_current_only_csv(FullWordCSV, WordCSV)

##def compile_lara_local_resources_explicit_full(ConfigFile, FullWordRecordingFile, FullSegmentRecordingFile):
##    compile_lara_local_resources_full_only(ConfigFile)
##    copy_tmp_files_if_they_exist(ConfigFile,
##                                 {'ldt_word_recording_file_full': FullWordRecordingFile,
##                                  'ldt_segment_recording_file_full': FullSegmentRecordingFile
##                                  })

# Extract lists of CSS files, script files, img files and audio files used in a corpus file
# and write them out

def find_css_img_and_audio_files(ConfigFile, DataFile):
    ConfigData = lara_config.read_lara_local_config_file(ConfigFile)
    if ConfigData and 'corpus' in ConfigData:
        Data = lara_split_and_clean.extract_css_img_and_audio_files(ConfigData['corpus'], ConfigData)
        if ConfigData['css_file'] and  'css_files' in Data:
            Data['css_files'] += [ ConfigData['css_file'] ]
        if ConfigData['script_file']:
            Data['script_files'] = [ ConfigData['script_file'] ]
        else:
            Data['script_files'] = []
        lara_utils.write_json_to_file(Data, DataFile)                           

# Explicit version for portal: only extract img and audio files,
# since the rest of it needs to come from the config file, which won't exist yet
def find_css_img_and_audio_files_explicit(CorpusFile, DataFile):
    ConfigData = lara_config.default_params()
    Data = lara_split_and_clean.extract_css_img_and_audio_files(CorpusFile, ConfigData)
    Data['script_files'] = []
    lara_utils.write_json_to_file(Data, DataFile)                           
	
## After doing this, you will typically have to record on LDT, add translations, etc

# Local compile (i.e. all resources on local machine), part 2. Makes word pages
def compile_lara_local_word_pages(ConfigFile):
    ConfigData = lara_config.read_lara_local_config_file(ConfigFile)
    if ConfigData:
        compile_lara_local_word_pages1(ConfigData)

# Distributed compile (i.e. resources spread out on web)
#
# AllLARAResourcesFile   JSON file with URLs for resources
# ReaderDataFile         JSON file with reading progress and preferences for user
# DistributedConfigFile  JSON file with default config values for distributed LARA
# ReaderId               Which reader 
# L2                     Which L2
#
# Compile LARA pages for ReaderId's reading progress in L2
def compile_lara_reading_history_from_config_file(ConfigFile):
    ConfigData = lara_config.read_lara_distributed_config_file(ConfigFile)
    if ConfigData:
        return compile_lara_reading_history(ConfigData)
    else:
        return False

def compile_lara_reading_history(ConfigData):
	return compile_lara_reading_history1(ConfigData)

# Plain version for reading portal: recompile everything, but produce pages in reading portal format
def compile_lara_reading_history_for_portal(ConfigData):
	ConfigData.for_reading_portal = 'yes'
	return compile_lara_reading_history1(ConfigData)

# 'Recompile' version for reading portal: reuse cached data where possible

def recompile_lara_reading_history_for_portal(ConfigData, NewPage):
	ConfigData.for_reading_portal = 'yes'
	ConfigData.recompile = NewPage
	return compile_lara_reading_history1(ConfigData)

## Unpack word or segment audio zipfile from LDT, convert to mp3, and copy things into place
def install_audio_zipfile(Zipfile, RecordingScriptFile, WordsOrSegments, ConfigFile):
    Params = lara_config.read_lara_local_config_file(ConfigFile)
    ToDir = audio_dir_for_type(ConfigFile, WordsOrSegments)
    if not ToDir:
        lara_utils.print_and_flush(f'*** Error: unable to find "{WordsOrSegments}" audio dir for {ConfigFile}')
        return False
    if not lara_utils.file_exists(Zipfile):
        lara_utils.print_and_flush(f'*** Error: unable to find "{Zipfile}"')
        return False
    TmpDir = lara_utils.get_tmp_directory(Params)
    lara_utils.unzip_file(Zipfile, TmpDir)
    lara_utils.print_and_flush(f'Unzipped {Zipfile} to {TmpDir}')
    lara_audio.convert_lara_audio_directory_to_mp3_format(TmpDir, ConfigFile)
    ConvertedTmpDir = lara_audio.converted_mp3_dir_for_dir(TmpDir)
    if not lara_utils.directory_exists(ConvertedTmpDir):
        lara_utils.print_and_flush('*** Error: unable to find converted mp3 dir {ConvertedTmpDir}')
        return False
    install_audio_zipfile1(ConvertedTmpDir, RecordingScriptFile, ToDir)

## Unpack segment non-LDT audio zipfile, copy things into place and update metadata file
def install_non_ldt_audio_zipfile(Zipfile, ConfigFile):
    Params = lara_config.read_lara_local_config_file(ConfigFile)
    ToDir = audio_dir_for_type(ConfigFile, 'segments')
    if not ToDir:
        lara_utils.print_and_flush(f'*** Error: unable to find segments audio dir for {ConfigFile}')
        return False
    if not lara_utils.file_exists(Zipfile):
        lara_utils.print_and_flush(f'*** Error: unable to find "{Zipfile}"')
        return False
    TmpDir = lara_utils.get_tmp_directory(Params)
    lara_utils.unzip_file(Zipfile, TmpDir)
    lara_utils.print_and_flush(f'Unzipped {Zipfile} to {TmpDir}')
    if not lara_utils.directory_exists(TmpDir):
        lara_utils.print_and_flush(f'*** Error: unable to find unzipped dir {TmpDir}')
        return False
    install_non_ldt_audio_zipfile1(TmpDir, ToDir)

# --------------------------------------------------------

def count_audio_and_translation_files_and_print(ConfigFile, AnswerFile):
    lara_utils.write_json_to_file(count_audio_and_translation_files(ConfigFile), AnswerFile)

def count_audio_and_translation_files(ConfigFile):
    Params = lara_config.read_lara_local_config_file(ConfigFile)
    if not Params:
        return False
    if Params.corpus == '':
        lara_utils.print_and_flush(f'*** Error: unable to internalise corpus data since "corpus" not defined in {ConfigFile}')
        return False
    return count_audio_and_translation_files_for_params(Params)

def count_audio_and_translation_files_for_params(Params):
    Params.split_file = lara_tmp_file('split', Params)
    AudioData = lara_audio.count_recorded_files(Params)
    TransData = lara_translations.count_translations(Params)
    if not AudioData or not isinstance(AudioData, dict) or \
       not 'words' in AudioData or not 'recorded' in AudioData['words'] or not 'not_recorded' in AudioData['words'] or \
       not 'segments' in AudioData or not 'recorded' in AudioData['segments'] or not 'not_recorded' in AudioData['segments']:
        lara_utils.print_and_flush(f'*** Error: malformed response from lara_audio.count_recorded_files')
        lara_utils.prettyprint(AudioData)
        return False
    if not TransData or not isinstance(TransData, dict) or \
       not 'words' in TransData or not 'translated' in TransData['words'] or not 'not_translated' in TransData['words'] or \
       not 'segments' in TransData or not 'translated' in TransData['segments'] or not 'not_translated' in TransData['segments']:
        lara_utils.print_and_flush(f'*** Error: malformed response from lara_translations.count_translations')
        lara_utils.prettyprint(TransData)
        return False
    return {'words': {'recorded': AudioData['words']['recorded'],
                      'not_recorded': AudioData['words']['not_recorded'],
                      'translated': TransData['words']['translated'],
                      'not_translated': TransData['words']['not_translated']
                      },
            'segments': {'recorded': AudioData['segments']['recorded'],
                         'not_recorded': AudioData['segments']['not_recorded'],
                         'translated': TransData['segments']['translated'],
                         'not_translated': TransData['segments']['not_translated']
                      }
            }

# --------------------------------------------------------

def segment_unsegmented_corpus1(ConfigData):
    if ConfigData.unsegmented_corpus != '':
        UnsegmentedCorpusFile = ConfigData.unsegmented_corpus        
    else:
        lara_utils.print_and_flush(f'*** Error: "unsegmented_corpus" not defined in config data')
        return False
    if not lara_utils.file_exists(UnsegmentedCorpusFile):
        lara_utils.print_and_flush(f'*** Error: unable to find unsegmented corpus file {UnsegmentedCorpusFile}')
        return False
    if ConfigData.untagged_corpus != '':
        UntaggedCorpusFile = ConfigData.untagged_corpus        
    else:
        lara_utils.print_and_flush('*** Error: "untagged_corpus" not defined in config data')
        return False
    lara_segment.segment_file(UnsegmentedCorpusFile, UntaggedCorpusFile)

# --------------------------------------------------------

## Do a structured diff between the corpus file that ConfigFile points to and an earlier version OldTaggedFile,
## and write everything out as Zipfile
def diff_tagged_corpus(OldTaggedFile, ConfigFile, Zipfile):
    import lara_compare_split_files
    Params = lara_config.read_lara_local_config_file(ConfigFile)
    if not Params:
        return False
    OldConfigFile = make_config_file_with_variant_corpus(ConfigFile, OldTaggedFile, Params)
    if not OldConfigFile:
        return False
    OldSplitFile = make_split_file(OldConfigFile)
    CurrentSplitFile = make_split_file(ConfigFile)
    if not OldSplitFile or not CurrentSplitFile:
        return False
    TmpDir = lara_utils.get_tmp_directory(Params)
    SurfaceDiffFile = f'{TmpDir}/surface_diff.txt'
    LemmaDiffFile = f'{TmpDir}/lemma_diff.txt'
    SurfaceAndLemmaDiffFile = f'{TmpDir}/surface_and_lemma_diff.txt'
    SummaryFile = f'{TmpDir}/summary.json'
    SurfaceChanged = lara_compare_split_files.split_files_diff(OldSplitFile, CurrentSplitFile, 'surface', SurfaceDiffFile)
    LemmaChanged = lara_compare_split_files.split_files_diff(OldSplitFile, CurrentSplitFile, 'lemma', LemmaDiffFile)
    lara_compare_split_files.split_files_diff(OldSplitFile, CurrentSplitFile, 'surface_and_lemma', SurfaceAndLemmaDiffFile)
    Summary = {'surface_changed': SurfaceChanged, 'lemma_changed': LemmaChanged}
    lara_utils.write_json_to_file(Summary, SummaryFile)
    lara_utils.make_zipfile(TmpDir, Zipfile)
    lara_utils.delete_file_if_it_exists(OldConfigFile)
    lara_utils.delete_directory_if_it_exists(TmpDir)
    lara_utils.print_and_flush(f'\nSUMMARY\n')
    lara_utils.print_and_flush(f'Surface words changed: {SurfaceChanged}')
    lara_utils.print_and_flush(f'Lemmas changed:        {LemmaChanged}')
    lara_utils.print_and_flush(f'Full details:          {Zipfile}')
    return True

def make_config_file_with_variant_corpus(ConfigFile, OldTaggedFile, Params):
    Content = lara_utils.read_json_file(ConfigFile)
    if not 'id' in Content:
        return False
    Id = Content['id']
    Content['id'] = f'{Id}_old'
    Content['corpus'] = OldTaggedFile
    VariantConfigFile = lara_utils.get_tmp_file_with_extension(Params, 'json')
    lara_utils.write_json_to_file(Content, VariantConfigFile)
    return VariantConfigFile
    

def make_split_file(ConfigFile):
    Params = lara_config.read_lara_local_config_file(ConfigFile)
    if not Params:
        return False
    if not compile_lara_local_clean(Params):
        return False
    SplitFile = lara_tmp_file('split', Params)
    if SplitFile and lara_utils.file_exists(SplitFile):
        return SplitFile
    else:
        return False

# --------------------------------------------------------

def treetag_untagged_corpus_file1(ConfigData):
    tag_untagged_corpus_file1(ConfigData, 'treetag')

def minimal_tag_untagged_corpus_file1(ConfigData):
    tag_untagged_corpus_file1(ConfigData, 'minimal_tag')

def tag_untagged_corpus_file1(ConfigData, Mode):
    if  ConfigData.language:
        Language = ConfigData.language
    else:
        lara_utils.print_and_flush('*** Error: "language" not defined in config data')
        return False
    if ConfigData.untagged_corpus:
        UntaggedCorpusFile = lara_config_file('untagged_corpus', ConfigData)        
    else:
        lara_utils.print_and_flush('*** Error: "untagged_corpus" not defined in config data')
        return False
    if ConfigData.tagged_corpus:
        TaggedCorpusFile = lara_config_file('tagged_corpus', ConfigData)
    else:
        TaggedCorpusFile = lara_config_file('corpus', ConfigData)
    if Mode == 'treetag':
        lara_treetagger.treetag_lara_file_main(Language, UntaggedCorpusFile, ConfigData, TaggedCorpusFile)
    elif Mode == 'minimal_tag':
        lara_minimal_tag.minimal_tag_lara_file_main(UntaggedCorpusFile, ConfigData, TaggedCorpusFile)
    else:
        lara_utils.print_and_flush(f'*** Error: unknown tagging mode {Mode}')

# --------------------------------------------------------    

def compile_lara_local_resources1(ConfigData):
    CleanOK = compile_lara_local_clean(ConfigData)
    if CleanOK:
        compile_lara_local_count_file(ConfigData)
        # Do this as a separate step 
        #compile_lara_local_make_lemma_dictionary_spreadsheet(ConfigData)
        compile_lara_local_make_segment_recording_file(ConfigData)
        compile_lara_local_make_word_recording_file(ConfigData)
        compile_lara_local_make_translation_spreadsheet(ConfigData)
        compile_lara_local_make_segment_translation_spreadsheet(ConfigData)
    else:
        lara_utils.print_and_flush('*** Error: something went wrong when reading corpus file')

##def compile_lara_local_resources_full_only1(ConfigData):
##    CleanOK = compile_lara_local_clean(ConfigData)
##    if CleanOK:
##        compile_lara_local_count_file(ConfigData)
##        compile_lara_local_make_segment_and_word_recording_files_full(ConfigData)

def compile_lara_local_word_pages1(ConfigData):
    compile_lara_local_make_word_pages(ConfigData)

def compile_lara_reading_history1(ConfigData):
    # Create an empty word pages directory, where the results will go
    compile_lara_reading_history_initialise_word_pages_dir(ConfigData)
    # Call Python to download the metadata (audio, images, translations) and also the corpora
    MetaMetaData = compile_lara_reading_history_download_metadata(ConfigData)
    if not MetaMetaData:
        return False
    # Store the downloaded metadata so that we can use it later
    compile_lara_reading_history_store_metadata(MetaMetaData)
    # Combine the downloaded corpus metadata into a single corpus that's split into segments
    CorpusOK = compile_lara_reading_history_make_split_corpus(ConfigData, MetaMetaData)
    if not CorpusOK:
        return False
    # Get some frequency statistics and save them
    compile_lara_reading_history_count_file(ConfigData)
    # And finally, build the web pages and return the result
    return compile_lara_reading_history_make_word_pages(ConfigData)

# --------------------------------------------------------

def delete_metadata_directory(ConfigFile):
    ConfigData = lara_config.read_lara_distributed_config_file(ConfigFile)
    TmpMetadataDir = lara_tmp_dir('metadata_dir', ConfigData)
    lara_utils.delete_directory_if_it_exists(TmpMetadataDir)

# --------------------------------------------------------

def compile_lara_reading_history_initialise_word_pages_dir(ConfigData):
    WordPagesDir = lara_compiled_dir('word_pages_directory', ConfigData)
    if ConfigData.recompile:
        # If we're recompiling, try to use the existing directory 
        lara_utils.create_directory_if_it_doesnt_exist(WordPagesDir)
    else:
        # If we're compiling, create a new directory directory 
        lara_utils.create_directory_deleting_old_if_necessary(WordPagesDir)        

def compile_lara_reading_history_download_metadata(ConfigData):
    ResourcesFile = ConfigData.resource_file
    ReadingHistory = ConfigData.reading_history
    TmpMetadataDir = lara_tmp_dir('metadata_dir', ConfigData)
    ConfigData.metadata_directory = TmpMetadataDir
    if ConfigData.recompile:
        # If we're recompiling, try to use the existing directory 
        lara_utils.create_directory_if_it_doesnt_exist(TmpMetadataDir)
    else:
        # If we're compiling, create a new directory  
        lara_utils.create_directory_deleting_old_if_necessary(TmpMetadataDir)    
    lara_download_metadata.download_metadata(ResourcesFile, ReadingHistory, ConfigData)
    return get_metametadata(TmpMetadataDir)

def get_metametadata(TmpDir):
    File = metametadata_file_in_tmp_directory(TmpDir)
    if lara_utils.file_exists(File):
        MetaMetaData = lara_utils.read_json_file(File)
        lara_utils.print_and_flush(f'--- Read metametadata from {File}')
        return MetaMetaData
    else:
        lara_utils.print_and_flush(f'*** Error: unable to find metametadata file {File}')
        return False                      
                                   
def metametadata_file_in_tmp_directory(TmpDir):
    return f'{TmpDir}/metametadata.json'

def compile_lara_reading_history_store_metadata(MetaMetaData):
    lara_distributed.store_downloaded_metadata(MetaMetaData)

# --------------------------------------------------------

def download_resource(ResourceId, ResourcesFile, TargetDir):
    ResourceData = lara_utils.read_json_file(ResourcesFile)
    if not ResourceData:
        return False
    if not ResourceId in ResourceData:
        lara_utils.print_and_flush(f'*** Error: {ResourceId} is not defined in {ResourcesFile}')
        return False
    URL = ResourceData[ResourceId][0]
    lara_download_resource.download_resource(URL, TargetDir)

# --------------------------------------------------------

def audio_dir_for_type(ConfigFile, WordsOrSegments):
    if not WordsOrSegments in ('words', 'segments'):
        lara_utils.print_and_flush(f'*** Error: bad second arg "{WordsOrSegments}" to audio_dir_for_type')
        return False
    ConfigData = lara_config.read_lara_local_config_file(ConfigFile)
    if not ConfigData:
        lara_utils.print_and_flush(f'*** Error: unable to read config file "{ConfigFile}"')
        return False
    if WordsOrSegments == 'words' and 'word_audio_directory' in ConfigData:
        return ConfigData['word_audio_directory']
    elif WordsOrSegments == 'segments' and 'segment_audio_directory' in ConfigData:
        return ConfigData['segment_audio_directory']

# Version for non-LDT audio files
# Copy over all files and either update metadata file or create a new one if necessary
def install_audio_zipfile1(ConvertedTmpDir, RecordingScriptFile, ToDir):
    NMP3Files = len(lara_utils.files_with_given_extension_in_directory(ConvertedTmpDir, 'mp3'))
    MetadataFile = f'{ConvertedTmpDir}/metadata_help.txt'
    if NMP3Files == 0:
        lara_utils.print_and_flush(f'*** Warning: no MP3 files found in {ConvertedTmpDir}')
        return True
    if not lara_utils.file_exists(MetadataFile):
        lara_utils.print_and_flush(f'*** Error: metadata file {MetadataFile} not found')
        return False
    lara_utils.create_directory_if_it_doesnt_exist(ToDir)
    lara_utils.copy_directory_one_file_at_a_time(ConvertedTmpDir, ToDir, ['mp3'])
    ToMetadataFile = f'{ToDir}/metadata_help.txt'
    if not lara_utils.file_exists(ToMetadataFile):
        lara_utils.copy_file(MetadataFile, ToMetadataFile)
        lara_utils.print_and_flush(f'--- Copied metadata file from {ConvertedTmpDir} to {ToDir}')
    else:
        OldMetadata = lara_utils.read_lara_text_file(ToMetadataFile)
        NewMetadata = lara_utils.read_lara_text_file(MetadataFile)
        UpdatedMetadata = OldMetadata + '\n' + NewMetadata
        lara_utils.write_unicode_text_file(UpdatedMetadata, ToMetadataFile)
        lara_utils.print_and_flush(f'--- Updated metadata file {ToMetadataFile} from {MetadataFile}')
    print_information_about_missing_ldt_files(RecordingScriptFile, MetadataFile)
    return True

def print_information_about_missing_ldt_files(RecordingScriptFile, MetadataFile):
    try:
        RecordingTexts = texts_in_ldt_recording_script(RecordingScriptFile)
        MetadataTexts = texts_in_ldt_metadata_file(MetadataFile)
        if RecordingTexts != False and MetadataTexts != False:
            NMissing = len([Text for Text in RecordingTexts if
                            len(Text)> 0 and not Text.isspace() and not Text in MetadataTexts])
            lara_utils.print_and_flush(f'--- {NMissing} recorded files missing.')
        else:
            lara_utils.print_and_flush(f'*** Warning: unable to calculate number of missing files')
    except:
        lara_utils.print_and_flush(f'*** Warning: unable to calculate number of missing files')
 
def texts_in_ldt_recording_script(File):
    Lines = lara_utils.read_unicode_text_file_to_lines(File)
    if not Lines:
        lara_utils.print_and_flush(f'*** Warning: unable to read LDT recording script {File}')
        return False
    RecordingTexts = lara_utils.non_false_members([ text_from_recording_script_line(Line) for Line in Lines ])
    lara_utils.print_and_flush(f'--- Found {len(RecordingTexts)} texts to record')
    return RecordingTexts

def texts_in_ldt_metadata_file(File):
    Lines = lara_utils.read_unicode_text_file_to_lines(File)
    if not Lines:
        lara_utils.print_and_flush(f'*** Warning: unable to read LDT metadata file {File}')
        return False
    MetadataTexts = lara_utils.non_false_members([ text_from_ldt_metadata_line(Line) for Line in Lines ])
    lara_utils.print_and_flush(f'--- Found {len(MetadataTexts)} recorded audio files')
    return MetadataTexts

def text_from_ldt_metadata_line(Line):
    Result = lara_parse_utils.parse_ldt_metadata_file_ldt_line(Line)
    return Result[1] if Result else False

def text_from_recording_script_line(Line):
    return lara_parse_utils.parse_ldt_recording_script_line(Line)

# Copy over all the converted MP3s. If there isn't a metadata file already, copy that over too.
# If there is one, update it.
# Typical metadata entry looks like this:
# NonLDTAudioFile inferno_i_1-12.mp3
def install_non_ldt_audio_zipfile1(TmpDir, AudioDir):
    AudioFiles = lara_utils.directory_files(TmpDir)
    NAudioFiles = len(AudioFiles)
    if NAudioFiles == 0:
        lara_utils.print_and_flush(f'*** Warning: no files found in {TmpDir}')
        return True
    lara_utils.create_directory_if_it_doesnt_exist(AudioDir)
    lara_utils.copy_directory_one_file_at_a_time(TmpDir, AudioDir, 'all')
    ToMetadataFile = f'{AudioDir}/metadata_help.txt'
    OldMetadata = [] if not lara_utils.file_exists(ToMetadataFile) else lara_utils.read_unicode_text_file_to_lines(ToMetadataFile)
    NewMetadata = [ f'NonLDTAudioFile {File}' for File in AudioFiles ]
    AllMetadata = lara_utils.remove_duplicates(OldMetadata + NewMetadata)      
    lara_utils.write_unicode_text_file('\n'.join(AllMetadata), ToMetadataFile)
    lara_utils.print_and_flush(f'--- Written metadata file {ToMetadataFile}')
    return True

# --------------------------------------------------------

def compile_lara_local_clean(ConfigData):
    CorpusFile = lara_config_file('corpus', ConfigData)
    SplitFile = lara_tmp_file('split', ConfigData)
    TaggingFeedbackFile = lara_tmp_file('tagging_feedback', ConfigData)
    return lara_split_and_clean.clean_lara_file(CorpusFile, ConfigData, SplitFile, TaggingFeedbackFile)

def compile_lara_reading_history_make_split_corpus(ConfigData, MetaMetaData):
    ReadingHistory = ConfigData.reading_history
    SplitFile = lara_tmp_file('split', ConfigData)
    return lara_distributed.make_split_corpus_from_downloaded_metadata(ReadingHistory, MetaMetaData, SplitFile, ConfigData)

# --------------------------------------------------------

def compile_lara_local_count_file(ConfigData):
    SplitFile = lara_tmp_file('split', ConfigData)
    CountFile = lara_tmp_file('count', ConfigData)
    lara.count_file(SplitFile, CountFile, ConfigData)

def compile_lara_reading_history_count_file(ConfigData):
    compile_lara_local_count_file(ConfigData)

# --------------------------------------------------------

def compile_lara_local_make_lemma_dictionary_spreadsheet(ConfigData):
    if ConfigData.lemma_dictionary_spreadsheet != '' and ConfigData.untagged_corpus != '':
        UntaggedCorpusFile = ConfigData.untagged_corpus
        LemmaFile = lara_tmp_file('lemma_dictionary_file', ConfigData)
        return lara_minimal_tag.make_lemma_dictionary_file(UntaggedCorpusFile, LemmaFile, ConfigData)
    else:
        return False
    
# --------------------------------------------------------
    
def compile_lara_local_make_segment_recording_file(ConfigData):
    if 'segment_audio_directory' in ConfigData:
        SplitFile = lara_tmp_file('split', ConfigData)
        LDTFile = lara_tmp_file('ldt_segment_recording_file', ConfigData)
        lara_audio.make_recording_file(SplitFile, LDTFile, 'new_only', ConfigData)
        LDTFileFull = lara_tmp_file('ldt_segment_recording_file_full', ConfigData)
        lara_audio.make_recording_file(SplitFile, LDTFileFull, 'full', ConfigData)

##def compile_lara_local_make_segment_recording_file(ConfigData):
##    if 'segment_audio_directory' in ConfigData:
##        SplitFile = lara_tmp_file('split', ConfigData)
##        LDTFile = lara_tmp_file('ldt_segment_recording_file', ConfigData)
##        lara_audio.make_recording_file(SplitFile, LDTFile, 'full', ConfigData)

# --------------------------------------------------------
    
def compile_lara_local_make_word_recording_file(ConfigData):
    if 'word_audio_directory' in ConfigData:
        SplitFile = lara_tmp_file('split', ConfigData)
        LDTFile = lara_tmp_file('ldt_word_recording_file', ConfigData)
        lara_audio.make_word_recording_file(SplitFile, LDTFile, 'new_only', ConfigData)
        LDTFileFull = lara_tmp_file('ldt_word_recording_file_full', ConfigData)
        lara_audio.make_word_recording_file(SplitFile, LDTFileFull, 'full', ConfigData)

##def compile_lara_local_make_word_recording_file(ConfigData):
##    if 'word_audio_directory' in ConfigData:
##        SplitFile = lara_tmp_file('split', ConfigData)
##        LDTFile = lara_tmp_file('ldt_word_recording_file', ConfigData)
##        lara_audio.make_word_recording_file(SplitFile, LDTFile, 'full', ConfigData)

# --------------------------------------------------------

##def compile_lara_local_make_segment_and_word_recording_files_full(ConfigData):
##    if 'segment_audio_directory' in ConfigData:
##        SplitFile = lara_tmp_file('split', ConfigData)
##        LDTFileFull = lara_tmp_file('ldt_segment_recording_file_full', ConfigData)
##        lara_audio.make_recording_file(SplitFile, LDTFileFull, 'full', ConfigData)
##    if 'word_audio_directory' in ConfigData:
##        SplitFile = lara_tmp_file('split', ConfigData)
##        LDTFileFull = lara_tmp_file('ldt_word_recording_file_full', ConfigData)
##        lara_audio.make_word_recording_file(SplitFile, LDTFileFull, 'full', ConfigData)
    
# --------------------------------------------------------
    
def compile_lara_local_make_translation_spreadsheet(ConfigData):
    if ConfigData.translation_spreadsheet != '':
        SplitFile = lara_tmp_file('split', ConfigData)
        #TranslationFile = lara_config_file('translation_spreadsheet', ConfigData)
        TmpTranslationFile = lara_tmp_file('tmp_translation_spreadsheet', ConfigData)
        lara_translations.make_translation_spreadsheet(SplitFile, TmpTranslationFile, ConfigData)

# --------------------------------------------------------
    
def compile_lara_local_make_segment_translation_spreadsheet(ConfigData):
    if ConfigData.segment_translation_spreadsheet != '':
        SplitFile = lara_tmp_file('split', ConfigData)
        #TranslationFile = lara_config_file('segment_translation_spreadsheet', ConfigData)
        TmpTranslationFile = lara_tmp_file('tmp_segment_translation_spreadsheet', ConfigData)
        lara_translations.make_segment_translation_spreadsheet(SplitFile, TmpTranslationFile, ConfigData)

# --------------------------------------------------------

def compile_lara_local_make_word_pages(ConfigData):
    SplitFile = lara_tmp_file('split', ConfigData)
    CountFile = lara_tmp_file('count', ConfigData)
    WordPageDir = lara_compiled_dir('word_pages_directory', ConfigData)
    ConfigData.local_files = 'yes'
    ConfigData.split_file = SplitFile
    ConfigData.count_file = CountFile
    ConfigData.word_pages_directory = WordPageDir
    lara.make_word_pages(ConfigData)
    
# --------------------------------------------------------

def compile_lara_reading_history_make_word_pages(ConfigData):
    SplitFile = lara_tmp_file('split', ConfigData)
    CountFile = lara_tmp_file('count', ConfigData)
    CompileCacheFile = lara_tmp_file('compile_cache', ConfigData)
    WordPageDir = lara_compiled_dir('word_pages_directory', ConfigData)
    ConfigData.split_file = SplitFile
    ConfigData.count_file = CountFile
    ConfigData.compile_cache_file = CompileCacheFile
    ConfigData.word_pages_directory = WordPageDir
    return lara.make_word_pages(ConfigData)

# --------------------------------------------------------

def copy_tmp_files_if_they_exist(ConfigFile, Dict):
    lara_utils.print_and_flush('--- COPYING GENERATED RESOURCE FILES')
    ConfigData = lara_config.read_lara_local_config_file(ConfigFile)
    if not ConfigData:
        lara_utils.print_and_flush(f'*** Error: unable to read config file {ConfigFile}, so can\'t copy anything')
        return False
    for Key in Dict:
        FromFile = lara_tmp_file(Key, ConfigData)
        ToFile = Dict[Key]
        if lara_utils.file_exists(FromFile):
            lara_utils.copy_file(FromFile, ToFile)
            lara_utils.print_and_flush(f'--- Copied "{Key}" file to {ToFile}')
        else:
            lara_utils.print_and_flush(f'*** Warning: tmp file "{FromFile}" not found, so cannot copy to {ToFile}')

def lara_config_file_defined(Key, ConfigData):
    return Key in ConfigData

def lara_config_file(Key, ConfigData):
    if Key in ConfigData:
        return ConfigData[Key]
    else:
        lara_utils.print_and_flush(f'*** Error: key "{Key}" not defined in config data')
        return False

def lara_config_dir(Key, ConfigData):
    if Key in ConfigData:
        return ConfigData[Key]
    else:
        lara_utils.print_and_flush(f'*** Error: key "{Key}" not defined in config data')
        return False

def lara_config_value(Key, ConfigData):
    if Key in ConfigData:
        return ConfigData[Key]
    else:
        lara_utils.print_and_flush(f'*** Error: key "{Key}" not defined in config data')
        return False

def lara_tmp_file(Key, ConfigData):
    return lara_tmp_file_for_id(Key,
                                lara_config_value('id', ConfigData),
                                lara_config_value('lara_tmp_directory', ConfigData))

def lara_tmp_file_for_id(Key, Id, TmpDir):
    return f'{TmpDir}/{Id}_{base_name_for_lara_tmp_file(Key)}'  

def lara_tmp_dir(Key, ConfigData):
    return lara_tmp_dir_for_id(Key,
                               lara_config_value('id', ConfigData),
                                lara_config_value('lara_tmp_directory', ConfigData))

def lara_tmp_dir_for_id(Key, Id, TmpDir):
    return f'{TmpDir}/{Id}_{base_name_for_lara_tmp_dir(Key)}'

def lara_compiled_dir(Key, ConfigData):
    return lara_compiled_dir_for_id(Key,
                                    lara_config_value('id', ConfigData),
                                    lara_config_value('compiled_directory', ConfigData))

def lara_compiled_dir_for_id(Key, Id, CompiledDir):
    return f'{CompiledDir}/{Id}{base_name_for_lara_compiled_dir(Key)}'   

base_names_for_lara_tmp_file = {'lemma_dictionary_file': 'tmp_lemma_dictionary.csv',
                                'split': 'split.json',
                                'tagging_feedback': 'tagging_feedback.txt',
                                'count': 'count.json',
                                'compile_cache': 'compile_cache.data.gz',
                                'ldt_segment_recording_file': 'record_segments.txt',
                                'ldt_word_recording_file': 'record_words.txt',
                                'ldt_segment_recording_file_full': 'record_segments_full.txt',
                                'ldt_word_recording_file_full': 'record_words_full.txt',
                                'tmp_translation_spreadsheet': 'tmp_translations.csv',
                                'tmp_segment_translation_spreadsheet': 'tmp_segment_translations.csv'}

base_names_for_lara_tmp_dir = {'metadata_dir': 'metadata'}

base_names_for_lara_compiled_dir = {'word_pages_directory': 'vocabpages'}

def base_name_for_lara_tmp_file(Key):
    if Key in base_names_for_lara_tmp_file:
        return base_names_for_lara_tmp_file[Key]
    else:
        lara_utils.print_and_flush(f'*** Error: LARA tmp file "{Key}" not defined')
        return False

def base_name_for_lara_tmp_dir(Key):
    if Key in base_names_for_lara_tmp_dir:
        return base_names_for_lara_tmp_dir[Key]
    else:
        lara_utils.print_and_flush(f'*** Error: LARA tmp dir "{Key}" not defined')
        return False

def base_name_for_lara_compiled_dir(Key):
    if Key in base_names_for_lara_compiled_dir:
        return base_names_for_lara_compiled_dir[Key]
    else:
        lara_utils.print_and_flush(f'*** Error: LARA compiled dir "{Key}" not defined')
        return False

def find_config_file( filename ):
    if not filename:
        # search for json in directories ./corpus and ./../corpus
        # load the config and check for "id" and "corpus"
        import pathlib
        allConfigFiles = [ str(path) for path in pathlib.Path('./corpus').glob('*.json') ] + [ str(path) for path in pathlib.Path('./../corpus').glob('*.json') ]
        realConfigFiles = []
        for path in allConfigFiles:
            ConfigData = lara_config.read_lara_local_config_file(path)
            if ConfigData and "id" in ConfigData and "corpus" in ConfigData:
                realConfigFiles.append( path )
        if len(realConfigFiles) == 0:
            lara_utils.print_and_flush( '*** Error: cannot determine config file. No files found.')
            return False
        if len(realConfigFiles) > 1:
            lara_utils.print_and_flush( f'*** Error: cannot determine config file. Too many files found: {str(realConfigFiles)}')
            return False
        filename = realConfigFiles[0]    
    configFile = lara_utils.absolute_file_name( filename )
    lara_utils.print_and_flush( f'--- using config file: {configFile}')
    return configFile
