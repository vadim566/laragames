import lara_config
import lara_audio
import lara_translations
import lara_utils
import lara_add_metadata

# Merge two language resources to create a new language resource
# We need the config file to say where the tmp directory is

def merge_language_resources(Dir1, Dir2, Dir12, ConfigFile):
    try:
        return merge_language_resources_main(Dir1, Dir2, Dir12, ConfigFile)
    except Exception as e:
        lara_utils.print_and_flush(f'*** Error: something went wrong when trying to merge {Dir1} and {Dir2} to {Dir12}')
        lara_utils.print_and_flush(str(e))
        return False

def merge_language_resources_main(Dir1, Dir2, Dir12, ConfigFile):
    if not check_valid_language_resource(Dir1):
        return False
    if not check_valid_language_resource(Dir2):
        return False
    Params = lara_config.read_lara_local_config_file(ConfigFile)
    if not Params:
        return False
    if not lara_utils.create_directory_deleting_old_if_necessary(Dir12):
        lara_utils.print_and_flush(f'*** Error: unable to create target directory')
        return False
    if not merge_language_resources_audio(Dir1, Dir2, Dir12):
        lara_utils.print_and_flush(f'*** Error: unable to merge audio directories')
        return False
    if not merge_language_resources_translations(Dir1, Dir2, Dir12, Params):
        lara_utils.print_and_flush(f'*** Error: unable to merge translation directories')
        return False
    lara_utils.print_and_flush(f'--- Successfully merged language resources {Dir1} and {Dir2} to {Dir12}')

def check_valid_language_resource(Dir):
    if not lara_add_metadata.add_metadata_to_lara_resource_directory(Dir, 'language'):
        lara_utils.print_and_flush(f'*** Error: unable to add metadata to {Dir}, probably there is something wrong with the resource')
        return False
    else:
        lara_utils.print_and_flush(f'--- Able to add metadata to {Dir}, assuming resource is okay')
        return True

_valid_audio_file_extensions = ['mp3', 'wav']

def merge_language_resources_audio(Dir1, Dir2, Dir12):
    AudioDir1 = f'{Dir1}/audio'
    AudioDir2 = f'{Dir2}/audio'
    AudioDir12 = f'{Dir12}/audio'
    lara_utils.create_directory_try_n_times(3, AudioDir12)
    VoiceDirs1 = lara_utils.directory_members_of_directory(AudioDir1) if lara_utils.directory_exists(AudioDir1) else []
    VoiceDirs2 = lara_utils.directory_members_of_directory(AudioDir2) if lara_utils.directory_exists(AudioDir2) else []
    # Just copy the voice directories directly that are in one audio directory but not the other
    for VoiceDir in [ Dir for Dir in VoiceDirs1 if not Dir in VoiceDirs2 ]:
        Target = f'{AudioDir12}/{VoiceDir}'
        if not lara_utils.create_directory_try_n_times(3, Target):
            return False
        lara_utils.copy_directory_one_file_at_a_time(f'{AudioDir1}/{VoiceDir}', Target, _valid_audio_file_extensions + ['txt'])
        lara_utils.print_and_flush(f'--- Copied {VoiceDir} from {AudioDir1} to {AudioDir12}')
    for VoiceDir in [ Dir for Dir in VoiceDirs2 if not Dir in VoiceDirs1 ]:
        Target = f'{AudioDir12}/{VoiceDir}'
        if not lara_utils.create_directory_try_n_times(3, Target):
            return False
        lara_utils.copy_directory_one_file_at_a_time(f'{AudioDir2}/{VoiceDir}', Target, _valid_audio_file_extensions + ['txt'])
        lara_utils.print_and_flush(f'--- Copied {VoiceDir} from {AudioDir2} to {AudioDir12}')
    # If they're in both directories, we have to merge them
    for VoiceDir in [ Dir for Dir in VoiceDirs1 if Dir in VoiceDirs2 ]:
        Target = f'{AudioDir12}/{VoiceDir}'
        if not lara_utils.create_directory_try_n_times(3, Target):
            return False
        merge_language_resources_audio1(f'{AudioDir1}/{VoiceDir}', f'{AudioDir2}/{VoiceDir}', Target)
    return True

def merge_language_resources_audio1(Dir1, Dir2, Dir12):
    lara_utils.copy_directory_one_file_at_a_time(Dir1, Dir12, _valid_audio_file_extensions)
    Metadata1 = lara_audio.read_ldt_metadata_file(Dir1)
    lara_utils.copy_directory_one_file_at_a_time(Dir2, Dir12, _valid_audio_file_extensions)
    Metadata2 = lara_audio.read_ldt_metadata_file(Dir2)
    Metadata12 = lara_utils.remove_duplicates(Metadata1 + Metadata2)
    MetadataFile12 = lara_audio.ldt_metadata_file(Dir12)
    lara_utils.write_unicode_text_file('\n'.join(Metadata12), MetadataFile12)
    lara_utils.print_and_flush(f'--- Merged audio directories {Dir1} and {Dir2} to {Dir12}')

def merge_language_resources_translations(Dir1, Dir2, Dir12, Params):
    TranslationDir1 = f'{Dir1}/translations'
    TranslationDir2 = f'{Dir2}/translations'
    TranslationDir12 = f'{Dir12}/translations'
    lara_utils.create_directory_try_n_times(3, TranslationDir12)
    TranslationCVS1 = lara_utils.files_with_given_extension_in_directory(TranslationDir1, 'csv')
    TranslationCVS2 = lara_utils.files_with_given_extension_in_directory(TranslationDir2, 'csv')
    FilesOnlyInDir1 = [ F for F in TranslationCVS1 if not F in TranslationCVS2 ]
    FilesOnlyInDir2 = [ F for F in TranslationCVS2 if not F in TranslationCVS1 ]
    FilesInBothDirs = [ F for F in TranslationCVS1 if F in TranslationCVS2 ]
    for File in FilesOnlyInDir1:
        lara_utils.copy_file(f'{TranslationDir1}/File', f'{TranslationDir12}/File')
    if len(FilesOnlyInDir1) > 0:
        lara_utils.print_and_flush(f'--- Copied {len(FilesOnlyInDir1)} spreadsheets from {TranslationDir1} to {TranslationDir12}')
    for File in FilesOnlyInDir2:
        lara_utils.copy_file(f'{TranslationDir2}/File', f'{TranslationDir12}/File')
    if len(FilesOnlyInDir2) > 0:
        lara_utils.print_and_flush(f'--- Copied {len(FilesOnlyInDir2)} spreadsheets from {TranslationDir2} to {TranslationDir12}')
    for File in FilesInBothDirs:
        TmpFile = lara_utils.get_tmp_trace_file(Params)
        merge_translation_spreadsheets(f'{TranslationDir1}/{File}', f'{TranslationDir2}/{File}', TmpFile)
        lara_utils.copy_file(TmpFile, f'{TranslationDir12}/{File}')
        lara_utils.delete_file_if_it_exists(TmpFile)
    if len(FilesInBothDirs) > 0:
        lara_utils.print_and_flush(f'--- Merged {len(FilesInBothDirs)} spreadsheets from {TranslationDir1} and {TranslationDir2} to {TranslationDir12}')
    return True
        
def merge_translation_spreadsheets(Spreadsheet1, Spreadsheet2, Spreadsheet12):
    Merged = merge_spreadsheet_data(lara_utils.read_lara_csv(Spreadsheet1), lara_utils.read_lara_csv(Spreadsheet2))
    lara_utils.write_lara_csv(Merged, Spreadsheet12)

def merge_spreadsheet_data(Lines1, Lines2):
    Dict1 = { Line[0]: Line[1:] for Line in Lines1 if not trivial_translation_spreadsheet_line(Line) }
    Dict2 = { Line[0]: Line[1:] for Line in Lines2 if not trivial_translation_spreadsheet_line(Line) }
    Dict12 = lara_utils.merge_dicts(Dict1, Dict2)
    return [ [ Key ] + Dict12[Key] for Key in Dict12 ]

def trivial_translation_spreadsheet_line(Line):
    return len(Line) == 0 or Line[0] == '' or Line[0].isspace()

    
