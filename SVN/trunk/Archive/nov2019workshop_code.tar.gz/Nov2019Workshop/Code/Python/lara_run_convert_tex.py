import lara_tex_french_course as t

t.convert_tex()


