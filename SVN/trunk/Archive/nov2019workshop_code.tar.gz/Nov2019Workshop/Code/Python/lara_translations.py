
import lara_split_and_clean
import lara_utils
import lara_replace_chars
import lara_parse_utils

def count_translations(Params):
    return { 'segments': count_segment_translations(Params),
             'words': count_word_translations(Params)
             }

def make_translation_spreadsheet(SplitFile, Spreadsheet, Params):
    global translations_for_headwords
    translations_for_headwords = {}
    if not process_word_spreadsheet_files('local_files', all_word_translation_spreadsheets(Params)):
        return False
    InList = [ Chunk for ( PageInfo, Chunks ) in lara_split_and_clean.read_split_file(SplitFile, Params) for Chunk in Chunks ]
    AllCurrent = all_non_punctuation_headwords_in_segments(InList)
    CurrentPairs = [ [Word, 'current'] for Word in AllCurrent ]
    # Collect the current translations loaded by process_word_spreadsheet_files if there are any
    if 'local_files' in translations_for_headwords:
        NonCurrentPairs = [ [Word, ''] for Word in translations_for_headwords['local_files'] if not Word in AllCurrent ]
    else:
        NonCurrentPairs = []
    AllPairs = CurrentPairs + NonCurrentPairs
    Triples0 = [ (Word, translation_for_headword_or_null(Word, 'local_files'), Current) for ( Word, Current ) in AllPairs ]
    Triples = sorted(lara_utils.remove_duplicates(Triples0), key=lambda x: x[0])
    Header = ['Head word', 'Translation', 'CurrentDomain']
    #lara_utils.write_lara_csv([ Header ] + Triples, Spreadsheet)
    write_translation_csv(Header, Triples, Spreadsheet)
    NEmpty = count_empty_translations_in_vocab_spreadsheet_list(Triples)
    NFilled = len(Triples) - NEmpty
    lara_utils.print_and_flush(f'--- Written word spreadsheet ({NFilled} filled entries, {NEmpty} blank entries) {Spreadsheet}')

def count_word_translations(Params):
    global translations_for_headwords
    translations_for_headwords = {}
    if not process_word_spreadsheet_files('local_files', all_word_translation_spreadsheets(Params)):
        ( NEmpty, NFilled ) = ( 0, 0 )
    InList = [ Chunk for ( PageInfo, Chunks ) in lara_split_and_clean.read_split_file(Params.split_file, Params) for Chunk in Chunks ]
    AllCurrent = all_non_punctuation_headwords_in_segments(InList)
    CurrentPairs = [ [Word, 'current'] for Word in AllCurrent ]
    Triples = [ (Word, translation_for_headword_or_null(Word, 'local_files'), Current) for ( Word, Current ) in CurrentPairs ]
    NEmpty = count_empty_translations_in_vocab_spreadsheet_list(Triples)
    NFilled = len(Triples) - NEmpty
    return { 'translated': NFilled, 'not_translated': NEmpty }

def all_word_translation_spreadsheets(Params):
    OwnTranslationSpreadsheets = [] if Params.translation_spreadsheet == '' else [ Params.translation_spreadsheet ]
    return OwnTranslationSpreadsheets 
                        
def all_non_punctuation_headwords_in_segments(InList):
    Words0 = [ Word for Chunk in InList for ( Surface, Word ) in Chunk[2]
               if not lara_parse_utils.is_punctuation_string(Word) and not not_real_headword(Word) ]
    return lara_utils.remove_duplicates(Words0)

# Not yet sure how 'local_files' can get into this list, but discard it if it does.
def not_real_headword(Word):
    return Word in ['local_files']

def make_segment_translation_spreadsheet(SplitFile, Spreadsheet, Params):
    global translations_for_segments
    translations_for_segments = {}
    if not process_segment_spreadsheet_files('local_files', all_segment_translation_spreadsheets(Params)):
        return False
    InList = [ Chunk for ( PageInfo, Chunks ) in lara_split_and_clean.read_split_file(SplitFile, Params) for Chunk in Chunks ]
    Triples = [ ( Chunk[1], translation_for_segment_or_null(Chunk[1], 'local_files'), 'current' ) for Chunk in InList
                if not (Chunk[1]).isspace() and not Chunk[1] == '' ]
    Header = ['Segment', 'Translation', 'CurrentDomain']
    #lara_utils.write_lara_csv([ Header ] + Triples, Spreadsheet)
    write_translation_csv(Header, Triples, Spreadsheet)
    NEmpty = count_empty_translations_in_vocab_spreadsheet_list(Triples)
    NFilled = len(Triples) - NEmpty
    lara_utils.print_and_flush(f'--- Written segment spreadsheet ({NFilled} filled entries, {NEmpty} blank entries) {Spreadsheet}')

def count_segment_translations(Params):
    global translations_for_segments
    translations_for_segments = {}
    if not process_segment_spreadsheet_files('local_files', all_segment_translation_spreadsheets(Params)):
        ( NEmpty, NFilled ) = ( 0, 0 )
    InList = [ Chunk for ( PageInfo, Chunks ) in lara_split_and_clean.read_split_file(Params.split_file, Params) for Chunk in Chunks ]
    Triples = [ ( Chunk[1], translation_for_segment_or_null(Chunk[1], 'local_files'), 'current' ) for Chunk in InList
                if not (Chunk[1]).isspace() and not Chunk[1] == '' ]
    NEmpty = count_empty_translations_in_vocab_spreadsheet_list(Triples)
    NFilled = len(Triples) - NEmpty
    return { 'translated': NFilled, 'not_translated': NEmpty }

def all_segment_translation_spreadsheets(Params):
    OwnTranslationSpreadsheets = [] if Params.segment_translation_spreadsheet == '' else [ Params.segment_translation_spreadsheet ]
    return OwnTranslationSpreadsheets

def write_translation_csv(Header, Triples, Spreadsheet):
    Triples1 = [ ( lara_replace_chars.restore_reserved_chars(Text), Trans, Current) for ( Text, Trans, Current ) in Triples ]
    lara_utils.write_lara_csv([ Header ] + Triples1, Spreadsheet)

translations_for_headwords = {}
translations_for_segments = {}

def init_stored_downloaded_translations_metadata():
    global translations_for_headwords, translations_for_segments
    translations_for_headwords = {}
    translations_for_segments = {}

def translation_for_headword(Word, LanguageId):
    global translations_for_headwords
    if LanguageId in translations_for_headwords:
        SubDict = translations_for_headwords[LanguageId]
        if Word in SubDict:
            return SubDict[Word]
        LemmaParts = Word.split('/')
        if len(LemmaParts) > 1 and LemmaParts[0] in SubDict:
            return SubDict[LemmaParts[0]]
    return False

def translation_for_headword_or_null(Word, LanguageId):
    Translation = translation_for_headword(Word, LanguageId)
    if Translation:
        return Translation
    else:
        return ''

def translation_for_segment(Segment, CorpusId):
    global translations_for_segments
    CanonicalSegment = regularise_segment(Segment)
    if CorpusId in translations_for_segments:
        SubDict = translations_for_segments[CorpusId]
        if CanonicalSegment in SubDict:
            return SubDict[CanonicalSegment]
        else:
            return False
    else:
        return False

def no_segment_translations(CorpusId):
    global translations_for_segments
    return not CorpusId in translations_for_segments 
    
def translation_for_segment_or_null(Segment, CorpusId):
    Translation = translation_for_segment(Segment, CorpusId)
    if Translation:
        return Translation
    else:
        return ''

def store_downloaded_word_translations(LanguageId, File):
    return process_word_spreadsheet_file(LanguageId, File)

def process_word_spreadsheet_files(LanguageId, Files):
    for File in Files:
        if not process_word_spreadsheet_file(LanguageId, File):
            return False
    return True

def process_word_spreadsheet_file(LanguageId, File):
    if lara_utils.file_exists(File):
        DataFromCSV = lara_utils.read_lara_csv(File)
        if DataFromCSV:
            Records = DataFromCSV[1:]
            store_word_spreadsheet_data(LanguageId, Records)
            lara_utils.print_and_flush(f'--- Loaded word translation spreadsheet {File}')
            return True
        else:
            lara_utils.print_and_flush(f'*** Error: unable to load word translation spreadsheet {File}')
            return False
    else:
        lara_utils.print_and_flush(f'*** Warning: word translation spreadsheet not found: {File}')
        return True

def store_word_spreadsheet_data(LanguageId, Records):
    global translations_for_headwords
    SubDict = translations_for_headwords[LanguageId] if LanguageId in translations_for_headwords else {}
    for Record in Records:
        # Ignore lines where the translation hasn't been filled in.
        if len(Record) >= 2 and not Record[1].isspace() and not Record[1] == '':
            ( Word, Translation ) = ( lara_replace_chars.replace_reserved_chars(Record[0]), Record[1] )
            SubDict[Word] = Translation
    translations_for_headwords[LanguageId] = SubDict

def store_downloaded_segment_translations(CorpusId, File):
    return process_segment_spreadsheet_file(CorpusId, File)

def process_segment_spreadsheet_files(CorpusId, Files):
    for File in Files:
        if not process_segment_spreadsheet_file(CorpusId, File):
            return False
    return True
            
def process_segment_spreadsheet_file(CorpusId, File):
    if lara_utils.file_exists(File):
        DataFromCSV = lara_utils.read_lara_csv(File)
        if DataFromCSV:
            Records = DataFromCSV[1:]
            store_segment_spreadsheet_data(CorpusId, Records)
            lara_utils.print_and_flush(f'--- Loaded segment translation spreadsheet ({len(Records)} records) {File}')
            return True
        else:
            lara_utils.print_and_flush(f'*** Error: unable to load segment translation spreadsheet {File}')
            return False
    else:
        lara_utils.print_and_flush(f'*** Warning: segment translation spreadsheet not found: {File}')
        return True

def store_segment_spreadsheet_data(CorpusId, Records):
    global translations_for_segments
    SubDict = translations_for_segments[CorpusId] if CorpusId in translations_for_segments else {}
    for Record in Records:
        # Ignore lines where the translation hasn't been filled in.
        if len(Record) >= 2 and not Record[1].isspace() and not Record[1] == '':
            Key = internalise_text_from_segment_spreadsheet(Record[0])
            SubDict[Key] = Record[1]
    translations_for_segments[CorpusId] = SubDict

def regularise_segment(Str):
    Str1 = lara_parse_utils.remove_weird_characters(Str)
    return lara_parse_utils.remove_initial_and_final_spaces(Str1.replace('"', '').replace('\'', ''))

def internalise_text_from_segment_spreadsheet(Str):
    Str1 =  lara_replace_chars.replace_reserved_chars(Str)
    return lara_parse_utils.remove_initial_and_final_spaces(Str1.replace('"', '').replace('\'', ''))

def count_empty_translations_in_vocab_spreadsheet_list(Triples):
    Empty = [ Word for ( Word, Translation, Current ) in Triples if Translation == '' ]
    return len(Empty)

# ------------------------------------------------

def make_current_only_csv(FullCSV, CurrentOnlyCSV):
    if lara_utils.file_exists(FullCSV):
        DataFromCSV = lara_utils.read_lara_csv(FullCSV)
        if DataFromCSV and len(DataFromCSV) >= 1:
            lara_utils.print_and_flush(f'--- Read full translation spreadsheet, {len(DataFromCSV)-1} records')
            CurrentOnlyRecords = [ Record for Record in DataFromCSV[1:] if len(Record) >= 2 and Record[2] == 'current' ]
            AllCurrentOnlyRecords = [ DataFromCSV[0] ] + CurrentOnlyRecords
            lara_utils.write_lara_csv(AllCurrentOnlyRecords, CurrentOnlyCSV)
            lara_utils.print_and_flush(f'--- Written current-only translation spreadsheet, {len(CurrentOnlyRecords)} records to {CurrentOnlyCSV}')
            return True
        else:
            lara_utils.print_and_flush(f'*** Warning: unable to read translation spreadsheet {FullCSV}')
            return False
    else:
        lara_utils.print_and_flush(f'*** Warning: word translation spreadsheet not found: {FullCSV}')
        return True
