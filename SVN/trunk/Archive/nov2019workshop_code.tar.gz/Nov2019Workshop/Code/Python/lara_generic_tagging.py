# Code that will be used by different taggers

import lara_utils
import lara_parse_utils
import lara_replace_chars
import lara_postags
import lara_clitics

# list of surface words/strings encountered during testing which TreeTagger 
# wants to tag (probably due to a bug in the TT executable) but must not have a tag 
surfacewords_to_not_tag = [ '»', '«', '„', '”', '…', '–' ] 

## Now go down the original LARA file, which has been turned into a string,
## matching each surface word from the tagging triples in turn and
## if necessary adding hashtags and/or multiword markers
def annotate_lara_string_from_tagging_triples(TagTuples, InString, Params):
    Index = 0
    N = len(InString)
    OutString = ''
    AddPosTagsToLemma = Params.add_postags_to_lemma == 'yes' and Params.language != '' 
    for ( SurfaceWordsList, Tag, Lemma ) in TagTuples:
        Lemma = maybe_fix_strange_treetagger_characters(Lemma, Params)
        SurfaceWord = ' '.join(SurfaceWordsList)
        if AddPosTagsToLemma:
            Tag = lara_postags.map_postag(Tag, Params)
        ( Clitic, CliticType ) = lara_clitics.is_clitic(SurfaceWord, Params.language)
        Lemma = Clitic if Clitic else Lemma
        ( NewStartIndex, NewEndIndex, MatchedString ) = match_surface_words(SurfaceWordsList, InString, Index)
        if not MatchedString:
            Sample = f'{InString[Index:Index+100]}...' if Index + 100 < N else InString[Index:]
            #lara_utils.print_and_flush(f'*** Error: unable to find "{str(SurfaceWord)}" in "{Sample}"')
            #return False
            lara_utils.print_and_flush(f'*** Warning: unable to find "{str(SurfaceWord)}" in "{Sample}"')
        else:
            SkippedString = InString[Index:NewStartIndex]
            if Lemma == '@card@' or \
               MatchedString.lower() == Lemma and ( not AddPosTagsToLemma or AddPosTagsToLemma and Tag == '' ):
                SubstituteString = MatchedString
                if need_multiword_brackets(MatchedString, SurfaceWordsList):
                    SubstituteString = f'@{SubstituteString}@'
            elif SurfaceWord in surfacewords_to_not_tag:
                SubstituteString = SurfaceWord
            else:
                if AddPosTagsToLemma and Tag != '' and Lemma != '':
                    Lemma = f'{Lemma}/{Tag}'
                SurfaceWordsString = f'@{MatchedString}@' if need_multiword_brackets(MatchedString, SurfaceWordsList) else MatchedString
                SubstituteString = f'{SurfaceWordsString}#{Lemma}#'
            if CliticType == 'pre':
                SubstituteString = f'{SubstituteString}|'
            elif CliticType == 'post':
                SubstituteString = f'|{SubstituteString}'
            OutString += ( SkippedString + SubstituteString )
            Index = NewEndIndex
    return OutString + InString[Index:]

# TreeTagger mangles the French œ ligature - we may find other similar cases
def maybe_fix_strange_treetagger_characters(Lemma, Params):
    Lang = Params.language
    if Lang == 'french':
        OutStr = ''
        for Char in Lemma:
            OutStr += ( 'œ' if ord(Char) == 156 else Char )
        return OutStr
    else:
        return Lemma

# We need multiword brackets around a string if it consists of several words, or includes punctuation other than hyphens or apostrophes,
# but we don't need it if the word is a single punctuation mark.
def need_multiword_brackets(MatchedString, SurfaceWordsList):
    return not is_single_punctuation_mark(MatchedString) and \
           ( len(SurfaceWordsList) > 1 or string_contains_punctuation_except_hyphen_and_apostrophe(MatchedString) )

def is_single_punctuation_mark(Str):
    return isinstance(Str, str) and len(Str) == 1 and lara_parse_utils.is_punctuation_char(Str[0])

def string_contains_punctuation_except_hyphen_and_apostrophe(Str):
    for Char in Str:
        if lara_parse_utils.is_punctuation_char(Char) and not Char in "-" and not lara_parse_utils.is_apostrophe_char(Char):
            return True
    return False

def match_surface_words(SurfaceWordsList, InString, Index):
    ( FirstWord, RestWords ) = ( SurfaceWordsList[0], SurfaceWordsList[1:] )
    StartIndex = InString.find(FirstWord, Index)
    if StartIndex < 0:
        return ( False, False, False)
    Index = StartIndex + len(FirstWord)
    for Word in RestWords:
        NewIndex = InString.find(Word, Index)
        if NewIndex < 0:
            return ( False, False, False)
        Index = NewIndex + len(Word)
    return ( StartIndex, Index, InString[StartIndex:Index] )

# If a multiword contains a clitic, we can get hashtags and separator chars inside the tagged version
def remove_hashtags_and_separators_inside_multiwords(Str):
    ( I, N, StrOut ) = ( 0, len(Str), '' )
    while True:
        if I >= N:
            return StrOut
        if Str[I] == '@':
            EndOfMultiword = Str.find('@', I + len('@'))
            if EndOfMultiword < 0:
                lara_utils.print_and_flush(f'*** Error: open multiword tag {Str[I:I+32]}" in tagged string')
                return False
            else:
                StrOut += f'@{remove_hashtags_and_separators(Str[I+1:EndOfMultiword])}@'
                I = EndOfMultiword + len('@')
        else:
            StrOut += Str[I]
            I += 1

def remove_hashtags_and_separators(Str):
    return (lara_parse_utils.remove_hashtag_annotations_from_string(Str)).replace('|', '')
