
import lara_utils
import unicodedata

## Simple utility functions for parsing LARA strings.

## Remove hashtags and HTML annotations, but keep the comments if we have
## 'keep_comments':'yes' in the parameters
## Returns a (Str, Trace) pair
def remove_hashtag_comment_and_html_annotations(StrIn, Params):
    KeepComments = 'keep_comments' if 'keep_comments' in Params and Params['keep_comments'] == 'yes' else 'delete_comments'
    return remove_hashtag_comment_and_html_annotations1(StrIn, KeepComments)

def remove_hashtag_comment_and_html_annotations1(StrIn, KeepComments):
    I = 0
    N = len(StrIn)
    State = 'outside_annotation'
    StrOut = ''
    while True:
        if I >= N and State == 'outside_annotation':
            return ( StrOut, [] )
        if I >= N:
            return ( '', [ f'*** Error: incorrect tagging in "{StrIn}"' ] )
        c1 = StrIn[I]
        c2 = StrIn[I:I+2]
        if c1 == "#" and State == 'outside_annotation':
            State = 'inside_hash'
            I += 1
        elif c1 == "@" and State == 'outside_annotation':
            State = 'inside_phrase'
            I += 1
        elif c1 == "<" and State == 'inside_phrase':
            State = 'inside_phrase_and_html'
            I += 1         
        elif c1 == "<" and State == 'inside_comment':
            State = 'inside_comment_and_html'
            I += 1         
        elif c1 == "<" and State == 'outside_annotation':
            State = 'inside_html'
            I += 1   
        elif c2 == "/*" and State == 'outside_annotation':
            State = 'inside_comment'
            I += 2  
        elif c1 == "#" and State == 'inside_hash':
            State = 'outside_annotation'
            I += 1  
        elif c1 == "@" and State == 'inside_phrase':
            State = 'outside_annotation'
            I += 1 
        elif c1 == ">" and State == 'inside_phrase_and_html':
            State = 'inside_phrase'
            I += 1 
        elif c1 == ">" and State == 'inside_comment_and_html':
            State = 'inside_comment'
            I += 1 
        elif c1 == ">" and State == 'inside_html':
            State = 'outside_annotation'
            I += 1
        elif c2 == "*/" and State == 'inside_comment':
            State = 'outside_annotation'
            I += 2
        elif State == 'inside_hash':
            I += 1
        elif State == 'inside_html':
            I += 1
        elif State == 'inside_phrase_and_html':
            I += 1
        elif State == 'inside_comment_and_html':
            I += 1
        elif State == 'inside_comment' and KeepComments == 'delete_comments':
            I += 1
        elif State == 'inside_comment' and KeepComments == 'keep_comments':
            StrOut += StrIn[I]
            I += 1
        elif State == 'outside_annotation':
            StrOut += StrIn[I]
            I += 1
        elif State == 'inside_phrase':
            StrOut += StrIn[I]
            I += 1
        else:
            return ( '', [ f'*** Error: incorrect tagging in "{StrIn}"' ] )

## Remove all HTML tags.
## Return a string/trace pair
def remove_html_annotations_from_string(StrIn):
    I = 0
    N = len(StrIn)
    State = 'outside_annotation'
    StrOut = ''
    while True:
        if I >= N and State == 'outside_annotation':
            return ( StrOut, [] )
        if I >= N:
            return ( '', [ f'*** Error: incorrect tagging in "{StrIn}"' ] )
        c1 = StrIn[I]
        if c1 == "<" and State == 'outside_annotation':
            State = 'inside_html'
            I += 1   
        elif c1 == ">" and State == 'inside_html':
            State = 'outside_annotation'
            I += 1
        elif State == 'inside_html':
            I += 1
        elif State == 'outside_annotation':
            StrOut += StrIn[I]
            I += 1
        else:
            return ( '', [ f'*** Error: incorrect tagging in "{StrIn}"' ] )

## Remove all hashtags and phrase markings.
## Return a string
def remove_hashtag_annotations_from_string(StrIn):
    I = 0
    N = len(StrIn)
    State = 'outside_annotation'
    StrOut = ''
    while True:
        if I >= N and State == 'outside_annotation':
            return StrOut
        if I >= N:
            lara_utils.print_and_flush(f'*** Error: incorrect tagging in "{StrIn}"')
            return False
        c1 = StrIn[I]
        if c1 == "#" and State == 'outside_annotation':
            State = 'inside_hash'
            I += 1   
        elif c1 == "#" and State == 'inside_hash':
            State = 'outside_annotation'
            I += 1
        elif c1 == "@" and State == 'outside_annotation':
            State = 'inside_phrase'
            I += 1   
        elif c1 == "@" and State == 'inside_phrase':
            State = 'outside_annotation'
            I += 1
        elif State == 'inside_hash':
            I += 1
        elif State == 'outside_annotation' or State == 'inside_phrase':
            StrOut += StrIn[I]
            I += 1
        else:
            return ( '', [ f'*** Error: incorrect tagging in "{StrIn}"' ] )   

## Remove top-level tags (i.e. not things like </i>) and comments.
## Return a string/trace pair
def remove_top_level_tags_and_comments(StrIn):
    I = 0
    N = len(StrIn)
    StrOut = ''
    while True:
        if I >= N:
            return ( StrOut, [] )
        elif substring_found_at_index(StrIn, I, "<"):
            End = StrIn.find(">", I+1)
            if End > I and is_top_level_tag(StrIn[I:End+len('>')]):
                I = End + len('>')
            elif End > I:
                StrOut += StrIn[I:End+len('>')]
                I = End + len('>')
            else:
                return ( '', [ f'*** Error: incorrect tagging in "{StrIn}"' ] )
        elif substring_found_at_index(StrIn, I, "/*"):
            End = StrIn.find("*/", I+len("*/"))
            if End > I:
                I = End + len("*/")
                # Shorten comments to minimal comments
                StrOut += '/**/'
            else:
                return ( '', [ f'*** Error: incorrect tagging in "{StrIn}"' ] )
        else:
            StrOut += StrIn[I]
            I += 1

def is_top_level_tag(Str):
    if Str in ['<h1>', '</h1>',
               '<h2>', '</h2>',
               '<table>', '</table>',
               '<tr>', '</tr>',
               '<td>', '</td>']:
        return True
    elif substring_found_at_index(Str, 0, '<img '):
        return True
    elif substring_found_at_index(Str, 0, '<audio '):
        return True
    else:
        return False

## Remove img and audio tags only
## Return a string/trace pair
def remove_img_and_audio_tags(StrIn):
    I = 0
    N = len(StrIn)
    StrOut = ''
    while True:
        if I >= N:
            return ( StrOut, [] )
        elif substring_found_at_index(StrIn, I, "<"):
            End = StrIn.find(">", I+1)
            if End > I and is_img_or_audio_tag(StrIn[I:End]):
                I = End + 1
            elif End > I:
                StrOut += StrIn[I:End+1]
                I = End + 1
            else:
                return ( '', [ f'*** Error: incorrect tagging in "{StrIn}"' ] )
        else:
            StrOut += StrIn[I]
            I += 1

def is_img_or_audio_tag(Str):
    if substring_found_at_index(Str, 0, '<img '):
        return True
    elif substring_found_at_index(Str, 0, '<audio '):
        return True
    else:
        return False


## Clean up string by adding spaces before and after various
## punctuation marks. This is ad hoc and not robust. We need a better way
clean_substitutions = [ [ "|", "| " ],
                        [ " M.", " M." ],
                        [ " Mr.", " Mr." ],
                        [ " Mrs.", " Mrs." ],
                        [ "\n", " " ],
                        [ " M.", " M." ],
                        [ "...", " ... " ],
                        [ "…", " ... " ],
                        [ ".»", " . » " ],
                        [ "?»", " ? » " ],
                        [ "!»", " ! » " ],
                        [ ".", " . " ],
                        [ "?", " ? " ],
                        [ "؟", " ؟ " ],
                        [ "!", " ! " ],
                        [ ";", " ; " ],
                        [ "؛", " ؛ " ],
                        [ ":", " : " ],
                        [ "--", " - " ],
                        [ "—", " — " ],
                        [ "«", "« " ],
                        [ "»", " » " ],
                        [ "“", "“ " ],
                        [ "”", " ” " ],
                        [ "\"", "" ],
                        [ ",", " ," ],
                        [ "،", " ،" ],
                        [ "'", "' " ],
                        [ "‘", " ‘ " ],
                        [ "’", " ’ " ],
                        [ "(", "( " ],
                        [ ")", " )" ],
                        #[ "_", "" ],
                        [ "　", " " ],
                        [ "。", " 。" ],
                        [ "、", " 、" ],
                        [ "！", " ！" ],
                        [ "「", "「 " ],
                        [ "」", " 」 " ]
                        ]

def clean_lara_string(StrIn):
    N = len(StrIn)
    State = 'top_level'
    StrOut = ''
    I = 0
    while True:
        if I >= N and State == 'top_level':
            return ( StrOut, [] )
        if I >= N:
            return ( StrIn, [f'*** Error: incorrect tagging in "{StrIn}"'] )
        c1 = StrIn[I]
        if c1 == "@" and State == 'top_level':
            State = 'inside_phrase_brackets'
            StrOut += StrIn[I]
            I += 1
        elif c1 == "@" and State == 'inside_phrase_brackets':
            State = 'top_level'
            StrOut += StrIn[I]
            I += 1
        elif State == 'inside_phrase_brackets':
            StrOut += StrIn[I]
            I += 1
        # Special handling of single quote/apostrophe surrounded by letters and possibly vertical bars or hashtags
        elif I + 2 < N and State == 'top_level' and StrIn[I] == '|' and is_apostrophe_char(StrIn[I + 1]) and StrIn[I+2].isalpha():
            StrOut += f'| {StrIn[I+1]}{StrIn[I+2]}'
            I += 3
        elif I + 2 < N and State == 'top_level' and StrIn[I].isalpha() and is_apostrophe_char(StrIn[I + 1]) and StrIn[I] == '|':
            StrOut += f'{StrIn[I]}{StrIn[I+1]}| '
            I += 3
        elif I + 2 < N and State == 'top_level' and StrIn[I].isalpha() and is_apostrophe_char(StrIn[I + 1]) and \
             ( StrIn[I+2].isalpha() or StrIn[I+2] == '#' ):
            StrOut += f'{StrIn[I]}{StrIn[I+1]}{StrIn[I+2]}'
            I += 3                                                                                   
        else:
            MatchResult = match_against_substitutions_table(StrIn, I, clean_substitutions)
            if MatchResult:
                ( From, To ) = MatchResult
                StrOut += To
                I += len(From)
            else:
                StrOut += StrIn[I]
                I += 1

def is_apostrophe_char(X):
    return X in "'’"

def match_against_substitutions_table(Str, Index, Table):
    for Line in Table:
        ( From, To ) = Line
        if substring_found_at_index(Str, Index, From):
            return ( From, To )
    return False

# AudioOutput help any_speaker MISSING_FILE all# (no trace info)
def parse_ldt_recording_script_line(Line):
    start_string = "MISSING_FILE "
    end_string = "#"
    Start = Line.find(start_string)
    if Start < 0:
        return False
    End = Line.find(end_string, Start + len(start_string))
    if End < 0:
        return False
    return Line[Start + len(start_string):End]

def parse_ldt_metadata_file_line(Line):
    if Line.find("AudioOutput") >= 0:
        return parse_ldt_metadata_file_ldt_line(Line)
    elif Line.find("NonLDTAudioFile") >= 0:
        return parse_ldt_metadata_file_non_ldt_line(Line)
    else:
        return False

# AudioOutput help any_speaker help/50771_181219201652.wav 'Now run along, and don't get into mischief. I am going out.'# |
def parse_ldt_metadata_file_ldt_line(Line):
    HelpIndex = Line.find("help/")
    if HelpIndex > 0:
        StartFileIndex = HelpIndex + len("help/")
    else:
        return False
    if Line.find(".wav") > 0:
        EndFileIndex = Line.find(".wav") + len(".wav")
    elif Line.find(".mp3") > 0:
        EndFileIndex = Line.find(".mp3") + len(".mp3")
    else:
        return False
    File = Line[StartFileIndex:EndFileIndex]
    FirstNonSpaceInTextIndex = skip_spaces(Line, EndFileIndex)
    HashIndex = Line.find("#")
    if HashIndex > EndFileIndex:
        Text = Line[FirstNonSpaceInTextIndex:HashIndex]
        return ( File, Text )
    else:
        return File

# NonLDTAudioFile Inferno_I_1-12.mp3
def parse_ldt_metadata_file_non_ldt_line(Line):
    TagIndex = Line.find("NonLDTAudioFile")
    if TagIndex >= 0:
        EndTagIndex = TagIndex + len("NonLDTAudioFile")
    else:
        return False
    FirstNonSpaceInTextIndex = skip_spaces(Line, EndTagIndex)
    File = remove_final_spaces(Line[FirstNonSpaceInTextIndex:])
    if len(File) > 0:
        return ( File, 'NonLDTAudioFile' )
    else:
        return False

def skip_spaces(Str, Start):
    Index = Start
    N = len(Str)
    while True:
        if Index >= N:
            return N
        elif Str[Index].isspace():
            Index += 1
        else:
            return Index

def substring_found_at_index(Str, Index, Substr):
    return Str[Index:Index + len(Substr)] == Substr 
    # return Str.find(Substr, Index, Index + len(Substr)) >= 0

def regularise_spaces(Str):
    return ' '.join(Str.split())

def remove_weird_characters(Str):
    # Odd things in Japanese
    #Str1 = Str.replace('　', '')
    Str1 = Str
    return Str1.replace('\ufeff', '')

def remove_initial_and_final_spaces(Str):
    return remove_final_spaces(remove_initial_spaces(Str))

def remove_initial_spaces(Str):
    I = 0
    N = len(Str)
    while True:
        if I >= N:
            return ''
        elif Str[I].isspace():
            I += 1
        else:
            return Str[I:]

def remove_final_spaces(Str):
    I = 0
    N = len(Str)
    while True:
        if I >= N:
            return Str
        elif (Str[I:]).isspace():
            return Str[:I]
        else:
            I += 1


def remove_initial_and_final_punctuation_marks(Str):
    return remove_final_punctuation_marks(remove_initial_punctuation_marks(Str))

def remove_punctuation_marks(Str):
    ( I, N, Str1 ) = ( 0, len(Str), '')
    while True:
        if I >= N:
            return Str1
        if not is_punctuation_char(Str[I]):
            Str1 += Str[I]
        I += 1

def remove_initial_punctuation_marks(Str):
    I = 0
    N = len(Str)
    while True:
        if I >= N:
            return ''
        elif is_punctuation_char(Str[I]):
            I += 1
        else:
            return Str[I:]

def remove_final_punctuation_marks(Str):
    I = 0
    N = len(Str)
    while True:
        if I >= N:
            return Str
        elif is_punctuation_or_vertical_bar_string(Str[I:]):
            return Str[:I]
        else:
            I += 1

def is_punctuation_or_vertical_bar_string(Str):
    for Char in Str:
        if not is_punctuation_or_vertical_bar_char(Char):
            return False
    return True


def is_punctuation_string(Str):
    if not isinstance(Str, str):
        return False
    for Char in Str:
        if not is_punctuation_char(Char):
            return False
    return True

def is_punctuation_or_vertical_bar_char(Char):
    return Char == '|' or is_punctuation_char(Char)

def is_punctuation_char(Char):
    return unicodedata.category(Char)[0] == 'P' or Char in '¦−'








   
