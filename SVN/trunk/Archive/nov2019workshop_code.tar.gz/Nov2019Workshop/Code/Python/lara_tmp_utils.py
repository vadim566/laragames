
import lara_utils

def convert_csv_from_quotes_to_no_quotes(InFile, OutFile):
    Content = lara_utils.read_lara_csv_specifying_quoting(InFile, 'quotes')
    lara_utils.write_lara_csv(Content, OutFile)

def convert_all_lara_csvs_from_quotes_to_no_quotes():
    RootDir = '$LARA/Content'
    for SubDir in lara_utils.directory_files(RootDir):
        FullSubDir = f'{RootDir}/{SubDir}'
        if lara_utils.directory_exists(FullSubDir):
            convert_all_lara_csvs_from_quotes_to_no_quotes1(FullSubDir)

def convert_all_lara_csvs_from_quotes_to_no_quotes1(Dir):
    if 'translations' in lara_utils.directory_files(Dir):
        TranslationDir = f'{Dir}/translations'
        convert_all_lara_csvs_from_quotes_to_no_quotes2(TranslationDir)

def convert_all_lara_csvs_from_quotes_to_no_quotes2(Dir):
    for CSVFile in lara_utils.directory_files(Dir):
        File = f'{Dir}/{CSVFile}'
        if lara_utils.extension_for_file(f'{Dir}/{CSVFile}') == 'csv':
            convert_csv_from_quotes_to_no_quotes(File, File)
            lara_utils.print_and_flush(f'--- Converted {File}')

# ---------------------------

def remove_nul_chars_from_file(InFile, OutFile):
    Content = lara_utils.read_lara_text_file(InFile)
    lara_utils.write_lara_text_file(Content.replace('\0', ''), OutFile)
