
import lara_top
import lara_config
import lara_utils
import time

def run_test1():
    Files = ['$LARA/Content/lorem_ipsum/corpus/local_config.json',
             '$LARA/Content/mary_had_a_little_lamb/corpus/mary_had_a_little_lamb.json',
             '$LARA/Content/peter_rabbit/corpus/local_config.json'
             ]
    run_lara_test(Files)

def run_test2():
    Files = ['$LARA/Content/lorem_ipsum/corpus/local_config.json',
             '$LARA/Content/mary_had_a_little_lamb/corpus/mary_had_a_little_lamb.json',
             '$LARA/Content/peter_rabbit/corpus/local_config.json',
             '$LARA/Content/hyakumankai_ikita_neko/corpus/local_config.json',
             '$LARA/Content/hur_gick_det_sen/corpus/local_config.json',
             '$LARA/Content/alice_in_wonderland/corpus/local_config.json',
             '$LARA/Content/tina_fer_i_fri/corpus/local_config.json',
             '$LARA/Content/ungaretti/corpus/local_config.json',
             '$LARA/Content/dante/corpus/local_config.json',
             '$LARA/Content/revivalistics/corpus/local_config.json',
             '$LARA/Content/EbneSina/corpus/local_config.json',
             '$LARA/Content/the_boy_who_cried_wolf/corpus/local_config.json',
             '$LARA/Content/Arash/corpus/local_config.json',
             '$LARA/Content/bozboz_ghandi/corpus/local_config.json',
             '$LARA/Content/molana/corpus/local_config.json',
             '$LARA/Content/le_petit_prince_small/corpus/local_config.json',
             '$LARA/Content/texs_french_course/corpus/local_config.json',
             '$LARA/Content/edward_lear/corpus/local_config.json',
             '$LARA/Content/ogden_nash/corpus/local_config.json',
             '$LARA/Content/litli_prinsinn/corpus/local_config.json',
             '$LARA/Content/barngarla_alphabet/corpus/local_config.json',
             '$LARA/Content/wilhelmbusch/corpus/wilhelmbusch.json',
             '$LARA/Content/the_rime_of_the_ancient_mariner/corpus/local_config.json',
             '$LARA/Content/animal_farm/corpus/local_config.json',
             '$LARA/Content/le_chien_jaune/corpus/local_config.json',
             '$LARA/Content/kallocain/corpus/local_config.json',
             '$LARA/Content/the_conversation/corpus/local_config.json',
             '$LARA/Content/the_conversation_french/corpus/local_config.json'
             ]
    run_lara_test(Files)

def run_lara_test_from_list_in_file(MetadataFile, TestType):
    Files = lara_utils.read_json_file(MetadataFile)
    if not Files:
        lara_utils.print_and_flush('*** Error: unable to read list of files from {MetadataFile}')
        return False
    for File in Files:
        if not lara_utils.file_exists(File):
            lara_utils.print_and_flush('*** Error: config file not found: {File}')
            return False
    run_lara_test(Files, TestType)

def run_lara_test(ConfigFiles, TestType):
    RecentResults = recent_results_pairs()
    StartTime = time.time()
    lara_utils.print_and_flush(f'--- Running test with {len(ConfigFiles)} texts\n')
    Results = {}
    for ConfigFile in ConfigFiles:
        run_single_lara_test(ConfigFile, TestType, Results, RecentResults)
    print_result_summary(Results, TestType)
    if StartTime is not None: 
        lara_utils.print_and_flush_with_elapsed_time('--- Done', StartTime)

def run_single_lara_test(ConfigFile, TestType, Results, RecentResults):
    StartTime = time.time()
    if TestType == 'resources_and_word_pages':
        run_resources_and_word_pages(ConfigFile, Results, RecentResults)
    if TestType == 'export_import':
        run_export_import_resources_and_word_pages(ConfigFile, Results, RecentResults)
    if TestType == 'tagging':
        run_tagging_resources(ConfigFile, Results, RecentResults)
    if TestType == 'add_metadata':
        run_add_metadata(ConfigFile, Results, RecentResults)
    if TestType == 'distributed':
        run_distributed(ConfigFile, Results, RecentResults)
    EndTime = time.time()
    mark_time_taken(Results, StartTime, EndTime, Params)
    mark_comparison_with_previous_results(Results, RecentResults, ConfigFile, Params)

def run_resources_and_word_pages(ConfigFile, Results, RecentResults):
    Params = lara_config.read_lara_local_config_file(ConfigFile)
    if not Params:
        mark_bad_config_file(Results, ConfigFile)
        return
    ResourcesOK = run_resources_step(ConfigFile, Params, Results)
    if ResourcesOK:
        run_word_pages_step(ConfigFile, Params, Results)    

def run_resources_step(ConfigFile, Params, Results):
    SplitFile = lara_top.lara_tmp_file('split', Params)
    lara_utils.delete_file_if_it_exists(SplitFile)
    try:
        lara_top.compile_lara_local_resources(ConfigFile)
    except:
        mark_bad_resources_step(Results, Params)
        return False
    if not lara_utils.file_exists(SplitFile):
        mark_bad_resources_step(Results, Params)
        return False
    return True
 
def run_word_pages_step(ConfigFile, Params, Results):
    try:
        lara_top.compile_lara_local_word_pages(ConfigFile)
    except:
        mark_bad_word_pages_step(Results, Params)
        return False
    if not files_in_word_pages_directory(Params):
        mark_bad_word_pages_step(Results, Params)
        return False
    mark_good_result(Results, Params)
    return True

def mark_bad_config_file(Results, ConfigFile):
    Results[ConfigFile] = 'bad_config_file'

def mark_bad_resources_step(Results, Params):
    mark_normal_data(Results, Params, 'result', 'bad_resources_step')

def mark_bad_word_pages_step(Results, Params):
    mark_normal_data(Results, Params, 'result', 'bad_word_pages_step')

def mark_good_result(Results, Params):
    mark_normal_data(Results, Params, 'result', 'okay')
    mark_normal_data(Results, Params, 'word_pages', number_of_files_in_word_pages_directory(Params))
    mark_normal_data(Results, Params, 'audio_and_translation_files', lara_top.count_audio_and_translation_files_for_params(Params))

def mark_time_taken(Results, StartTime, EndTime, Params):
    TimeTaken = float('%.2f'%( EndTime - StartTime ))
    mark_normal_data(Results, Params, 'time_taken', TimeTaken)

def mark_normal_data(Results, Params, Key, Value):
    Id = Params.id
    Record = Results[Id] if Id in Results else {}
    Record[Key] = Value
    Results[Id] = Record

def files_in_word_pages_directory(Params):
    _minimum_plausible_number_of_files_in_word_page_directory = 5
    NFiles = number_of_files_in_word_pages_directory(Params)
    return NFiles >= _minimum_plausible_number_of_files_in_word_page_directory

def number_of_files_in_word_pages_directory(Params):
    WordPageDir = lara_top.lara_compiled_dir('word_pages_directory', Params)
    return len(lara_utils.directory_files(WordPageDir))

# ------------------------------------------------

def mark_comparison_with_previous_results(Results, RecentResults, ConfigFile, Params):
    Id = Params.id
    if not Id in Results:
        return
    Record = Results[Id]
    if not 'result' in Record:
        return
    mark_comparison_with_last_good_result_if_wrong(Record, Id, Results, RecentResults)
    for Key in ['audio_and_translation_files', 'word_pages']:
        mark_comparison_with_last_result_if_different(Key, Record, Id, Results, RecentResults)

def mark_comparison_with_last_good_result_if_wrong(Record, Id, Results, RecentResults):
    Outcome = Record['result']
    if Outcome == 'okay':
        return
    Record['last_good_result'] = last_good_result(RecentResults, Id)

def mark_comparison_with_last_result_if_different(Key, Record, Id, Results, RecentResults):
    if not Key in Record:
        return
    Result = Record[Key]
    for ( Timestamp, OldResults ) in RecentResults:
        if Id in OldResults and Key in OldResults[Id]:
            OldResult = OldResults[Id][Key]
            if not results_match(OldResult, Result):
                #lara_utils.print_and_flush(f'--- Different: {OldResult}, {Result}')
                DiffKey = f'{Key}_OLD'
                Record[DiffKey] = ( Timestamp, OldResult )
            return

def last_good_result(RecentResults, Id):
    for ( Timestamp, Data ) in RecentResults:
        if Id in Data and 'result' in Data[Id] and Data[Id]['result'] == 'okay':
            return Timestamp
    return 'never_worked'

def results_match(X, X1):
    if isinstance(X, str):
        return isinstance(X1, str) and X == X1
    if isinstance(X, int):
        return isinstance(X1, int) and X == X1
    if isinstance(X, list):
        return isinstance(X1, list) and lists_match(X, X1)
    if isinstance(X, dict):
        return isinstance(X1, dict) and dicts_match(X, X1)
    return False

def lists_match(X, X1):
    if len(X) != len(X1):
        return False
    if len(X) == 0:
        return True
    return results_match(X[0], X1[0]) and lists_match(X[1:], X1[1:])

def dicts_match(X, X1):
    if not lists_match(sorted(list(X.keys())), sorted(list(X1.keys()))):
        return False
    for Key in X:
        if not results_match(X[Key], X1[Key]):
            return False
    return True

# ------------------------------------------------    

# How many logfiles to go back when looking for the last time something worked
_how_far_back_to_go = 20

def recent_results_pairs():
    return [ ( logfile_name_to_timestamp(Logfile),
               lara_utils.read_json_file(f'{logfile_dir_create_if_necessary()}/{Logfile}') ) 
             for Logfile in last_logfiles() ]

def last_logfiles():
    Files = lara_utils.directory_files(logfile_dir_create_if_necessary())[:_how_far_back_to_go]
    Files.sort(reverse=True)
    return Files

def logfile_name_to_timestamp(Logfile):
    return Logfile.split('.')[0]

# ------------------------------------------------    

def print_result_summary(Results):
    lara_utils.write_json_to_file(Results, get_timestamped_logfile())

def get_timestamped_logfile():
    return f'{logfile_dir_create_if_necessary()}/{lara_utils.timestamp()}.json'

def logfile_dir_create_if_necessary():
    Dir = '$LARA/logfiles'
    lara_utils.create_directory_if_it_doesnt_exist(Dir)
    return Dir
