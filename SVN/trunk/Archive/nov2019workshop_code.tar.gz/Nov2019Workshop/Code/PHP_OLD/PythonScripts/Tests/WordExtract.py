from nltk.tokenize import sent_tokenize, word_tokenize

punctuations = '''!()-[]{};:'"\,<>./?@#$%^&*_~'''

my_str = "سلام پدرجان!!! کجا بودی چرا؟ نیامدی."

# remove punctuation from the string
no_punct = ""
for char in my_str:
   if char not in punctuations:
       no_punct = no_punct + char

words = word_tokenize(no_punct)
print(words)