function showMessage(message, contentID, valType, timeout)
{
    $('#translationError').css("display", "");
    $('.ErrorMsg').html(message);
    setTimeout(function() {
        $('.ErrorMsg').html("");
        $('#translationError').css("display", "none");
      /*  if(contentID != -1)
        {
            $("#mainContentDIV").load('DataTranslation.php?type=' + valType + "&contentID=" + contentID);
        }*/
    }, timeout);
}

function sendTranslation(sendMode)
{
    $("#SendMode").val(sendMode);

    var data = $('#dataTranslationForm').serialize();
    data += "&task=saveData";

    $.ajax({
        url: "../data/SegmentsAndWords.data.php",
        type: "post",
        data: data ,
        success: function (response) {
            var reqResponse = $.parseJSON(response);
            var responseMsg = reqResponse[0].resultMsg;
            var responseID =  reqResponse[0].id;
            var responseType =  reqResponse[0].type;

            if (responseMsg.indexOf("DataIsNOTSavedForItems") != -1)
            {
                showMessage("Not Saved!", responseID, responseType, 3000);
            }
            if (responseMsg.indexOf("FinalCopyFailed") != -1)
            {
                showMessage("Not Copied to Final Destination!", responseID, responseType, 3000);
            }
            else if (responseMsg.indexOf("DataIsSavedForItems") != -1)
            {
                showMessage("Saved Successfully!.", responseID, responseType, 3000);
            }
            else if (responseMsg.indexOf("DataIsSavedAndCopiedForItems") != -1)
            {
                showMessage("Saved and Copied to Final Destination!", responseID, responseType, 3000);
            }
            else
            {
                showMessage("Something goes wrong!.", -1, '', 3000);
            }
        },
        error: function(jqXHR, textStatus, errorThrown) {
            console.log(textStatus, errorThrown);
        }
    });
}

function returnToContent()
{
    $("#mainContentDIV").load('NewLARAContent.php?Q0=' + $("#ContentID").val() + '&activeTab=1');
}