var OperationButtNames = ["Create Resources", "Tag Raw Text"];
var TaskValues = ["CreateResources", "TagRawText"];

function onLoad(activeTab, msgToShow)
{
    $("#OperationButt").prop("value",OperationButtNames[0]);
    $("#task").prop("value",TaskValues[0]);

    var inputNames = Object.keys(contentVal);

    var inputName;
    var inputID;

    for (i = 0; i < inputNames.length; i++) {
        inputName = inputNames[i];
        inputID = "#" + inputName;
        if($('input:radio[name="' + inputName + '"]').length)
        {
            $('input:radio[name="' + inputName + '"]').val([contentVal[inputName]]);
        }
        else
        {
            $(inputID).val(contentVal[inputName]);
        }
    }

    var form = $('#configFileForm');

    var L2 = $('#L2ID').val();
    if(L2 != -1)
    {
        var url = "../data/Language.data.php";
        var data = "LanguageID=" + L2 + "&task=hasTreeTagger";

        $.ajax({
            url: url,
            type: "post",
            data: data,
            success: function(response) {
                if (response.indexOf("YES") != -1) {
                    $("#TreeTaggerStatusTR").css("display","");

                }
                else {
                    $("#TreeTaggerStatusTR").css("display", "none");
                }
            }
        });
    }


    if(contentVal["TreeTaggerStatus"] == 'YES' && $("#RawTextFileName").val()  != "")
    {
        var cmp = "&fileDir=" + contentVal["DirName"] + "/corpus&fileName=Tagged_" + $("#RawTextFileName").val() ;
        $('#TreeTaggerResultDL').attr("href","../top.php?download=taggedFile" + cmp);
        $("#TreeTaggerResultTR").css("display","");
    }

    //OptionalComplementaries
    $( "#OptionalComplementary" ).accordion({
        collapsible: true, active : 'none'
    });
    //embeddedImages
    if($("#HasEmbeddedImage").val() == 'YES' && emItemVal["ImageNames"] != null && emItemVal["ImageNames"] != "")
    {
        var ImageNames = emItemVal["ImageNames"].split("@@");
        var ImageDescription = "";
        for(i = 0 ; i < ImageNames.length; i++)
        {
            var ImageNameParts = ImageNames[i].split(":");
            if(ImageNameParts[1] == 'NO')
            {
                ImageDescription = ImageDescription.concat(ImageNameParts[0] + ",");
            }
        }
        if(ImageDescription == "")
        {
            ImageDescription = "You have already uploaded all images."
        }
        else
        {
            $("#EmbeddedFilesDesc").css("display","");
            ImageDescription = "List of Images: " + ImageDescription ;
        }
        $("#EmbeddedImageTR").css("display","");
        $('#eImageFileName').css("display", "");
        $('#eImageFileName').html(ImageDescription);
    }
    //embeddedAudios
    if($("#HasEmbeddedAudio").val() == 'YES' && emItemVal["AudioNames"] != null && emItemVal["AudioNames"] != "")
    {
        var AudioNames = emItemVal["AudioNames"].split("@@");
        var AudioDescription = "";
        for(i = 0 ; i < AudioNames.length; i++)
        {
            var AudioNameParts = AudioNames[i].split(":");
            if(AudioNameParts[1] == 'NO')
            {
                AudioDescription = AudioDescription.concat(AudioNameParts[0] + ",");
            }
        }
        if(AudioDescription == "")
        {
            AudioDescription = "You have already uploaded all audios."
        }
        else
        {
            $("#EmbeddedFilesDesc").css("display","");
            AudioDescription = "List of Audios: " + AudioDescription ;
        }
        $("#EmbeddedAudioTR").css("display","");
        $('#eAudioFileName').css("display", "");
        $('#eAudioFileName').html(AudioDescription);
    }
    //embeddedCSS
    if($("#HasEmbeddedCSS").val() == 'YES' && emItemVal["cssNames"] != null && emItemVal["cssNames"] != "")
    {
        var cssNames = emItemVal["cssNames"].split("@@");
        var CssDescription = "";
        for(i = 0 ; i < cssNames.length; i++)
        {
            var CssNameParts = cssNames[i].split(":");
            if(CssNameParts[1] == 'NO')
            {
                CssDescription = CssDescription.concat(CssNameParts[0] + ",");
            }
        }
        if(CssDescription == "")
        {
            CssDescription = "You have already uploaded all css files."
        }
        else
        {
            $("#EmbeddedFilesDesc").css("display","");
            CssDescription = "List of CSS: " + CssDescription ;
        }
        $("#EmbeddedCssTR").css("display","");
        $('#eCssFileName').css("display", "");
        $('#eCssFileName').html(CssDescription);
    }
    //embeddedScript
    if($("#HasEmbeddedScript").val() == 'YES' && emItemVal["ScriptNames"] != null && emItemVal["ScriptNames"] != "")
    {
        var scriptNames = emItemVal["ScriptNames"].split("@@");
        var ScriptDescription = "";
        for(i = 0 ; i < scriptNames.length; i++)
        {
            var ScriptNameParts = scriptNames[i].split(":");
            if(ScriptNameParts[1] == 'NO')
            {
                ScriptDescription = ScriptDescription.concat(ScriptNameParts[0] + ",");
            }
        }
        if(ScriptDescription == "")
        {
            ScriptDescription = "You have already uploaded all script files."
        }
        else
        {
            $("#EmbeddedFilesDesc").css("display","");
            ScriptDescription = "List of Script: " + ScriptDescription ;
        }
        $("#EmbeddedScriptTR").css("display","");
        $('#eScriptFileName').css("display", "");
        $('#eScriptFileName').html(ScriptDescription);
    }

    $("#FirstPhaseResultTR").css("display","");
    var cmp = "&fileDir=" + contentVal["DirName"] + "/corpus&fileName=FirstPhaseFor" + $("#ContentName").val().split(' ').join('') + ".zip";
    $('#FirstPhaseResultDL').attr("href","../top.php?download=firstPhase" + cmp);

    $('#WordTrnslt').click(function () {
        $("#mainContentDIV").load('DataTranslation.php?type=word&contentID=' + $("#ContentID").val());
    });

    $('#SgmntTrnslt').click(function () {
        $("#mainContentDIV").load('DataTranslation.php?type=segment&contentID=' + $("#ContentID").val());
    });

    $('#UploadWordTrnslt').change(function() {
        $("#task").val("UploadWordTrnslt");
        saveSubcontentTranslation();
    });

    $('#UploadSgmntTrnslt').change(function() {
        $("#task").val("UploadSgmntTrnslt");
        saveSubcontentTranslation();
    });

    if($("#WebAddress").val() != "") {

        var FolderName = $('#ContentName').val().split(' ').join('_') + 'vocabpages';

        var cmpld = "&folderDir=" + contentVal["DirName"] + "/&folderName=" + FolderName;
        $('#CompiledFolderDL').attr("href","../top.php?download=compiledContent" + cmpld);

        $("#WebAddressTR").css("display", "");
    }

    $( "#tabs" ).tabs();
    $( "#tabs" ).tabs( "option", "active", activeTab);

    if(msgToShow != "notSetYet")
    {
        showMessageOnload(msgToShow);
    }
}

$("#L2ID").change(function(e) {
    $('#TreeTaggerStatus').prop('checked', false);
    $("#RawTextTR").css("display","none");
    $("#ComplementaryDiv").css("display","");
    $('#OperationButt').prop('value', OperationButtNames[0]);
    $("#task").prop("value",TaskValues[0]);
    var valueSelected = this.value;

    var url = "../data/Language.data.php";
    var data = "LanguageID=" + valueSelected + "&task=hasTreeTagger";

    $.ajax({
        url: url,
        type: "post",
        data: data,
        success: function(response) {
            if (response.indexOf("YES") != -1) {
                $("#TreeTaggerStatusTR").css("display","");

            }
            else {
                $("#TreeTaggerStatusTR").css("display", "none");
            }
        }
    });
});

$("#RawText").change(function(e) {
    var PrvRawText = $("#RawTextFileName").val();
    var fileName = e.target.files[0].name;
    if(PrvRawText != "")
    {
        var confMsg = "You have already uploaded " + PrvRawText + " and the tagged file is ready to downlad. " +
            "Are you sure you want to tag another file?"
        if(confirm(confMsg))
        {
            var alrtMsg = "Okay.. New file named " + fileName + " is selected. Do not forget to click on" +
                " 'Tag Raw text' button to tag it.";
            alert(alrtMsg);
            $('#rawFileName').css("display", "");
            $('#rawFileName').html(fileName);
            $('#TreeTaggerPRV').css("display", "none");
        }
        else
        {
            $("#RawText").val('');
        }
    }
    else
    {
        $('#rawFileName').css("display", "");
        $('#rawFileName').html(fileName);
    }

});

$("#TaggedText").change(function(e) {
    var PrvTaggedText = $("#TaggedTextFileName").val();
    var fileName = e.target.files[0].name;
    if(PrvTaggedText != "")
    {
        var confMsg = "You have already uploaded " + PrvTaggedText + " and made resources for it. " +
            "Are you sure you want to change it?"
        if(confirm(confMsg))
        {
            var alrtMsg = "Okay.. New file named " + fileName + " is selected. Do not forget to click on" +
                " 'Create Resources' button. Keep in mind that the resources might change.";
            alert(alrtMsg);
            $('#taggedFileName').css("display", "");
            $('#taggedFileName').html(fileName);
            $('#TaggedPRV').css("display", "none");

        }
        else
        {
            $("#TaggedText").val('');
        }
    }
    else
    {
        $('#taggedFileName').css("display", "");
        $('#taggedFileName').html(fileName);
    }
});

$("#EmbeddedAudio").change(function(e) {
    var fileName = e.target.files[0].name;
    $('#eAudioFileName').css("display", "");
    $('#eAudioFileName').html(fileName);
});

$("#EmbeddedCss").change(function(e) {
    var fileName = e.target.files[0].name;
    $('#eCssFileName').css("display", "");
    $('#eCssFileName').html(fileName);
});

$("#EmbeddedImage").change(function(e) {
    var fileName = e.target.files[0].name;
    $('#eImageFileName').css("display", "");
    $('#eImageFileName').html(fileName);
});

$("#EmbeddedScript").change(function(e) {
    var fileName = e.target.files[0].name;
    $('#eScriptFileName').css("display", "");
    $('#eScriptFileName').html(fileName);
});

$( "#TreeTaggerStatus").change(function(e) {
    var $input = $( this );
    if($input.is( ":checked" )){
        $("#RawTextTR").css("display","");
        $("#ComplementaryDiv").css("display","none");
        $('#OperationButt').prop('value', OperationButtNames[1])
        $("#task").prop("value",TaskValues[1]);

    }
    else
    {
        $("#RawTextTR").css("display","none");
        $("#ComplementaryDiv").css("display","");
        $('#OperationButt').prop('value', OperationButtNames[0])
        $("#task").prop("value",TaskValues[0]);
    }
});

$( "#ExternalResourceStatus").change(function(e) {
    var $input = $( this );
    if($input.is( ":checked" )){
        $("#ExternalResourceTR").css("display","");
    }
    else{
        $("#ExternalResourceTR").css("display","none");
    }
});

$("#ExternalResource").change(function(e) {
    var fileName = e.target.files[0].name;
    $('#ExternalResFileName').css("display", "");
    $('#ExternalResFileName').html(fileName);
});

function createResources()
{
    var activeTab = 0;
    //task values : "CreateResources" OR "TagRawText"
    if(validateConfigFileForm())
    {
        showLoading('#mainContentDIV');
        var form = $('#configFileForm');
        var formdata = false;
        if (window.FormData){
            formdata = new FormData(form[0]);
        }
        var data = formdata ? formdata : form.serialize();
        $.ajax({
            url         : '../data/Content.data.php',
            data        : data,
            cache       : false,
            contentType : false,
            processData : false,
            type        : 'POST',
            success: function (response) {
                hideLoading('#mainContentDIV');
                var reqResponse = $.parseJSON(response);
                var responseMsg = reqResponse[0].resultMsg;
                var responseID =  reqResponse[0].id;
                $("#mainContentDIV").load('NewLARAContent.php?Q0=' + responseID +
                            '&activeTab=' + activeTab + '&msg=' + responseMsg);

            },
            error: function(jqXHR, textStatus, errorThrown) {
                console.log(textStatus, errorThrown);
                alert("Something is wrong here.");
            }
        });
    }
    else
    {
        setTimeout(function() {
            $('.configFileError').css("display", "none");
        }, 3000);

    }
}

function createPages()
{
    var activeTab = 2;

    if(validatePageCreation())
    {
        showLoading('#mainContentDIV');
        var data = { task: "CreatePages", contentID :  $("#ContentID").val(),
            tokenType : $("#tokenType").val(), accessToken : $("#accessToken").val()};
        $.ajax({
            url         : '../data/Content.data.php',
            data        : data,
            type        : 'GET',
            contentType : 'application/json; charset=utf-8',

            success: function (response) {
                hideLoading('#mainContentDIV');
                var reqResponse = $.parseJSON(response);
                var responseMsg = reqResponse[0].resultMsg;
                var responseID =  reqResponse[0].id;

                $("#mainContentDIV").load('NewLARAContent.php?Q0=' + responseID +
                    '&activeTab=' + activeTab + '&msg=' + responseMsg);
            },
            error: function(jqXHR, textStatus, errorThrown) {
                console.log(textStatus, errorThrown);
                alert("Something is wrong here.");
            }
        });
    }
    else
    {
        setTimeout(function() {
            $('.configFileError').css("display", "none");
        }, 3000);
    }
}

function publishResource()
{
    var activeTab = 2;
    var publishType = 'Insert';
    var confMsg = "Are you sure you want to publish " + $('#ContentName').val() + "?";
    if($('#UsageInReadingsCount').val() != 0)
    {
        publishType = $('#PublishOptions').val();
        if(publishType == 'Undefined')
        {
            alert("Please select the publishing method.");
            return;
        }
    }
    if(confirm(confMsg))
    {
        var data = { task: "PublishContent", contentID :  $('#ContentID').val(), publishType : publishType};
        $.ajax({
            url         : '../data/Content.data.php',
            data        : data,
            type        : 'GET',
            contentType : 'application/json; charset=utf-8',

            success: function (response) {
                var reqResponse = $.parseJSON(response);
                var responseMsg = reqResponse[0].resultMsg;
                var responseID =  reqResponse[0].id;

                $("#mainContentDIV").load('NewLARAContent.php?Q0=' + responseID +
                    '&activeTab=' + activeTab + '&msg=' + responseMsg);
            },
            error: function(jqXHR, textStatus, errorThrown) {
                console.log(textStatus, errorThrown);
                alert("Something is wrong here.");
            }
        });
    }
}

function validateConfigFileForm()
{
    var ContentName = $('#ContentName').val();
    var L1 = $('#L1ID').val();
    var L2 = $('#L2ID').val();

    $('.configFileError').css("display", "");

    if(ContentName == "")
    {
        $('.ErrorMsg').html('Please Enter a Name for the Content');
        return false;
    }

    if(L1 == -1)
    {
        $('.ErrorMsg').html('Please Select a Language as L1');
        return false;
    }

    if(L2 == -1)
    {
        $('.ErrorMsg').html('Please Select a Language as L2');
        return false;
    }

    if(L1 == L2)
    {
        $('.ErrorMsg').html('Languages for L1 and L2 Can Not Be the Same.');
        return false;
    }

    var currentRawText = $('#RawText').val();
    var currentTaggedText = $("#TaggedText").val();
    var currentImage = $("#EmbeddedImage").val();
    var currentAudio = $("#EmbeddedAudio").val();
    var currentCss = $("#EmbeddedCss").val();
    var currentScript = $("#EmbeddedScript").val();
    var currentExtRes = $("#ExternalResource").val();

    if(currentRawText != '' &&
        (currentTaggedText != '' ||
         currentImage != '' ||
         currentAudio != '' ||
         currentCss != '' ||
         currentScript != '' ||
         currentExtRes != ''))
    {
        if($("#task").val() == TaskValues[0])//create resource
        {
            var msg = "You have selected new file for tagging. Are you sure you want to ignore it" +
                " and create resources for " + currentTaggedText + "?";
            if(!confirm(msg))
            {
                return false;
            }
        }
        else if($("#task").val() == TaskValues[1])//tag raw text
        {
            var msg = "Are you sure you want to ignore creating resources " +
                " and tag " + currentRawText + "?";
            if(!confirm(msg))
            {
                return false;
            }
        }
    }

    if($("#task").val() == TaskValues[0])//create resource
    {
        var WordAudioVal = $('#WordAudio').val();
        var SegmentAudioVal = $('#SegmentAudio').val();
        var notSelectedItems = new Array();
        var notSelectedItemsIndex = 0;

        if (!$("input[name='L1rtl']").is(':checked'))
        {
            notSelectedItems[notSelectedItemsIndex] = "L1 is Right to Left";
            notSelectedItemsIndex++;
        }
        if (!$("input[name='AudioMouseOver']").is(':checked'))
        {
            notSelectedItems[notSelectedItemsIndex] = "Audio MouseOver";
            notSelectedItemsIndex++;
        }
        if (!$("input[name='WordTranslationMouseOver']").is(':checked'))
        {
            notSelectedItems[notSelectedItemsIndex] = "Word Translation MouseOver";
            notSelectedItemsIndex++;
        }
        if (!$("input[name='SegmentTranslationMouseOver']").is(':checked'))
        {
            notSelectedItems[notSelectedItemsIndex] = "Segment Translation MouseOver";
            notSelectedItemsIndex++;
        }
        if(notSelectedItemsIndex != 0)
        {
            var errorMsg = "Please select a value for these items:</br>";
            for(i = 0 ; i < notSelectedItems.length; i++)
            {
                errorMsg += notSelectedItems[i] + "</br>";
            }
            $('.ErrorMsg').html(errorMsg);
            return false;
        }

        var PrvTaggedText = $("#TaggedTextFileName").val();
        var ext = $('#TaggedText').val().split('.').pop().toLowerCase();

        if(currentTaggedText == "" && PrvTaggedText == "")
        {
            $('.ErrorMsg').html('Please Upload the Tagged Text File.');
            return false;
        }
        if(currentTaggedText != "" && $.inArray(ext, ['txt', 'docx']) == -1) {
            $('.ErrorMsg').html('Invalid Extention! Please Upload a .txt or .docx File.');
            return false;
        }

        //Let's do some checking about embedded items
        if($("#HasEmbeddedImage").val == 'YES' && currentImage == '')
        {
            var msg = "Are you sure you want to continue without uploading images?";
            if(!confirm(msg))
            {
                return false;
            }
        }
        if($("#HasEmbeddedAudio").val == 'YES' && currentAudio == '')
        {
            var msg = "Are you sure you want to continue without uploading audios?";
            if(!confirm(msg))
            {
                return false;
            }
        }
        if($("#HasEmbeddedCSS").val == 'YES' && currentCss == '')
        {
            var msg = "Are you sure you want to continue without uploading css files? ";
            if(!confirm(msg))
            {
                return false;
            }
        }
        if($("#HasEmbeddedScript").val == 'YES' && currentScript == '')
        {
            var msg = "Are you sure you want to continue without uploading scripts? ";
            if(!confirm(msg))
            {
                return false;
            }
        }
        if($("#ExternalResourceStatus").is(":checked") && currentExtRes == '')
        {
            var msg = "Are you sure you want to continue without uploading external resources? ";
            if(!confirm(msg))
            {
                return false;
            }
        }
        if($("#HasExternalResources").val == 'YES' && $("#ExternalResourceStatus").is(":checked") && currentExtRes != '')
        {
            var msg = "You have already import an external resource. Are you sure you want to add another one?";
            if(!confirm(msg))
            {
                return false;
            }
        }
    }
    else if($("#task").val() == TaskValues[1])//tag raw text
    {
        var PrvRawText = $("#RawTextFileName").val();
        var ext = $('#RawText').val().split('.').pop().toLowerCase();

        if(currentRawText == "" && PrvRawText == "")
        {
            $('.ErrorMsg').html('Please Upload the Raw Text File.');
            return false;
        }
        if(currentRawText != "" && $.inArray(ext, ['txt', 'docx']) == -1) {
            $('.ErrorMsg').html('Invalid Extention! Please Upload a .txt or docx File.');
            return false;
        }
    }

    $('.configFileError').css("display", "none");
    return true;
}

function validatePageCreation()
{
    $('.configFileError').css("display", "");

    if (!$("input[name='ReadyToCompile']").is(':checked'))
    {
        $('.ErrorMsg').html('Please confirm that you want to create pages with the current state');
        return false;
    }
    $('.configFileError').css("display", "none");
    return true;
}

function saveSubcontentTranslation()
{
    var activeTab = 1;

    var form = $('#configFileForm');
    var formdata = false;
    if (window.FormData){
        formdata = new FormData(form[0]);
    }
    var data = formdata ? formdata : form.serialize();
    $.ajax({
        url         : '../data/SegmentsAndWords.data.php',
        data        : data,
        cache       : false,
        contentType : false,
        processData : false,
        type        : 'POST',
        success: function (response) {
            var reqResponse = $.parseJSON(response);
            var responseMsg = reqResponse[0].resultMsg;
            var responseID =  reqResponse[0].id;

            $("#mainContentDIV").load('NewLARAContent.php?Q0=' + responseID +
                '&activeTab=' + activeTab + '&msg=' + responseMsg);
        },
        error: function(jqXHR, textStatus, errorThrown) {
            console.log(textStatus, errorThrown);
            alert("Something is wrong here", 5000);
        }
    });
}

function showMessageOnload(message)
{
    var msgText = getMsgText(message);
    $('.configFileError').css("display", "");
    $('.ErrorMsg').html(msgText);
}

function getMsgText(responseMsg)
{
    var msgToShow;
    if (responseMsg == "fileUploadError")
    {
        msgToShow = "You should upload a text file as raw text.";
    }
    else if (responseMsg == "RtFileTypeError")
    {
        msgToShow = "Uploaded raw text file must be a txt or docx.";
    }
    else if (responseMsg == "TtFileTypeError")
    {
        msgToShow = "Uploaded tagged text file must be a txt or docx.";
    }
    else if (responseMsg == "extResTypeError")
    {
        msgToShow = "External Resources must be uploaded in zip format.";
    }
    else if (responseMsg == "eAudioTypeError")
    {
        msgToShow = "Embedded audios must be uploaded in zip format.";
    }
    else if (responseMsg == "eCSSTypeError")
    {
        msgToShow = "Embedded CSS must be uploaded in zip format.";
    }
    else if (responseMsg == "eImageTypeError")
    {
        msgToShow = "Embedded images must be uploaded in zip format.";
    }
    else if (responseMsg == "eScriptTypeError")
    {
        msgToShow = "Embedded scripts must be uploaded in zip format.";
    }
    else if (responseMsg == "CreateDIRFailed")
    {
        msgToShow = "Failed to create the directory.";
    }
    else if (responseMsg == "CreateSubDIRFailed")
    {
        msgToShow = "Failed to create one of the subdirectories.";
    }
    else if (responseMsg == "UploadFileFailed")
    {
        msgToShow = "Failed to upload the file.";
    }
    else if (responseMsg == "TaggedFileFailed")
    {
        msgToShow = "Failed to tag the file.";
    }
    else if (responseMsg == "TaggedFileCreated")
    {
        msgToShow = "Tagged file is created and ready to download.";
    }
    else if (responseMsg == "FirstCompileStepFailed")
    {
        msgToShow = "Failed to complete the first phase of compiling.";
    }
    else if (responseMsg == "CreateLDTTaskFailed")
    {
        msgToShow = "Failed to create LDT task for audio parts.";
    }
    else if (responseMsg == "FirstCompileStepDone")
    {
        msgToShow = "Resources are created and ready to download.";
    }
    else if (responseMsg == "hasEmbedded")
    {
        msgToShow = "The tagged file has embedded media. Please upload them.";
    }
    else if (responseMsg == "FailedToOpenZipFile")
    {
        msgToShow = "Unable to open the the uploaded zip file.";
    }
    else if (responseMsg == "FailedToExtractZipFile")
    {
        msgToShow = "Unable to extract the uploaded zip file.";
    }
    else if (responseMsg == "FailedToExtractExtResFile")
    {
        msgToShow = "Unable to extract the uploaded zip file for External resource.";
    }
    else if (responseMsg == "MergeLanguageResourcesFailed")
    {
        msgToShow = "Unable to merge the uploaded file for External resource.";
    }
    else if(responseMsg == "InstallPrvAudioFailed")
    {
        msgToShow = "Installing recorded audio failed.";
    }
    else if(responseMsg == "MetadataToDatabaseFailed")
    {
        msgToShow = "Saving metadata info to database failed.";
    }
    else if(responseMsg == "DeletePrvWordFailed")
    {
        msgToShow = "Deleting previous recorded audio for words failed.";
    }
    else if(responseMsg == "DeletePrvSegFailed")
    {
        msgToShow = "Deleting previous recorded audio for segments failed.";
    }
    else if(responseMsg == "FailToSegmentize")
    {
        msgToShow = "Auto segmentation failed.";
    }
    else if(responseMsg == "DownloadFromLdtFailed")
    {
        msgToShow = "Downloading recorded audio from LDT failed.";
    }
    else if(responseMsg == "InstallNolLDTAudioFailed")
    {
        msgToShow = "Installing non-ldt recorded audio failed.";
    }
    else if(responseMsg == "PageCreationDone")
    {
        msgToShow = "Pages are created and copied to the web.";
    }
    else if(responseMsg == "CopyingPagesFailed")
    {
        msgToShow = "Copying pages to web failed.";
    }
    else if(responseMsg == "CreatePagesFailed")
    {
        msgToShow = "Creating pages failed.";
    }
    else if(responseMsg == "InstallZipfileFailed")
    {
        msgToShow = "Installing recorded audio from LDT failed.";
    }
    else if(responseMsg == "FailedToCopyResource")
    {
        msgToShow = "Failed to copy content resource.";
    }
    else if(responseMsg == "FailedToCopyLangResource")
    {
        msgToShow = "Failed to copy language resource.";
    }
    else if(responseMsg == "FailedPublish")
    {
        msgToShow = "Failed to publish.";
    }
    else if(responseMsg == "FailedToExtractPageNames")
    {
        msgToShow = "Could not extract the page names of the resource.";
    }
    else if(responseMsg == "SuccessfulPublish")
    {
        msgToShow = "Resource is published successfully.";
    }
    else if (responseMsg == "fileTypeError")
    {
        msgToShow = "Uploaded file format must be CSV.";
    }
    else if (responseMsg == "FinalCopyFailed")
    {
        msgToShow = "Copied to Final Destination Failed!";
    }
    else if (responseMsg == "UploadedAndCopied")
    {
        msgToShow = "Saved and Copied to Final Destination!";
    }
    else if (responseMsg == "TransferToDbFailed")
    {
        msgToShow = "Transferring to Database Failed!";
    }
    else if (responseMsg == "UploadFileFailed")
    {
        msgToShow = "Uploading to Server Failed!";
    }
    return msgToShow;
}

function showPythonOutput()
{
    var data = { task: "PythonOutputDetail",
                 relatedID :  $('#ContentID').val(),
                 relatedPage : "content"};
    $.ajax({
            url         : '../top.php',
            data        : data,
            type        : 'GET',
            contentType : 'application/json; charset=utf-8',

            success: function (response)
            {
                $('.ErrorMsg').html(response);
            },
            error: function(jqXHR, textStatus, errorThrown) {
                console.log(textStatus, errorThrown);
                alert("Something is wrong here.");
            }
        });
}

function onLoadLaraContents()
{
    $('#TableOfContents').DataTable();
}

function deleteContent(contentID, contentName)
{
    var confMsg = "Are you sure you want to delete " + contentName + "?";
    if(confirm(confMsg))
    {
        var data = { task: "DeleteContent", contentID :  contentID};
        $.ajax({
            url         : '../data/Content.data.php',
            data        : data,
            type        : 'GET',
            contentType : 'application/json; charset=utf-8',

            success: function (response) {
                var reqResponse = $.parseJSON(response);
                var responseMsg = reqResponse[0].resultMsg;
                var responseID =  reqResponse[0].id;

                if(responseMsg == "FailedDelete")
                {
                    alert("Failed to delete.");
                }
                else if(responseMsg == "SuccessfulDelete")
                {
                    $("#mainContentDIV").load('LARAContents.php');
                }
            },
            error: function(jqXHR, textStatus, errorThrown) {
                console.log(textStatus, errorThrown);
                alert("Something is wrong here.");
            }
        });
    }
}

function forHani()
{
    $("#task").val("forHani");
    var form = $('#configFileForm');
    var formdata = false;
    if (window.FormData){
        formdata = new FormData(form[0]);
    }
    var data = formdata ? formdata : form.serialize();
    $.ajax({
        url         : '../data/Content.data.php',
        data        : data,
        cache       : false,
        contentType : false,
        processData : false,
        type        : 'POST',

        success: function (response) {
            var reqResponse = $.parseJSON(response);
            var responseMsg = reqResponse[0].resultMsg;
            var responseID =  reqResponse[0].id;

            alert(responseMsg);


        },
        error: function(jqXHR, textStatus, errorThrown) {
            console.log(textStatus, errorThrown);
            alert("Something is wrong in forHani.");
        }
    });
}