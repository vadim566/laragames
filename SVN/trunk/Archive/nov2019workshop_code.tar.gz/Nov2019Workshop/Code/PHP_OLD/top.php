<?php

session_start();

//serverSetting

define("ROOT", "/export/data/www/issco-site/en/research/projects/LARA-portal/trunk/Code/PHP/");
define("PythonDir","/export/data/www/issco-site/en/research/projects/LARA-portal/trunk/Code/Python/");
define("SVNContentDir","/export/data/www/issco-site/en/research/projects/LARA-portal/trunk/Content/");
define("LaraContentDir","/export/data/www/LARA-data/");
define("WorkingTmpDirectory","/export/data/www/LARA-data/WorkingTmpDirectory/");
define("ContentTmpDirectory","/export/data/www/LARA-data/ContentTmpDirectory/");
define("ExternalResourceDirectory","/export/data/www/LARA-data/ExternalResourceDirectory/");
define("CallectorDir","/export/data/www/issco-site/en/research/projects/callector/");
define("LaraEnv", "LARA='/export/data/www/issco-site/en/research/projects/LARA-portal/trunk'");
define("TreeTaggerEnv", "TREETAGGER='/usr/local/TreeTagger'");
define("WebRoot", "https://www.issco.unige.ch/en/research/projects/callector/");
define("PythonCmnd", "python3.7");
define("DistributedDir","/export/data/www/issco-site/en/research/projects/callector/LaraResourceContent/");
define("ReadingHistoryDir","/export/data/www/issco-site/en/research/projects/callector/LaraReadingHistories/");
define("PortalReadingHistoryDir","/en/research/projects/callector/LaraReadingHistories/");
define("DistributedWebRoot", "https://www.issco.unige.ch/en/research/projects/callector/LaraResourceContent/");

//EL stands for ExternalLog
define("EL_TypePythonCmnd", "PythonCmnd");
define("EL_TypePythonRes", "PythonRes");
define("EL_TypeLdtCmnd", "LdtCmnd");
define("EL_TypeLdtRes", "LdtRes");
define("EL_TypeConfigFile", "ConfigFile");

//CL stands for Construction Log
define("CL_FailedMakeDir", "Unsuccessful attempt to creat the directory");
define("CL_SuccessfulMakeDir", "Create the root directory for content");
define("CL_RenameRootDir", "Rename related folder on server");

define("CL_FailedUploadRawText", "Unsuccessful attempt to upload raw Text");
define("CL_SuccessfulUploadRawText", "Upload raw Text");

define("CL_FailedTagging", "Unsuccessful attempt to tag the raw file");
define("CL_SuccessfulTagging", "Create tagged file based on the raw file");

define("CL_CreateConfigFile_Limited", "Create limited config file");
define("CL_CreateConfigFile", "Created complete config file");

define("CL_FailedUploadTaggedText", "Unsuccessful attempt to upload tagged Text");
define("CL_SuccessfulUploadTaggedText", "Upload tagged Text");


define("CL_HasEmbeddedFiles", "The tagged file has embedded items.");
define("CL_NoEmbeddedFiles", "The tagged file has NO embedded items.");

define("CL_FailedUploadEmbImage", "Unsuccessful attempt to upload embedded images");
define("CL_SuccessfulUploadEmbImage", "Upload Embedded images");

define("CL_FailedUploadEmbCSS", "Unsuccessful attempt to upload embedded CSS");
define("CL_SuccessfulUploadEmbCSS", "Upload Embedded CSS");

define("CL_FailedUploadEmbScript", "Unsuccessful attempt to upload embedded script");
define("CL_SuccessfulUploadEmbScript", "Upload Embedded script");

define("CL_FailedUploadEmbAudio", "Unsuccessful attempt to upload embedded audios");
define("CL_SuccessfulUploadEmbAudio", "Upload Embedded audios");

define("CL_FailedResourceFiles", "Unsuccessful attempt to create resource files");
define("CL_SuccessfulResourceFiles", "Create resource files");

const SubDirNames = array("audio" => "audio",
    "corpus" => "corpus",
    "images" => "images",
    "translations" => "translations");

const SubDirNamesContentTmp = array("compiled" => "compiled",
    "laraTmpDirectory" => "laraTmpDirectory");

const EmbeddedItemsTypes = array("Image" => "Image",
    "Audio" => "Audio",
    "CSS" => "CSS",
    "Script" => "Script");

require_once "DataLayer/FolderZipArchive.class.php";
require_once "class/ExternalCommandsLogs.class.php";
require_once "class/DistributedResource.class.php";


function CreateResponse($val)
{
    if (is_string($val)) return '"'.addslashes($val).'"';
    if (is_numeric($val)) return $val;
    if ($val === null) return 'null';
    if ($val === true) return 'true';
    if ($val === false) return 'false';

    $assoc = false;
    $i = 0;
    foreach ($val as $k=>$v){
        if ($k !== $i++){
            $assoc = true;
            break;
        }
    }
    $res = array();
    foreach ($val as $k=>$v){
        $v = CreateResponse($v);
        if ($assoc){
            $k = '"'.addslashes($k).'"';
            $v = $k.':'.$v;
        }
        $res[] = $v;
    }
    $res = implode(',', $res);
    return ($assoc)? '{'.$res.'}' : '['.$res.']';
}

function objToJS($object, $jsObjName)
{
    $objArr = get_object_vars($object);
    $retVal = "<script>var ". $jsObjName." = " . json_encode($objArr). "</script>";
    return $retVal;
}

function LogIntoLDT()
{

    $url = 'https://regulus.unige.ch/litedevtools/server/token';

    $post = array (
        'grant_type' => 'password',
        'username' => 'lara',
        'password' => 'p0rt@l!'
    );

    $query = http_build_query($post);

    $header = array(
        "Content-Type: application/x-www-form-urlencoded",
        "Content-Length: ".strlen($query),
        "User-Agent:MyAgent/1.0");

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_HEADER, 0);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/4.0 (compatible;)");
    curl_setopt($ch, CURLOPT_HTTPHEADER,$header);
    curl_setopt($ch, CURLOPT_FRESH_CONNECT, 1);
    curl_setopt($ch, CURLOPT_FORBID_REUSE, 1);
    curl_setopt($ch, CURLOPT_TIMEOUT, 100);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $query);

    $result = curl_exec($ch);

    $resultArray = array();

    if ($result === FALSE)
    {
        $resultArray["access_token"] = "LDTAuthenticationFailed";
        $result = CreateResponse($resultArray);
        curl_close($ch);
        return $result;
    }
    else
    {
        curl_close($ch);
        return $result;
    }
}

function RemoveDir($dir) {
    if (is_dir($dir)) {
        $objects = scandir($dir);
        foreach ($objects as $object) {
            if ($object != "." && $object != "..") {
                if (is_dir($dir."/".$object))
                    RemoveDir($dir."/".$object);
                else
                    unlink($dir."/".$object);
            }
        }
        rmdir($dir);
    }
}

function ExternalCmndLog($LogType, $LogData, $HistoryID, $RelatedPage)
{
    $ExternalLog = new ExternalCommandsLogs();
    $ExternalLog->LogType = $LogType;
    $ExternalLog->LogData = $LogData;
    $ExternalLog->LogDateTime = (new DateTime('now'))->format('Y-m-d H:i:s');
    $ExternalLog->UserID = $_SESSION['UserID'];
    $ExternalLog->RelatedID = $HistoryID;
    $ExternalLog->RelatedPage = $RelatedPage;

    $ExternalLog->insert();

    return true;
}

if(isset($_REQUEST["download"]))
{
    if($_REQUEST["download"] == "rawFile" ||
        $_REQUEST["download"] == "taggedFile")
    {
        $fileDir = LaraContentDir . $_REQUEST["fileDir"];
        $fileName = $_REQUEST["fileName"];

        $FileNameParts = explode('.', $fileName);
        $FileExt = $FileNameParts[count($FileNameParts) - 1];
        $FileExt = strtolower($FileExt);
        if ($FileExt == "txt")
            $mimeType = "text/plain";
        else if ($FileExt == "docx")
            $mimeType = "application/vnd.openxmlformats-officedocument.wordprocessingml.document";

        ob_end_clean();

        header('Content-Type: '.$mimeType);
        header('Content-Disposition: attachment; filename="' . basename($fileName) . '";');
        header('Content-Transfer-Encoding: binary');
        header('Expires: 0');
        header('Cache-Control: must-revalidate');
        header('Pragma: public');
        header('Content-Length: ' . filesize($fileDir . "/" . $fileName));

        readfile($fileDir . "/" . $fileName);
        exit;

    }

    else if ($_REQUEST["download"] == "firstPhase")
    {
        $fileDir = LaraContentDir . $_REQUEST["fileDir"];
        $fileName = $_REQUEST["fileName"];


        $zip = new ZipArchive;
        $tmp_file =  $fileDir . "/" .$fileName;
        if ($zip->open($tmp_file,  ZipArchive::CREATE)) {
            $zip->addFile($fileDir . '/local_config.json', 'local_config.json');
            $zip->addFile($fileDir . '/segment_recording.txt', 'segment_recording.txt');
            $zip->addFile($fileDir . '/segment_translation.csv', 'segment_translation.csv');
            $zip->addFile($fileDir . '/word_recording.txt', 'word_recording.txt');
            $zip->addFile($fileDir . '/word_translation.csv', 'word_translation.csv');
            $zip->close();

            ob_end_clean();
            header('Content-type: application/zip');
            header("Content-length: " . filesize($tmp_file));
            header("Pragma: no-cache");
            header("Expires: 0");
            header('Content-disposition: attachment; filename="' . basename($fileName) . '";');
            readfile($tmp_file);
            exit;
        } else {
            echo 'Failed!';
        }
    }

    else if ($_REQUEST["download"] == "finalPack")
    {
        $input = LaraContentDir . $_REQUEST["folderDir"] ;
        $output = LaraContentDir . $_REQUEST["folderDir"] . "/" . $_REQUEST["zipFolderName"] ;

        new FolderZipArchive($input, $output);

        ob_end_clean();
        header('Content-type: application/zip');
        header("Content-length: " . filesize($output));
        header("Pragma: no-cache");
        header("Expires: 0");
        header('Content-disposition: attachment; filename="' . basename($output) . '";');
        readfile($output);
        exit;
    }
    else if ($_REQUEST["download"] == "finalResourcePack")
    {
        $input = CallectorDir . $_REQUEST["folderDir"] ;
        $output = CallectorDir . $_REQUEST["folderDir"] . "/" . $_REQUEST["zipFolderName"] ;

        new FolderZipArchive($input, $output);

        ob_end_clean();
        header('Content-type: application/zip');
        header("Content-length: " . filesize($output));
        header("Pragma: no-cache");
        header("Expires: 0");
        header('Content-disposition: attachment; filename="' . basename($output) . '";');
        readfile($output);
        exit;
    }
    else if ($_REQUEST["download"] == "compiledContent")
    {
        $input = ContentTmpDirectory . $_REQUEST["folderDir"] . "/compiled/" . $_REQUEST["folderName"] ;
        $output = ContentTmpDirectory . $_REQUEST["folderDir"] . "/" . $_REQUEST["folderName"] . ".zip";

        new FolderZipArchive($input, $output);

        ob_end_clean();
        header('Content-type: application/zip');
        header("Content-length: " . filesize($output));
        header("Pragma: no-cache");
        header("Expires: 0");
        header('Content-disposition: attachment; filename="' . basename($output) . '";');
        readfile($output);
        exit;
    }
    else if($_REQUEST["download"] == "pythonTrace")
    {
        if(isset($_REQUEST["contentID"]))
            $temp = ExternalCommandsLogs::SearchExternalCommandsLogs($_REQUEST["contentID"], 'content');
        else if(isset($_REQUEST["rhID"]))
            $temp = ExternalCommandsLogs::SearchExternalCommandsLogs($_REQUEST["rhID"], 'history');

        $fileContent = "pythonTrace:" . "\n";
        for($i = 0; $i < count($temp); $i++)
        {
            $fileContent .= $temp[$i]["LogTime"] . " *** " . $temp[$i]["LogInfo"];
            $fileContent .=  "\n" . "----------------------------------" . "\n"  ;

        }
        header("Content-type: text/plain");
        header("Content-Disposition: attachment; filename=PythonTrace.txt");

        echo $fileContent;
    }
    else if($_REQUEST["download"] == "allResources")
    {
        $temp = DistributedResource::CreateAllResources();
        $fileContent = "{" . "\n";
        for($i = 0; $i < count($temp); $i++)
        {
            $fileContent .=  $temp[$i]["ResID"] . ' : ';
            $fileContent .=  $temp[$i]["ResInfo"] .  ',' . "\n"  ;
        }
        $fileContent = rtrim($fileContent);
        $fileContent = rtrim($fileContent,",");
        $fileContent .=   "\n"  ;
        $fileContent .= "}" ;
        header("Content-type: text/plain");
        header("Content-Disposition: attachment; filename=all_resources.json");

        echo $fileContent;
    }
}

if(isset($_REQUEST["task"]) && $_REQUEST["task"] == "PythonOutputDetail")
{
    $temp = ExternalCommandsLogs::SearchExternalCommandsLogs($_REQUEST["relatedID"],$_REQUEST["relatedPage"]);
    $res = $temp[0]["LogInfo"];
    echo $res;
    die();
}
?>
