<?php
/**
 * Created by PhpStorm.
 * User: habibih
 * Date: 4/16/2019
 * Time: 12:16 PM
 */

require_once '../top.php';
require_once '../class/Content.class.php';
require_once '../class/Language.class.php';
require_once '../class/User.class.php';
require_once '../class/ExternalCommandsLogs.class.php';
require_once '../class/ContentConstructionLogs.class.php';
require_once '../class/ContentEmbeddedItem.class.php';
require_once '../class/ContentConfig.class.php';
require_once '../class/ContentTranslationSegment.class.php';
require_once '../class/ContentWord.class.php';
require_once '../class/DistributedResource.class.php';
require_once '../class/DistributedResourcePage.class.php';
require_once '../SharedModules/DocxConversion.class.php';
require_once 'SegmentsAndWords.data.php';

//forHani Requirements
require_once '../class/Content_ContentPage.class.php';
require_once '../class/Content_PageSegment.class.php';


$task = isset($_REQUEST["task"]) ? $_REQUEST["task"] :  "";

switch ($task)
{
    case "TagRawText":
        TagRawText();

    case "CreateResources":
        CreateResources();

    case "CreatePages":
        CreatePages();

    case "forHani":
        forHani();

    case "DeleteContent":
        DeleteContent();

    case "PublishContent":
        PublishContent();

}

function TagRawText()
{
    //json response is created using this array
    $resultArray = array();
    $resultArray[0]["resultMsg"] = "notSetYet";

    $contentObj = FillItems($_REQUEST);

    if ($contentObj->ContentID == null) {
        $resultArray[0]["id"] = -1;
    }
    else{
        $resultArray[0]["id"] = $contentObj->ContentID;
    }


    //Check if user wants to use tagger but has not upload a file.
    if(!file_exists($_FILES['RawText']['tmp_name']) || !is_uploaded_file($_FILES['RawText']['tmp_name']))
    {
        $resultArray[0]["resultMsg"] = "fileUploadError";
        $result = CreateResponse($resultArray);
        echo $result;
        die();
    }

    //check if anything except txt or docx file is uploaded and return if so.
    $FileNameParts = explode('.', $_FILES['RawText']['name']);
    $FileExt = $FileNameParts[count($FileNameParts) - 1];
    $FileExt = strtolower($FileExt);
    if ($FileExt != "txt" && $FileExt != "docx" ) {
        $resultArray[0]["resultMsg"] = "RtFileTypeError";
        $result = CreateResponse($resultArray);
        echo $result;
        die();
    }

    //continue with file to create tagged file
    if ($contentObj->ContentID == null)
    {
        //create new data raw in database for new content
        $contentObj->insert();
        $contentObj->ContentID = $contentObj->lastID();
        $resultArray[0]["id"] = $contentObj->ContentID;
    }
    else
    {
        //edit the existing content raw in database
        $oldDirName = $contentObj->DirName;
        $newDirName = $contentObj->ContentID . "_" . str_replace(" ","_",$contentObj->ContentName);
        if(!empty($oldDirName) && $oldDirName != $newDirName)
        {
            rename(LaraContentDir . $oldDirName, LaraContentDir . $newDirName);
            $contentObj->DirName = $newDirName;
            CreateConstructionLog(CL_RenameRootDir , "from " . $oldDirName . " to " . $newDirName,
                $contentObj->ContentID, $contentObj->ContentStatus);
        }
        $contentObj->update();
    }

    //creating the folder structure for the saved content
    $dirName = $contentObj->ContentID . "_" . str_replace(" ","_",$contentObj->ContentName);
    $createDIRRes = CreateDIR($dirName, SubDirNames);
    $createTmpDIRRes = CreateTmpDIR($dirName, SubDirNamesContentTmp);

    //check failure or success in creating directories
    if (in_array($createDIRRes,array("CreateDIRFailed","CreateSubDIRFailed")))
    {
        CreateConstructionLog(CL_FailedMakeDir, $createDIRRes,
            $contentObj->ContentID, $contentObj->ContentStatus);
        $resultArray[0]["resultMsg"] = $createDIRRes;
        $result = CreateResponse($resultArray);
        echo $result;
        die();
    }
    else if (in_array($createDIRRes, array("DIRExists","DIRCreated")))
    {
        if($createDIRRes == "DIRCreated")
        {
            CreateConstructionLog(CL_SuccessfulMakeDir, $contentObj->DirName,
                $contentObj->ContentID, $contentObj->ContentStatus);
            $contentObj->DirName = $dirName;
            $setPart = "DirName = :dirName";
            $wherePart = "ContentID = :contentID";
            $params = array(":dirName" => $contentObj->DirName, ":contentID" => $contentObj->ContentID);
            Content::PartialUpdate($setPart, $wherePart, $params);
        }

        $corpusDir = LaraContentDir . $contentObj->DirName . "/" . SubDirNames["corpus"] . "/";
        $file = $_FILES['RawText'];
        $fileName = str_replace(" ","_",$_FILES['RawText']['name']);

        //upload the raw file in corpus directory
        if (UploadFile($fileName, $corpusDir, $file))
        {
            $contentObj->RawTextFileName = $fileName;
            $setPart = "RawTextFileName = :rawTextFileName";
            $wherePart = "ContentID = :contentID";
            $params = array(":rawTextFileName" => $contentObj->RawTextFileName,
                            ":contentID" => $contentObj->ContentID);
            Content::PartialUpdate($setPart, $wherePart, $params);

            CreateConstructionLog(CL_SuccessfulUploadRawText, $corpusDir . $fileName,
                $contentObj->ContentID, $contentObj->ContentStatus);

            //check for segmentation
            if ($FileExt == "txt")
            {
                $fileContent = file_get_contents($_FILES['RawText']['tmp_name']);
            }
            else if ($FileExt == "docx" )
            {
                 $docxObj = new DocxConversion(LaraContentDir . $contentObj->DirName . "/" . SubDirNames["corpus"] . "/" . $contentObj->RawTextFileName);
                 $fileContent = $docxObj->convertToText();
            }
            if( strpos($fileContent,"||") === false)
            {
                $oldName = LaraContentDir . $contentObj->DirName . "/" . SubDirNames["corpus"] . "/" . $contentObj->RawTextFileName;
                $newName = LaraContentDir . $contentObj->DirName . "/" . SubDirNames["corpus"] . "/notsegmented_" . $contentObj->RawTextFileName;
                if(rename($oldName,$newName))
                {
                    if(!SegmentizeIt($contentObj,'raw'))
                    {
                        $resultArray[0]["resultMsg"] = "FailToSegmentize";
                        $result = CreateResponse($resultArray);
                        echo $result;
                        die();
                    }
                }
            }

            CreateConfigFile($corpusDir, $contentObj, "", true);
            CreateConstructionLog(CL_CreateConfigFile_Limited, $corpusDir . "local_config.json",
                $contentObj->ContentID, $contentObj->ContentStatus);

            //using Manny's python code to create the tagged file
            $taggingResult = CreateTaggedFile($corpusDir, $contentObj->ContentID);
            if($taggingResult == true)
            {
                $contentObj->TreeTaggerStatus = "YES";
                $contentObj->ContentStatus = "treeTagger";
                $setPart = "TreeTaggerStatus = :treeTaggerStatus, ContentStatus = :contentStatus ";
                $wherePart = "ContentID = :contentID";
                $params = array(":treeTaggerStatus" => $contentObj->TreeTaggerStatus, ":contentStatus" => $contentObj->ContentStatus,
                    ":contentID" => $contentObj->ContentID);
                Content::PartialUpdate($setPart, $wherePart, $params);

                CreateConstructionLog(CL_SuccessfulTagging, $corpusDir . "Tagged_" . $fileName,
                    $contentObj->ContentID, $contentObj->ContentStatus);
                $resultArray[0]["resultMsg"] = "TaggedFileCreated";
            }
            else
            {
                CreateConstructionLog(CL_FailedTagging,  "",
                    $contentObj->ContentID, $contentObj->ContentStatus);
                $resultArray[0]["resultMsg"] = "TaggedFileFailed";
            }
        }
        else
        {
            CreateConstructionLog(CL_FailedMakeDir,  "",
                $contentObj->ContentID, $contentObj->ContentStatus);
            $resultArray[0]["resultMsg"] = "UploadFileFailed";
        }
        $result = CreateResponse($resultArray);
        echo $result;
        die();
    }
}

function CreateResources()
{
    //json response is created using this array
    $resultArray = array();
    $resultArray[0]["resultMsg"] = "notSetYet";


    $contentObj = FillItems($_REQUEST);
    if ($contentObj->ContentID == null) {
        $resultArray[0]["id"] = -1;
    }
    else{
        $resultArray[0]["id"] = $contentObj->ContentID;
    }

    //checking format for uploaded files
    if(file_exists($_FILES['TaggedText']['tmp_name']) && is_uploaded_file($_FILES['TaggedText']['tmp_name']))
    {
        $FileNameParts = explode('.', $_FILES['TaggedText']['name']);
        $FileExt = $FileNameParts[count($FileNameParts) - 1];
        $FileExt = strtolower($FileExt);
        if ($FileExt != "txt" && $FileExt != "docx") {
            $resultArray[0]["resultMsg"] = "TtFileTypeError";
            $result = CreateResponse($resultArray);
            echo $result;
            die();
        }
    }
    else
    {
        if(file_exists($_FILES['EmbeddedAudio']['tmp_name']) && is_uploaded_file($_FILES['EmbeddedAudio']['tmp_name']))
        {
            $FileNameParts = explode('.', $_FILES['EmbeddedAudio']['name']);
            $FileExt = $FileNameParts[count($FileNameParts) - 1];
            $FileExt = strtolower($FileExt);
            if ($FileExt != "zip") {
                $resultArray[0]["resultMsg"] = "eAudioTypeError";
                $result = CreateResponse($resultArray);
                echo $result;
                die();
            }
        }

        if(file_exists($_FILES['EmbeddedCss']['tmp_name']) && is_uploaded_file($_FILES['EmbeddedCss']['tmp_name']))
        {
            $FileNameParts = explode('.', $_FILES['EmbeddedCss']['name']);
            $FileExt = $FileNameParts[count($FileNameParts) - 1];
            $FileExt = strtolower($FileExt);
            if ($FileExt != "zip") {
                $resultArray[0]["resultMsg"] = "eCSSTypeError";
                $result = CreateResponse($resultArray);
                echo $result;
                die();
            }
        }

        if(file_exists($_FILES['EmbeddedImage']['tmp_name']) && is_uploaded_file($_FILES['EmbeddedImage']['tmp_name']))
        {
            $FileNameParts = explode('.', $_FILES['EmbeddedImage']['name']);
            $FileExt = $FileNameParts[count($FileNameParts) - 1];
            $FileExt = strtolower($FileExt);
            if ($FileExt != "zip") {
                $resultArray[0]["resultMsg"] = "eImageTypeError";
                $result = CreateResponse($resultArray);
                echo $result;
                die();
            }
        }

        if(file_exists($_FILES['EmbeddedScript']['tmp_name']) && is_uploaded_file($_FILES['EmbeddedScript']['tmp_name']))
        {
            $FileNameParts = explode('.', $_FILES['EmbeddedScript']['name']);
            $FileExt = $FileNameParts[count($FileNameParts) - 1];
            $FileExt = strtolower($FileExt);
            if ($FileExt != "zip") {
                $resultArray[0]["resultMsg"] = "eScriptTypeError";
                $result = CreateResponse($resultArray);
                echo $result;
                die();
            }
        }
    }
    if(isset($_REQUEST["ExternalResourceStatus"]) &&
        file_exists($_FILES['ExternalResource']['tmp_name']) &&
        is_uploaded_file($_FILES['ExternalResource']['tmp_name']))
    {
        $FileNameParts = explode('.', $_FILES['ExternalResource']['name']);
        $FileExt = $FileNameParts[count($FileNameParts) - 1];
        $FileExt = strtolower($FileExt);
        if ($FileExt != "zip") {
            $resultArray[0]["resultMsg"] = "extResTypeError";
            $result = CreateResponse($resultArray);
            echo $result;
            die();
        }
    }

    //add or update content to database
    if ($contentObj->ContentID == null)
    {
        //create new data raw in database for new content
        $contentObj->insert();
        $contentObj->ContentID = $contentObj->lastID();
        $resultArray[0]["id"] = $contentObj->ContentID;
    }
    else
    {
        //edit the existing content raw in database
        $oldDirName = $contentObj->DirName;
        $newDirName = $contentObj->ContentID . "_" . str_replace(" ","_",$contentObj->ContentName);
        if(!empty($oldDirName) && $oldDirName != $newDirName)
        {
            rename(LaraContentDir . $oldDirName, LaraContentDir . $newDirName);
            CreateConstructionLog(CL_RenameRootDir , "from " . $oldDirName . " to " . $newDirName,
                $contentObj->ContentID, $contentObj->ContentStatus);
            $contentObj->DirName = $newDirName;
        }
        $contentObj->update();
    }

    //creating the folder structure for the saved content
    $dirName = $contentObj->ContentID . "_" . str_replace(" ","_",$contentObj->ContentName);
    $createDIRRes = CreateDIR($dirName, SubDirNames);
    $createTmpDIRRes = CreateTmpDIR($dirName, SubDirNamesContentTmp);

    //check failure or success in creating directories
    if (in_array($createDIRRes,array("CreateDIRFailed","CreateSubDIRFailed")))
    {
        CreateConstructionLog(CL_FailedMakeDir, $createDIRRes,
            $contentObj->ContentID, $contentObj->ContentStatus);
        $resultArray[0]["resultMsg"] = $createDIRRes;
        $result = CreateResponse($resultArray);
        echo $result;
        die();
    }
    else if (in_array($createDIRRes, array("DIRExists","DIRCreated")))
    {
        if($createDIRRes == "DIRCreated")
        {
            $contentObj->DirName = $dirName;
            $setPart = "DirName = :dirName";
            $wherePart = "ContentID = :contentID";
            $params = array(":dirName" => $contentObj->DirName, ":contentID" => $contentObj->ContentID);
            Content::PartialUpdate($setPart, $wherePart, $params);

            CreateConstructionLog(CL_SuccessfulMakeDir, $contentObj->DirName,
                $contentObj->ContentID, $contentObj->ContentStatus);
        }

        $corpusDir = LaraContentDir . $contentObj->DirName . "/" . SubDirNames["corpus"] . "/";

        //if the user uploaded a tagged text, so it should be uploaded on the server and check for segmentation and embedded files
        //if not, check for embedded files
        if(file_exists($_FILES['TaggedText']['tmp_name']) && is_uploaded_file($_FILES['TaggedText']['tmp_name']))
        {
            $file = $_FILES['TaggedText'];
            $fileName = str_replace(" ","_",$_FILES['TaggedText']['name']);
            if (UploadFile($fileName, $corpusDir, $file))
            {
                $contentObj->TaggedTextFileName = $fileName;
                $setPart = "TaggedTextFileName = :taggedTextFileName";
                $wherePart = "ContentID = :contentID";
                $params = array(":taggedTextFileName" => $contentObj->TaggedTextFileName,
                    ":contentID" => $contentObj->ContentID);
                Content::PartialUpdate($setPart, $wherePart, $params);

                CreateConstructionLog(CL_SuccessfulUploadTaggedText, $corpusDir . $fileName,
                    $contentObj->ContentID, $contentObj->ContentStatus);

                //check for segmentation
                if ($FileExt == "txt")
                {
                    $fileContent = file_get_contents($_FILES['TaggedText']['tmp_name']);
                }
                else if ($FileExt == "docx" )
                {
                    $docxObj = new DocxConversion(LaraContentDir . $contentObj->DirName . "/" . SubDirNames["corpus"] . "/" . $contentObj->TaggedTextFileName);
                    $fileContent = $docxObj->convertToText();
                }
                if( strpos($fileContent,"||") === false)
                {
                    $oldName = LaraContentDir . $contentObj->DirName . "/" . SubDirNames["corpus"] . "/" . $contentObj->TaggedTextFileName;
                    $newName = LaraContentDir . $contentObj->DirName . "/" . SubDirNames["corpus"] . "/notsegmented_" . $contentObj->TaggedTextFileName;
                    if(rename($oldName,$newName))
                    {
                        if(!SegmentizeIt($contentObj, 'tagged'))
                        {
                            $resultArray[0]["resultMsg"] = "FailToSegmentize";
                            $result = CreateResponse($resultArray);
                            echo $result;
                            die();
                        }
                    }
                }

                //check for embedded files in tagged file
                $hasEmbeddedFiles = CheckForEmbeddedFiles($contentObj);
                if ($hasEmbeddedFiles == 'hasEmbedded') {
                    CreateConstructionLog(CL_HasEmbeddedFiles, $corpusDir . $fileName,
                        $contentObj->ContentID, $contentObj->ContentStatus);
                    $resultArray[0]["resultMsg"] = $hasEmbeddedFiles;
                    $result = CreateResponse($resultArray);
                    echo $result;
                    die();
                }
                else
                {
                    CreateConstructionLog(CL_NoEmbeddedFiles, $corpusDir . $fileName,
                        $contentObj->ContentID, $contentObj->ContentStatus);
                }
            }
            else {
                CreateConstructionLog(CL_FailedUploadTaggedText, $corpusDir . $fileName,
                    $contentObj->ContentID, $contentObj->ContentStatus);
                $resultArray[0]["resultMsg"] = "UploadFileFailed";
                $result = CreateResponse($resultArray);
                echo $result;
                die();
            }
        }
        else
        {
            $SrcDir = ContentTmpDirectory . $contentObj->DirName . "/" . SubDirNamesContentTmp["laraTmpDirectory"] . "/"  ;

            if($contentObj->HasEmbeddedImage == 'YES' &&
                file_exists($_FILES['EmbeddedImage']['tmp_name']) &&
                is_uploaded_file($_FILES['EmbeddedImage']['tmp_name']))
            {
                $file = $_FILES['EmbeddedImage'];
                $zipFileName = "images.zip";
                UploadFile($zipFileName,$SrcDir, $file);

                $DestDir = LaraContentDir . $contentObj->DirName . "/"  . SubDirNames["images"] . "/"  ;
                $path = $_FILES['EmbeddedImage']['tmp_name'];

                $zip = new ZipArchive;
                if ($zip->open($path) === true) {
                    for ($i = 0; $i < $zip->numFiles; $i++) {
                        $filename = $zip->getNameIndex($i);
                        $fileinfo = pathinfo($filename);
                        copy("zip://" . $path . "#" . $filename, $DestDir . $fileinfo['basename']);
                        if (ContentEmbeddedItem::itemExists($contentObj->ContentID,
                            EmbeddedItemsTypes["Image"], $fileinfo['basename'])) {
                            ContentEmbeddedItem::updateUploadStatus($contentObj->ContentID,
                                EmbeddedItemsTypes["Image"], $fileinfo['basename']);
                        }
                    }
                    $zip->close();
                    CreateConstructionLog(CL_SuccessfulUploadEmbImage, $DestDir,
                        $contentObj->ContentID, $contentObj->ContentStatus);
                }
                else
                {
                    CreateConstructionLog(CL_FailedUploadEmbImage, $SrcDir . $zipFileName,
                        $contentObj->ContentID, $contentObj->ContentStatus);
                    $resultArray[0]["resultMsg"] = "FailedToExtractZipFile";
                    $result = CreateResponse($resultArray);
                    echo $result;
                    die();
                }
            }
            if($contentObj->HasEmbeddedCSS == 'YES'&&
                file_exists($_FILES['EmbeddedCss']['tmp_name']) &&
                is_uploaded_file($_FILES['EmbeddedCss']['tmp_name']))
            {
                $file = $_FILES['EmbeddedCss'];
                $zipFileName = "css.zip";
                UploadFile($zipFileName,$SrcDir, $file);

                $DestDir = LaraContentDir . $contentObj->DirName . "/" . SubDirNames["corpus"] . "/"  ;
                $path = $_FILES['EmbeddedCss']['tmp_name'];

                $zip = new ZipArchive;
                if ($zip->open($path) === true) {
                    for ($i = 0; $i < $zip->numFiles; $i++) {
                        $filename = $zip->getNameIndex($i);
                        $fileinfo = pathinfo($filename);
                        copy("zip://" . $path . "#" . $filename, $DestDir . $fileinfo['basename']);
                        if (ContentEmbeddedItem::itemExists($contentObj->ContentID,
                            EmbeddedItemsTypes["CSS"], $fileinfo['basename'])) {
                            ContentEmbeddedItem::updateUploadStatus($contentObj->ContentID,
                                EmbeddedItemsTypes["CSS"], $fileinfo['basename']);
                        }
                    }
                    $zip->close();
                    CreateConstructionLog(CL_SuccessfulUploadEmbCSS, $DestDir,
                        $contentObj->ContentID, $contentObj->ContentStatus);
                }
                else{
                    CreateConstructionLog(CL_FailedUploadEmbCSS, $SrcDir . $zipFileName,
                        $contentObj->ContentID, $contentObj->ContentStatus);
                    $resultArray[0]["resultMsg"] = "FailedToOpenZipFile";
                    $result = CreateResponse($resultArray);
                    echo $result;
                    die();
                }
            }
            if($contentObj->HasEmbeddedScript == 'YES'&&
                file_exists($_FILES['EmbeddedScript']['tmp_name']) &&
                is_uploaded_file($_FILES['EmbeddedScript']['tmp_name']))
            {
                $file = $_FILES['EmbeddedScript'];
                $zipFileName = "script.zip";
                UploadFile($zipFileName,$SrcDir, $file);

                $DestDir = LaraContentDir . $contentObj->DirName . "/" . SubDirNames["corpus"] . "/"  ;
                $path = $_FILES['EmbeddedScript']['tmp_name'];

                $zip = new ZipArchive;
                if ($zip->open($path) === true) {
                    for ($i = 0; $i < $zip->numFiles; $i++) {
                        $filename = $zip->getNameIndex($i);
                        $fileinfo = pathinfo($filename);
                        copy("zip://" . $path . "#" . $filename, $DestDir . $fileinfo['basename']);
                        if (ContentEmbeddedItem::itemExists($contentObj->ContentID,
                            EmbeddedItemsTypes["Script"],  $fileinfo['basename'])) {
                            ContentEmbeddedItem::updateUploadStatus($contentObj->ContentID,
                                EmbeddedItemsTypes["Script"],  $fileinfo['basename']);
                        }
                    }
                    $zip->close();
                    CreateConstructionLog(CL_SuccessfulUploadEmbScript, $DestDir,
                        $contentObj->ContentID, $contentObj->ContentStatus);
                }
                else{
                    CreateConstructionLog(CL_FailedUploadEmbScript, $SrcDir . $zipFileName ,
                        $contentObj->ContentID, $contentObj->ContentStatus);
                    $resultArray[0]["resultMsg"] = "FailedToOpenZipFile";
                    $result = CreateResponse($resultArray);
                    echo $result;
                    die();
                }
            }
            if($contentObj->HasEmbeddedAudio == 'YES'&&
                file_exists($_FILES['EmbeddedAudio']['tmp_name']) &&
                is_uploaded_file($_FILES['EmbeddedAudio']['tmp_name']))
            {
                $AudioSrcDir = LaraContentDir . $contentObj->DirName . "/" . SubDirNames["audio"] . "/"  ;
                $file = $_FILES['EmbeddedAudio'];
                $fileName = "audio.zip";
                UploadFile($fileName,$AudioSrcDir, $file);

                $path = $_FILES['EmbeddedAudio']['tmp_name'];

                $zip = new ZipArchive;
                if ($zip->open($path) === true) {
                    for ($i = 0; $i < $zip->numFiles; $i++) {
                        $filename = $zip->getNameIndex($i);
                        $fileinfo = pathinfo($filename);
                        if (ContentEmbeddedItem::itemExists($contentObj->ContentID,
                            EmbeddedItemsTypes["Script"],  $fileinfo['basename'])) {
                            ContentEmbeddedItem::updateUploadStatus($contentObj->ContentID,
                                EmbeddedItemsTypes["Script"],  $fileinfo['basename']);
                        }
                    }
                    $zip->close();
                    CreateConstructionLog(CL_SuccessfulUploadEmbAudio, $DestDir,
                        $contentObj->ContentID, $contentObj->ContentStatus);
                }
                else{
                    CreateConstructionLog(CL_FailedUploadEmbAudio, $AudioSrcDir . $fileName,
                        $contentObj->ContentID, $contentObj->ContentStatus);
                    $resultArray[0]["resultMsg"] = "FailedToOpenZipFile";
                    $result = CreateResponse($resultArray);
                    echo $result;
                    die();
                }
            }
        }

        //Create and save Config file
        $tokenType = $_REQUEST["tokenType"];
        $accessToken = $_REQUEST["accessToken"];
        $headerInfo = $tokenType . " " . $accessToken ;
        CreateConfigFile($corpusDir, $contentObj, $headerInfo, false);
        CreateConstructionLog(CL_CreateConfigFile, $corpusDir . "local_config.json",
            $contentObj->ContentID, $contentObj->ContentStatus);

        //check if any external resource is uploaded and unzip and merge it if so
        if(isset($_REQUEST["ExternalResourceStatus"]) &&
            file_exists($_FILES['ExternalResource']['tmp_name']) &&
            is_uploaded_file($_FILES['ExternalResource']['tmp_name']))
        {
            $srcDir = ContentTmpDirectory . $contentObj->DirName . "/" . SubDirNamesContentTmp["laraTmpDirectory"] . "/"  ;

            $file = $_FILES['ExternalResource'];
            $fileInfo = pathinfo($_FILES['ExternalResource']["name"]);
            $zipFileName =  $fileInfo['basename'];
            UploadFile($zipFileName, $srcDir, $file);

            $rootDestDir = ExternalResourceDirectory . $contentObj->DirName . "/" ;
            $res = CreateResourceDIR($rootDestDir);
            if (in_array($res, array("DIRExists","DIRCreated"))) {
                $destDir = $rootDestDir . time() . "/";
                $resDest = CreateResourceDIR($destDir);
                if ($resDest != "CreateDIRFailed") {
                    $mergedDir = $rootDestDir . "merged/";
                    $resMerged = CreateResourceDIR($mergedDir);
                    if ($resMerged != "CreateDIRFailed") {
                        if (UnzipIt($srcDir . $zipFileName, $destDir, $contentObj->ContentID) == false) {
                            $resultArray[0]["resultMsg"] = "FailedToExtractExtResFile";
                            $result = CreateResponse($resultArray);
                            echo $result;
                            die();
                        }
                        else {
                            //uploaded folder for external resource
                            $dirs = array_filter(glob($destDir . '*'), 'is_dir');
                            $externalDir = $dirs[0];

                            //main language resource
                            $L2Name = Language::getLanguageName($contentObj->L2ID);
                            $mainDir = LaraContentDir . $L2Name;
                            if (!file_exists($mainDir) || !is_dir($mainDir))
                            {
                                rename($externalDir, $mainDir);
                            } else {
                                $mergeRes = MergeLanguageResources($externalDir, $mainDir, $mergedDir, $corpusDir, $contentObj->ContentID);
                                if($mergeRes == true)
                                {
                                    RemoveDir($mainDir);
                                    rename($mergedDir, $mainDir);
                                }
                                else
                                {
                                    $resultArray[0]["resultMsg"] = "MergeLanguageResourcesFailed";
                                    $result = CreateResponse($resultArray);
                                    echo $result;
                                    die();

                                }
                            }
                        }
                    }
                }
            }
        }

        //using Manny's python code to create the resources file
        $createResourcesResult = CreateResourceFiles($corpusDir, $contentObj->ContentID);

        if($createResourcesResult == true) {
            FromExcelToDatabase("words", $corpusDir, $contentObj->ContentID);
            FromExcelToDatabase("segments", $corpusDir, $contentObj->ContentID);

            if ($contentObj->WordLdtTaskID != '' || $contentObj->SegmentLdtTaskID != '') {
                if (!InstallAudio($contentObj->ContentID, $tokenType, $accessToken)) {
                    $resultArray[0]["resultMsg"] = "InstallPrvAudioFailed";
                    $result = CreateResponse($resultArray);
                    echo $result;
                    die();
                }
            }

            if ($contentObj->SegmentLdtTaskID != '')
            {
                if (!FromMetadataToDatabase($contentObj->ContentID, 'segment')) {
                    $resultArray[0]["resultMsg"] = "MetadataToDatabaseFailed";
                    $result = CreateResponse($resultArray);
                    echo $result;
                    die();
                }
            }


            $wordLDT = $contentObj->WordLdtTaskID;
            $segmentLDT = $contentObj->SegmentLdtTaskID;

            if (filesize($corpusDir . 'word_recording.txt') != 0){
                if ($contentObj->WordLdtTaskID != '') {
                    if (!DeleteLDTTask($tokenType, $accessToken, $contentObj->WordLdtTaskID)) {
                        $resultArray[0]["resultMsg"] = "DeletePrvWordFailed";
                        $result = CreateResponse($resultArray);
                        echo $result;
                        die();
                    }
                }
                $wordLDT = CreateLDTTask($tokenType, $accessToken, $corpusDir . 'word_recording.txt', $contentObj->ContentName, $contentObj->WordAudio);
                if ($wordLDT != "-1")
                    $contentObj->WordLdtTaskID = $wordLDT;
            }
            if($_SESSION["UserName"] == 'hani')
            {
                //if (filesize($corpusDir . 'segment_recording.txt') != 0) {
                if($contentObj->SegmentLdtTaskID != '')
                {
                    if(!DeleteLDTTask($tokenType, $accessToken, $contentObj->SegmentLdtTaskID))
                    {
                        $resultArray[0]["resultMsg"] = "DeletePrvSegFailed";
                        $result = CreateResponse($resultArray);
                        echo $result;
                        die();
                    }
                }

                $EditFileRes = EditRecordingFile($contentObj->ContentID, $corpusDir, 'segment');

                if($EditFileRes == "FailedToReadSegRecAll")
                {
                    $resultArray[0]["resultMsg"] = $EditFileRes;
                    $result = CreateResponse($resultArray);
                    echo $result;
                    die();
                }
                elseif ($EditFileRes ==  "NoPrvRecordingInfo")
                {
                    $segmentLDT = CreateLDTTask($tokenType, $accessToken, $corpusDir . 'segment_recording.txt', $contentObj->ContentName, $contentObj->SegmentAudio);
                }
                elseif ($EditFileRes == "EditedFileReady")
                {
                    $segmentLDT = CreateLDTTask($tokenType, $accessToken, $corpusDir . 'segment_recording_all_edit.txt', $contentObj->ContentName, $contentObj->SegmentAudio);
                }
                if($segmentLDT != "-1")
                    $contentObj->SegmentLdtTaskID = $segmentLDT;
                //}
            }
            else{
                if (filesize($corpusDir . 'segment_recording.txt') != 0) {
                    if($contentObj->SegmentLdtTaskID != '')
                    {
                        if(!DeleteLDTTask($tokenType, $accessToken, $contentObj->SegmentLdtTaskID))
                        {
                            $resultArray[0]["resultMsg"] = "DeletePrvSegFailed";
                            $result = CreateResponse($resultArray);
                            echo $result;
                            die();
                        }
                    }

                    $segmentLDT = CreateLDTTask($tokenType, $accessToken, $corpusDir . 'segment_recording.txt', $contentObj->ContentName, $contentObj->SegmentAudio);
                    if($segmentLDT != "-1")
                        $contentObj->SegmentLdtTaskID = $segmentLDT;
                }
            }

            if($wordLDT == "-1" || $segmentLDT == "-1")
            {
                $resultArray[0]["resultMsg"] = "CreateLDTTaskFailed";
            }
            else {
                $resultArray[0]["resultMsg"] = "FirstCompileStepDone";

                $contentObj->ContentStatus = "resources";
                $setPart = " ContentStatus = :contentStatus";
                $params = array(":contentStatus" => $contentObj->ContentStatus);

                if (!empty($contentObj->WordLdtTaskID)) {
                    $setPart .= ", WordLdtTaskID = :wordLDT";
                    $params[":wordLDT"] = $contentObj->WordLdtTaskID;
                }
                if (!empty($contentObj->SegmentLdtTaskID))
                {
                    $setPart .= ", SegmentLdtTaskID = :segmentLDT ";
                    $params[":segmentLDT"] = $contentObj->SegmentLdtTaskID;
                }

                $wherePart = "ContentID = :contentID";
                $params[":contentID"] = $contentObj->ContentID;

                $params = array(":wordLDT" => $contentObj->WordLdtTaskID, ":segmentLDT" =>$contentObj->SegmentLdtTaskID ,
                    ":contentStatus" => $contentObj->ContentStatus, ":contentID" => $contentObj->ContentID);
                Content::PartialUpdate($setPart, $wherePart, $params);
            }
        }
        else
        {
            $resultArray[0]["resultMsg"] = "FirstCompileStepFailed";
        }
    }
        $result = CreateResponse($resultArray);
        echo $result;
        die();

}

function CreatePages()
{
    $resultArray = array();
    $resultArray[0]["resultMsg"] = "notSetYet";

    $where = " ContentID = :contentID";
    $whereParam = array(":contentID" => $_GET["contentID"]);
    $info = Content::SearchContent($where, $whereParam);
    $contentObj = FillItems($info[0]);

    $resultArray[0]["id"] = $contentObj->ContentID;

    $tokenType = $_REQUEST["tokenType"];
    $accessToken = $_REQUEST["accessToken"];
    $headerInfo = $tokenType . " " . $accessToken ;

    $dirName = $contentObj->ContentID . "_" . str_replace(" ","_",$contentObj->ContentName);
    $audioDir = LaraContentDir . $dirName . "/" . SubDirNames["audio"] . "/";
    $corpusDir = LaraContentDir . $dirName . "/" . SubDirNames["corpus"] . "/";
    $configFile = $corpusDir . "local_config.json";

    if(!empty($contentObj->WordLdtTaskID))
        $resultWord = DownloadFromLDT($contentObj, $audioDir, $headerInfo, "word");
    else
        $resultWord = true;

    if(!empty($contentObj->SegmentLdtTaskID))
        $resultSeg =  DownloadFromLDT($contentObj, $audioDir, $headerInfo, "segment");
    else
        $resultSeg = true;

    if (!$resultWord || !$resultSeg) {
        $resultArray[0]["resultMsg"] = "DownloadFromLdtFailed";
    }
    else
    {
        if(InstallLdtZipfile($corpusDir, $audioDir, $configFile,
            $contentObj->ContentID, $contentObj->WordLdtTaskID, $contentObj->SegmentLdtTaskID)) {
            if($contentObj->HasEmbeddedAudio == "YES")
            {
                if(!InstallNonLdtAudio($audioDir, $configFile, $contentObj->ContentID))
                {
                    $resultArray[0]["resultMsg"] = "InstallNolLDTAudioFailed";
                    $result = CreateResponse($resultArray);
                    echo $result;
                    die();
                }
            }
            if (CreatePageFiles($corpusDir, $contentObj->ContentID)) {
                $compileDir = ContentTmpDirectory . $dirName . "/" . SubDirNamesContentTmp["compiled"] . "/";
                $dirName = str_replace(" ", "_", $contentObj->ContentName) . "vocabpages";
                if (CopyToWeb($compileDir, $dirName, $contentObj->ContentID))
                {
                    $resultArray[0]["resultMsg"] = "PageCreationDone";
                    $contentObj->ContentStatus ="pages";
                    $contentObj->WebAddress = WebRoot . $dirName . "/_hyperlinked_text_.html";
                    $setPart = "WebAddress = :webAddress, ContentStatus = :contentStatus ";
                    $wherePart = "ContentID = :contentID";
                    $params = array(":webAddress" => $contentObj->WebAddress, ":contentStatus" => $contentObj->ContentStatus, ":contentID" => $contentObj->ContentID);
                    Content::PartialUpdate($setPart, $wherePart, $params);
                }
                else{
                    $resultArray[0]["resultMsg"] = "CopyingPagesFailed";
                }

            } else {
                $resultArray[0]["resultMsg"] = "CreatePagesFailed";
            }
        }
        else
        {
            $resultArray[0]["resultMsg"] = "InstallZipfileFailed";
        }
    }

    $result = CreateResponse($resultArray);
    echo $result;
    die();
}

function InstallAudio($contentID, $tokenType, $accessToken)
{
    $where = " ContentID = :contentID";
    $whereParam = array(":contentID" => $contentID);
    $info = Content::SearchContent($where, $whereParam);
    $contentObj = FillItems($info[0]);
    $headerInfo = $tokenType . " " . $accessToken ;

    $dirName = $contentObj->ContentID . "_" . str_replace(" ","_",$contentObj->ContentName);
    $audioDir = LaraContentDir . $dirName . "/" . SubDirNames["audio"] . "/";
    $corpusDir = LaraContentDir . $dirName . "/" . SubDirNames["corpus"] . "/";
    $configFile = $corpusDir . "local_config.json";

    if(!empty($contentObj->WordLdtTaskID))
        $resultWord = DownloadFromLDT($contentObj, $audioDir, $headerInfo, "word");
    else
        $resultWord = true;
    if(!empty($contentObj->SegmentLdtTaskID))
        $resultSeg =  DownloadFromLDT($contentObj, $audioDir, $headerInfo, "segment");
    else
        $resultSeg = true;

    if (!$resultWord || !$resultSeg) {
        return false;
    }
    else
    {
        if(InstallLdtZipfile($corpusDir, $audioDir, $configFile,
            $contentObj->ContentID, $contentObj->WordLdtTaskID, $contentObj->SegmentLdtTaskID)) {
            return true;
        }
        else
        {
            return false;
        }
    }
}

function FillItems($src)
{
    $contentObj = new Content();
    PdoDataAccess::FillObjectByArray($contentObj, $src);
    return $contentObj;
}

function FillConfigItems($src)
{
    $configObj = new ContentConfig();
    PdoDataAccess::FillObjectByArray($configObj, $src);
    return $configObj;
}

function MakeEmptyContent()
{
    $contentObj = new Content();
    $contentObj->CreatorID = $_SESSION['UserID'];
    $contentObj->L1ID = -1;
    $contentObj->L2ID = -1;
    $contentObj->WordAudio = -1;
    $contentObj->SegmentAudio = -1;
    $contentObj->ContentStatus = 'raw';
    $contentObj->TreeTaggerStatus = 'NO';
    $contentObj->AudioMouseOver = 'NO';
    $contentObj->WordTranslationMouseOver = 'NO';
    $contentObj->SegmentTranslationMouseOver = 'NO';
    $contentObj->L1rtl = 'NO';
    $contentObj->TableOfContents = 'NO';
    $contentObj->KeepComments = 'NO';
    $contentObj->CommentsByDefault = 'NO';
    $contentObj->LinguisticsArticleComments = 'NO';
    $contentObj->ColouredWords = 'YES';
    $contentObj->AudioWordsInColour = 'NO';
    $contentObj->MaxExamplesPerWordPage = '10';
    $contentObj->ExtraPageInfo = 'NO';
    $contentObj->Font = 'sans-serif';
    $contentObj->FrequencyListsInMainText = 'NO';
    $contentObj->HasEmbeddedAudio = 'NO';
    $contentObj->HasEmbeddedCSS = 'NO';
    $contentObj->HasEmbeddedImage = 'NO';
    $contentObj->HasEmbeddedScript = 'NO';
    $contentObj->HasExternalResources = 'NO';
    $contentObj->LangRepType = 'Public';

    return $contentObj;
}

function CreateDIR($dirName, $subDirNames)
{
    $dirAddress = LaraContentDir . $dirName;
    //check if the directory for the content already exists
    if (!file_exists( $dirAddress ) || !is_dir($dirAddress))
    {
        //if not, try to create the root directory
        if(! mkdir($dirAddress, 0777, true))
        {
            return "CreateDIRFailed";
        }
        else
        {
            //and then, create 3 sub directories
            for($i = 0; $i < count($subDirNames); $i++)
            {

                $subDir = $dirAddress . "/" . array_keys($subDirNames)[$i];
                if( !mkdir($subDir, 0777, true))
                {
                    return "CreateSubDIRFailed";
                }
            }
            return "DIRCreated";
        }
    }
    else
    {
        return "DIRExists";
    }
}

function CreateTmpDIR($dirName, $subDirNames)
{
    $dirAddress = ContentTmpDirectory . $dirName;
    //check if the directory for the content already exists
    if (!file_exists( $dirAddress ) || !is_dir($dirAddress))
    {
        //if not, try to create the root directory
        if(! mkdir($dirAddress, 0777, true))
        {
            return "CreateDIRFailed";
        }
        else
        {
            //and then, create 3 sub directories
            for($i = 0; $i < count($subDirNames); $i++)
            {

                $subDir = $dirAddress . "/" . array_keys($subDirNames)[$i];
                if( !mkdir($subDir, 0777, true))
                {
                    return "CreateSubDIRFailed";
                }
            }
            return "DIRCreated";
        }
    }
    else
    {
        return "DIRExists";
    }
}

function CreateResourceDIR($dirAddress)
{
    //check if the directory for the content already exists
    if (!file_exists( $dirAddress ) || !is_dir($dirAddress))
    {
        //if not, try to create the root directory
        if(! mkdir($dirAddress, 0777, true))
        {
            return "CreateDIRFailed";
        }
        else
        {
            return "DIRCreated";
        }
    }
    else
    {
        return "DIRExists";
    }
}

function UploadFile($fileName, $fileDir, $file)
{
    $fp = fopen($fileDir . $fileName, "w");
    fwrite($fp, fread(fopen($file ['tmp_name'], 'r'), $file['size']));
    fclose($fp);
    return true;
}

function CreateTaggedFile($fileDir, $contentID)
{
    $bashFile = $fileDir . "TreeTaggerCommand.txt";
    $fp = fopen( $bashFile, "w");
    $command = LaraEnv . " " . TreeTaggerEnv . " " . PythonCmnd . " " . PythonDir . "lara_run_for_portal.py treetagger " . $fileDir . "local_config.json 2>&1";
    fwrite($fp, $command);
    fclose($fp);

    $LogID = ExternalCmndLog(EL_TypePythonCmnd, $command, $contentID, 'content');
    $output = shell_exec('bash < '  . $bashFile );
    $LogID = ExternalCmndLog(EL_TypePythonRes, $output, $contentID, 'content');

    if(strpos($output, "Error") === false)
        return true;
    else
        return false;
}

function UnzipIt($zipFile, $destination, $contentID)
{
    $bashFile = $destination . "unzipIt.txt";
    $fp = fopen( $bashFile, "w");
    $command = LaraEnv . " " . PythonCmnd . " " . PythonDir . "lara_run_for_portal.py unzip " . $zipFile .
        " " .  $destination . " 2>&1";
    fwrite($fp, $command);
    fclose($fp);

    $LogID = ExternalCmndLog(EL_TypePythonCmnd, $command, $contentID, 'content');
    $output = shell_exec('bash < '  . $bashFile );
    $LogID = ExternalCmndLog(EL_TypePythonRes, $output, $contentID, 'content');

    if(strpos($output, "Unzipped") !== false)
        return true;
    else
        return false;
}

function CreateConfigFile($corpusDir, $contentObj, $headerInfo, $limited = false)
{
    $L1Name = Language::getLanguageName($contentObj->L1ID);
    $L2Name = Language::getLanguageName($contentObj->L2ID);
    $UserName = User::GetUserName($contentObj->CreatorID);
    $TranslationFileName = $L2Name . "_" . $L1Name . ".csv";

    $taggedFileName = "Tagged_" . $contentObj->RawTextFileName;
    $configObj = new ContentConfig();
    $configObj->ContentID = $contentObj->ContentID;

    $local_config_data = '{';
    $local_config_data .= '"id" : "' . str_replace(" ", "_", $contentObj->ContentName) . '",';
    $configObj->id = str_replace(" ", "_", $contentObj->ContentName);
    $local_config_data .= '"language" : "' . $L2Name . '",';
    $configObj->language = $L2Name;

    if(!$limited)
    {
        $configObj->isLimited = "no";
        $wordUnserName = User::GetLdtUserName($headerInfo, $contentObj->WordAudio);
        $segmentUserName = User::GetLdtUserName($headerInfo, $contentObj->SegmentAudio);

        if ($contentObj->L1rtl == 'YES') {
            $local_config_data .= '"text_direction" : "rtl",';
            $configObj->text_direction = "rtl";
        }
        $local_config_data .= '"max_examples_per_word_page":' . $contentObj->MaxExamplesPerWordPage . ',';
        $configObj->max_examples_per_word_page = $contentObj->MaxExamplesPerWordPage;
        $local_config_data .= '"corpus" : "' . $corpusDir . $contentObj->TaggedTextFileName . '",';
        $configObj->corpus =  $corpusDir . $contentObj->TaggedTextFileName;

        $local_config_data .= '"word_audio_directory" : "' . LaraContentDir . $L2Name . '/' . SubDirNames["audio"] . '/' . $wordUnserName . '",';
        $configObj->word_audio_directory = LaraContentDir . $L2Name . '/' . SubDirNames["audio"] . '/' . $wordUnserName;
        if($contentObj->LangRepType == "Public")
        {
            $local_config_data .= '"translation_spreadsheet" : "' . LaraContentDir . $L2Name . '/' . SubDirNames["translations"] . '/' . $TranslationFileName . '",';
            $configObj->translation_spreadsheet = LaraContentDir . $L2Name . '/' . SubDirNames["translations"] . '/' . $TranslationFileName;
        }
        else
        {
            $local_config_data .= '"translation_spreadsheet" : "' . LaraContentDir . $L2Name . '/' . SubDirNames["translations"] . '/' . $UserName . '_' . $TranslationFileName . '",';
            $configObj->translation_spreadsheet = LaraContentDir . $L2Name . '/' . SubDirNames["translations"] . '/' . $UserName . '_' . $TranslationFileName;
        }

        $local_config_data .= '"segment_audio_directory" : "' . LaraContentDir . $contentObj->DirName . '/' . SubDirNames["audio"] . '/' . $segmentUserName . '",';
        $configObj->segment_audio_directory = LaraContentDir . $contentObj->DirName . '/' . SubDirNames["audio"] . '/' . $segmentUserName;
        $local_config_data .= '"segment_translation_spreadsheet" : "' . LaraContentDir . $contentObj->DirName . '/' . SubDirNames["translations"] . '/' . $TranslationFileName . '",';
        $configObj->segment_translation_spreadsheet = LaraContentDir . $contentObj->DirName . '/' . SubDirNames["translations"] . '/' . $TranslationFileName ;

        $local_config_data .= '"translation_mouseover" : "' . strtolower($contentObj->WordTranslationMouseOver) . '",';
        $configObj->translation_mouseover = strtolower($contentObj->WordTranslationMouseOver);
        $local_config_data .= '"audio_mouseover" : "' . strtolower($contentObj->AudioMouseOver) . '",';
        $configObj->audio_mouseover = strtolower($contentObj->AudioMouseOver);
        $local_config_data .= '"segment_translation_mouseover" : "' . strtolower($contentObj->SegmentTranslationMouseOver) . '",';
        $configObj->segment_translation_mouseover = strtolower($contentObj->SegmentTranslationMouseOver);

        //NewAdded
        $local_config_data .= '"allow_table_of_contents" : "' . strtolower($contentObj->TableOfContents) . '",';
        $configObj->allow_table_of_contents = strtolower($contentObj->TableOfContents);
        $local_config_data .= '"keep_comments" : "' . strtolower($contentObj->KeepComments) . '",';
        $configObj->keep_comments = strtolower($contentObj->KeepComments);
        $local_config_data .= '"comments_by_default" : "' . strtolower($contentObj->CommentsByDefault) . '",';
        $configObj->comments_by_default = strtolower($contentObj->CommentsByDefault);
        $local_config_data .= '"linguistics_article_comments" : "' . strtolower($contentObj->LinguisticsArticleComments) . '",';
        $configObj->linguistics_article_comments = strtolower($contentObj->LinguisticsArticleComments);
        $local_config_data .= '"coloured_words" : "' . strtolower($contentObj->ColouredWords) . '",';
        $configObj->coloured_words = strtolower($contentObj->ColouredWords);
        if ($contentObj->AudioWordsInColour == 'YES') {
            $local_config_data .= '"audio_words_in_colour" : "red",';
            $configObj->audio_words_in_colour = "red";
        }
        if ($contentObj->ExtraPageInfo == 'YES') {
            $local_config_data .= '"extra_page_info" : "' . $L2Name . '",';
            $configObj->extra_page_info = $L2Name;
        }
        $local_config_data .= '"font" : "' . strtolower($contentObj->Font) . '",';
        $configObj->font = strtolower($contentObj->Font);
        $local_config_data .= '"frequency_lists_in_main_text_page" : "' . strtolower($contentObj->FrequencyListsInMainText) . '",';
        $configObj->frequency_lists_in_main_text_page = strtolower($contentObj->FrequencyListsInMainText);
    }
    else
    {
        $configObj->isLimited = "yes";
        $local_config_data .= '"corpus" : "' . $corpusDir . $contentObj->RawTextFileName . '",';
        $configObj->corpus =  $corpusDir . $contentObj->TaggedTextFileName;
    }

    $local_config_data .= '"untagged_corpus" : "' . $corpusDir . $contentObj->RawTextFileName . '",';
    $configObj->untagged_corpus = $corpusDir . $contentObj->RawTextFileName;
    $local_config_data .= '"tagged_corpus" : "' . $corpusDir . $taggedFileName. '",';
    $configObj->tagged_corpus = $corpusDir . $taggedFileName;
    $local_config_data .= '"compiled_directory" : "' . ContentTmpDirectory . $contentObj->DirName . '/' . SubDirNamesContentTmp["compiled"] . '",';
    $configObj->compiled_directory = ContentTmpDirectory . $contentObj->DirName . '/' . SubDirNamesContentTmp["compiled"];
    $local_config_data .= '"lara_tmp_directory" : "' . ContentTmpDirectory . $contentObj->DirName . '/' . SubDirNamesContentTmp["laraTmpDirectory"] . '",';
    $configObj->lara_tmp_directory = ContentTmpDirectory . $contentObj->DirName . '/' . SubDirNamesContentTmp["laraTmpDirectory"];
    $local_config_data .= '"working_tmp_directory" : "' . WorkingTmpDirectory . '",';
    $configObj->working_tmp_directory = WorkingTmpDirectory ;
    $local_config_data .= '"image_directory" : "' . LaraContentDir . $contentObj->DirName . '/' . SubDirNames["images"] . '"';
    $configObj->image_directory = LaraContentDir . $contentObj->DirName . '/' . SubDirNames["images"];
    $local_config_data .= '}';

    $local_config_file = $corpusDir . 'local_config.json';
    $handle = fopen($local_config_file, 'w') or die('Cann   ot open file:  ' . $local_config_file);
    fwrite($handle, $local_config_data);
    fclose($handle);

    $deleteWhere = "ContentID = :contentID";
    $deleteWhereParam = array(":contentID" => $contentObj->ContentID);
    ContentConfig::delete($deleteWhere, $deleteWhereParam);

    $configObj->insert();
    $LogID = ExternalCmndLog(EL_TypeConfigFile, $local_config_data, $contentObj->ContentID, 'content');
    return true;
}

function SegmentizeIt($contentObj, $stage)
{
    $corpusDir = LaraContentDir . $contentObj->DirName . "/" . SubDirNames["corpus"] . "/";

    if($stage == 'raw')
    {
        $nonSegfileName = "notsegmented_" . $contentObj->RawTextFileName;
        $fileName = $contentObj->RawTextFileName;
    }
    else if($stage == 'tagged')
    {
        $nonSegfileName = "notsegmented_" . $contentObj->TaggedTextFileName;
        $fileName = $contentObj->TaggedTextFileName;
    }

    $bashFile = $corpusDir . "SegmentFile.txt";
    $fp = fopen( $bashFile, "w");
    $command = LaraEnv . " " . TreeTaggerEnv . " " . PythonCmnd . " " . PythonDir . "lara_run_for_portal.py segment_file " .
        $corpusDir . $nonSegfileName . " " . $corpusDir . $fileName . " 2>&1";
    fwrite($fp, $command);

    $LogID = ExternalCmndLog(EL_TypePythonCmnd, $command, $contentObj->ContentID, 'content');
    $output = shell_exec('bash < '  . $bashFile);
    $LogID = ExternalCmndLog(EL_TypePythonRes, $output, $contentObj->ContentID, 'content');

    if(strpos($output, "Error") === false)
        return true;
    else
        return false;

}

function CheckForEmbeddedFiles($contentObj)
{
    $corpusDir = LaraContentDir . $contentObj->DirName . "/" . SubDirNames["corpus"] . "/";
    $fileName = $contentObj->TaggedTextFileName;
    $bashFile = $corpusDir . "CheckForEmbeddedFiles.txt";
    $fp = fopen( $bashFile, "w");
    $command = LaraEnv . " " . PythonCmnd . " " . PythonDir . "lara_run_for_portal.py extract_css_img_and_audio_files_basic " .
        $corpusDir . $fileName . " " . $corpusDir . "embeddedFiles.json 2>&1";
    fwrite($fp, $command);

    $LogID = ExternalCmndLog(EL_TypePythonCmnd, $command, $contentObj->ContentID, 'content');
    $output = shell_exec('bash < '  . $bashFile);
    $LogID = ExternalCmndLog(EL_TypePythonRes, $output, $contentObj->ContentID, 'content');

    $outputString = file_get_contents($corpusDir."embeddedFiles.json");
    $jsonOutput = json_decode($outputString, true); // decode the JSON into an associative array

    ContentEmbeddedItem::MakeItemsStateOld($contentObj->ContentID);

    if(count($jsonOutput['audio_files']) == 0 &&
        count($jsonOutput['css_files']) == 0 &&
        count($jsonOutput['img_files']) == 0 &&
        count($jsonOutput['script_files']) == 0)
    {
        $contentObj->HasEmbeddedAudio = 'NO';
        $contentObj->HasEmbeddedCSS = 'NO';
        $contentObj->HasEmbeddedImage = 'NO';
        $contentObj->HasEmbeddedScript = 'NO';
        $setPart = "HasEmbeddedAudio = :noEmbedded, HasEmbeddedCSS = :noEmbedded,
                    HasEmbeddedImage = :noEmbedded, HasEmbeddedScript = noEmbedded";
        $wherePart = "ContentID = :contentID";
        $params = array(":noEmbedded" => 'NO', ":contentID" => $contentObj->ContentID);
        Content::PartialUpdate($setPart, $wherePart, $params);

        $retVal = "noEmbeddedFile";
    }
    else {
        $setPart = "";
        if (count($jsonOutput['audio_files']) != 0)
        {
            $contentObj->HasEmbeddedAudio = 'YES';
            $setPart .= " HasEmbeddedAudio = :hasEmbedded,";
            for($i = 0; $i < count($jsonOutput['audio_files']); $i++)
            {
                if(ContentEmbeddedItem::itemExists($contentObj->ContentID, EmbeddedItemsTypes["Audio"], $jsonOutput['audio_files'][$i]))
                {
                    ContentEmbeddedItem::updateItemState($contentObj->ContentID, EmbeddedItemsTypes["Audio"], $jsonOutput['audio_files'][$i]);
                }
                else
                {
                    CreateEmbeddedItem(EmbeddedItemsTypes["Audio"], $jsonOutput['audio_files'][$i], $contentObj->ContentID);
                }
            }
        }
        if(count($jsonOutput['css_files']) != 0)
        {
            $contentObj->HasEmbeddedCSS = 'YES';
            $setPart .= " HasEmbeddedCSS = :hasEmbedded,";
            for($i = 0; $i < count($jsonOutput['css_files']); $i++)
            {
                if(ContentEmbeddedItem::itemExists($contentObj->ContentID, EmbeddedItemsTypes["CSS"], $jsonOutput['css_files'][$i]))
                {
                    ContentEmbeddedItem::updateItemState($contentObj->ContentID, EmbeddedItemsTypes["CSS"], $jsonOutput['css_files'][$i]);
                }
                else
                {
                    CreateEmbeddedItem(EmbeddedItemsTypes["CSS"], $jsonOutput['css_files'][$i], $contentObj->ContentID);
                }
            }
        }
        if(count($jsonOutput['img_files']) != 0)
        {
            $contentObj->HasEmbeddedImage = 'YES';
            $setPart .= " HasEmbeddedImage = :hasEmbedded,";
            for($i = 0; $i < count($jsonOutput['img_files']); $i++)
            {
                if(ContentEmbeddedItem::itemExists($contentObj->ContentID, EmbeddedItemsTypes["Image"], $jsonOutput['img_files'][$i]))
                {
                    ContentEmbeddedItem::updateItemState($contentObj->ContentID, EmbeddedItemsTypes["Image"], $jsonOutput['img_files'][$i]);
                }
                else
                {
                    CreateEmbeddedItem(EmbeddedItemsTypes["Image"], $jsonOutput['img_files'][$i], $contentObj->ContentID);
                }
            }
        }
        if(count($jsonOutput['script_files']))
        {
            $contentObj->HasEmbeddedScript = 'YES';
            $setPart .= " HasEmbeddedScript = :hasEmbedded,";
            for($i = 0; $i < count($jsonOutput['script_files']); $i++)
            {
                if(ContentEmbeddedItem::itemExists($contentObj->ContentID, EmbeddedItemsTypes["Script"], $jsonOutput['script_files'][$i]))
                {
                    ContentEmbeddedItem::updateItemState($contentObj->ContentID, EmbeddedItemsTypes["Script"], $jsonOutput['script_files'][$i]);
                }
                else
                {
                    CreateEmbeddedItem(EmbeddedItemsTypes["Script"], $jsonOutput['script_files'][$i], $contentObj->ContentID);
                }
            }
        }
        $setPart = rtrim($setPart,',');
        $wherePart = "ContentID = :contentID";
        $params = array(":hasEmbedded" => 'YES', ":contentID" => $contentObj->ContentID);
        Content::PartialUpdate($setPart, $wherePart, $params);

        $retVal = "hasEmbedded";
    }

    $where = "ContentID = :contentID and ItemState = 'OLD'";
    $whereParam = array(":contentID" => $contentObj->ContentID);
    ContentEmbeddedItem::delete($where, $whereParam);

    if(ContentEmbeddedItem::allUploaded($contentObj->ContentID))
    {
        $retVal = "noEmbeddedFile";
    }

    return $retVal;
}

function MergeLanguageResources($externalDir, $mainDir, $mergedDir, $corpusDir, $contentID)
{
    $bashFile = $externalDir . "MergeResources.txt";
    $fp = fopen( $bashFile, "w");

    $command = LaraEnv . " " . PythonCmnd . " " . PythonDir . "lara_run_for_portal.py merge_language_resources " .
        $mainDir . " " . $externalDir . " " . $mergedDir . " " . $corpusDir . "local_config.json  2>&1";
    fwrite($fp, $command);

    $LogID = ExternalCmndLog(EL_TypePythonCmnd, $command, $contentID, 'content');
    $output = shell_exec('bash < '  . $bashFile );
    $LogID = ExternalCmndLog(EL_TypePythonRes, $output, $contentID, 'content');

    if(strpos($output, "Error") === false)
        return true;
    else
        return false;
}

function CreateResourceFiles($corpusDir, $contentID)
{
    $bashFile = $corpusDir . "FirstPhaseCommand.txt";
    $fp = fopen( $bashFile, "w");

    $command = LaraEnv . " " . PythonCmnd . " " . PythonDir . "lara_run_for_portal.py resources_basic " . $corpusDir . "local_config.json " .
        $corpusDir . "word_recording.txt " .
        $corpusDir . "word_recording_all.txt " .
        $corpusDir . "segment_recording.txt " .
        $corpusDir . "segment_recording_all.txt " .
        $corpusDir . "word_translation.csv " .
        $corpusDir . "segment_translation.csv 2>&1";
    fwrite($fp, $command);

    $LogID = ExternalCmndLog(EL_TypePythonCmnd, $command, $contentID, 'content');
    $output = shell_exec('bash < '  . $bashFile );
    $LogID = ExternalCmndLog(EL_TypePythonRes, $output, $contentID, 'content');

    if(strpos($output, "Error") === false)
        return true;
    else
        return false;
}

function DeleteLDTTask($tokenType, $accessToken, $TaskID)
{
    $url = 'https://regulus.unige.ch/litedevtools/server/api/lara/deleteRecordingTask/' . $TaskID;
    $header = [
        "Authorization: " . $tokenType . " " . $accessToken
    ];

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "DELETE");
    curl_setopt($ch, CURLOPT_HEADER, 0);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/4.0 (compatible;)");
    curl_setopt($ch, CURLOPT_HTTPHEADER,$header);
    curl_setopt($ch, CURLOPT_FRESH_CONNECT, 1);
    curl_setopt($ch, CURLOPT_FORBID_REUSE, 1);
    curl_setopt($ch, CURLOPT_TIMEOUT, 100);

    $result = curl_exec($ch);
    curl_close($ch);
    if ($result === FALSE) {
        //echo "Error sending" . $fname .  " " . curl_error($ch);
        return false;
    }else{
        return true;
    }
}

function EditRecordingFile($contentID, $corpusDir, $type)
{
    $where = " ContentID = :contentID";
    $whereParam = array(":contentID" => $contentID);

    //ConfigInfo
    $configObjInfo = ContentConfig::SearchContentConfig($where, $whereParam);
    if ($configObjInfo != false) {
        require_once 'Content.data.php';
        $configObj = FillConfigItems($configObjInfo);

        $mdObj = new ContentRecordingMetadata();
        $mdObj->ContentID = $contentID;
        $mdObj->RecordingType = $type;

        if ($type == 'segment') {
            $mdObj->MetadataFileDirectory = $configObj->segment_audio_directory . "/metadata_help.txt";
        }
        else if ($type == "word")
        {
            $mdObj->MetadataFileDirectory = $configObj->word_audio_directory . "/metadata_help.txt";
        }

        if($mdObj->IsRegistered() == false)
        {
            return "NoPrvRecordingInfo";
        }

        $where = " RecordingMetadataID = :rmID";
        $whereParam = array(":rmID" => $mdObj->RecordingMetadataID);

        $recordingInfo = ContentRecordingSegment::SearchRecordingSegments($where, $whereParam);
        $recordingInfoCount = count($recordingInfo);
        $editedFileContent = "";
        if ($file = fopen($corpusDir . "segment_recording_all.txt", "r"))
        {
            while(!feof($file)) {
                $line = fgets($file);
                $i = 0;
                while ($i <= $recordingInfoCount)
                {
                    if($recordingInfo[$i]["SegmentText"] ==  trim($line,"AudioOutput help any_speaker MISSING_FILE # (no trace info)\n"))
                    {
                        $line = str_replace("MISSING_FILE",
                            "help/" . str_replace("mp3", "wav", $recordingInfo[$i]["AudioFileName"]),
                            $line);
                        $i = $recordingInfoCount;
                    }
                    $i++;
                }
                $editedFileContent .= $line;
            }
            fclose($file);
        }
        else
        {
            return "FailedToReadSegRecAll";
        }

        file_put_contents($corpusDir . "segment_recording_all_edit.txt", $editedFileContent);
        return "EditedFileReady";
    }
}

function CreateLDTTask($tokenType, $accessToken, $fileDir, $contentName, $ldtUserID)
{
    $url = 'https://regulus.unige.ch/litedevtools/server/api/lara/postRecordingTask';
    $fname = $fileDir;
    $cfile = new CURLFile(realpath($fname));

    $post = array (
        'file' => $cfile,
        'taskName' => $contentName
    );

    if($ldtUserID == -1)
    {
        $post["anonymousTask"] = 'true';
    }
    else
    {
        $post["anonymousTask"] = 'false';
        $post["assignedUserId"] = $ldtUserID;
    }

    $header = [
        "Content-Type: multipart/form-data",
        "Authorization: " . $tokenType . " " . $accessToken
    ];

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_HEADER, 0);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/4.0 (compatible;)");
    curl_setopt($ch, CURLOPT_HTTPHEADER,$header);
    curl_setopt($ch, CURLOPT_FRESH_CONNECT, 1);
    curl_setopt($ch, CURLOPT_FORBID_REUSE, 1);
    curl_setopt($ch, CURLOPT_TIMEOUT, 100);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $post);

    $result = curl_exec($ch);
    if ($result === FALSE) {
        //echo "Error sending" . $fname .  " " . curl_error($ch);
        curl_close($ch);
        return "-1";
    }else{
        $RecTaskRes = json_decode($result, true);
        $ldtTaskID = $RecTaskRes["id"];
        curl_close($ch);
        return $ldtTaskID;
    }
}

function DownloadFromLDT($contentObj, $audioDir, $headerInfo, $type)
{
    if($type == "word")
    {
        $url = 'https://regulus.unige.ch/litedevtools/server/api/lara/downloadRecordedFiles/' . $contentObj->WordLdtTaskID;
        $FileToSave = $audioDir . 'ldtWords.zip';
    }
    elseif ($type == "segment")
    {
        $url = 'https://regulus.unige.ch/litedevtools/server/api/lara/downloadRecordedFiles/' . $contentObj->SegmentLdtTaskID;
        $FileToSave = $audioDir . 'ldtSegments.zip';
    }

    $header = [
        "Authorization: " . $headerInfo
    ];

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_HEADER, 0);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/4.0 (compatible;)");
    curl_setopt($ch, CURLOPT_HTTPHEADER,$header);
    curl_setopt($ch, CURLOPT_FRESH_CONNECT, 1);
    curl_setopt($ch, CURLOPT_FORBID_REUSE, 1);
    curl_setopt($ch, CURLOPT_TIMEOUT, 100);

    $result = curl_exec ($ch);
    if ($result === FALSE) {
        curl_close($ch);
        return false;
    }
    else{
        file_put_contents($FileToSave, $result);
        curl_close($ch);
        return true;
    }
}

function InstallLdtZipfile($corpusDir, $audioDir, $configFile, $contentID, $wordLdtTaskID, $segLdtTaskID)
{
    $bashFile = $audioDir . "InstallWords.txt";
    $wordRecFile = $corpusDir . "word_recording.txt";
    $segRecFile = $corpusDir . "segment_recording.txt";

    $fp = fopen( $bashFile, "w");

    $command = LaraEnv . " " . PythonCmnd . " " . PythonDir . "lara_run_for_portal.py install_ldt_zipfile " .
        $audioDir . "ldtWords.zip " . $wordRecFile . " words " .  $configFile . " 2>&1" ;
    fwrite($fp, $command);

    if(file_exists( $audioDir . "ldtWords.zip") && !empty($wordLdtTaskID) )
    {
        $LogID = ExternalCmndLog(EL_TypePythonCmnd, $command, $contentID, 'content');
        $output = shell_exec('bash < '  . $bashFile );
        $LogID = ExternalCmndLog(EL_TypePythonRes, $output, $contentID, 'content');
    }
    else
    {
        $output = true;
    }

    if(strpos($output, "Error") === false)
    {
        $bashFile = $audioDir . "InstallSegments.txt";
        $fp = fopen( $bashFile, "w");

        $command = LaraEnv . " " . PythonCmnd . " " . PythonDir . "lara_run_for_portal.py install_ldt_zipfile " .
            $audioDir . "ldtSegments.zip " . $segRecFile . " segments " . $configFile . " 2>&1" ;
        fwrite($fp, $command);


        if(file_exists( $audioDir . "ldtSegments.zip") && !empty($segLdtTaskID))
        {
            $LogID = ExternalCmndLog(EL_TypePythonCmnd, $command, $contentID, 'content');
            $output = shell_exec('bash < '  . $bashFile );
            $LogID = ExternalCmndLog(EL_TypePythonRes, $output, $contentID, 'content');
        }
        else
        {
            $output = true;
        }

        if(strpos($output, "Error") === false )
        {
            return true;
        }
        else
        {
            return false;
        }
    }
    else
    {
        return false;
    }
}

function InstallNonLdtAudio($audioDir, $configFile, $contentID)
{
    $bashFile = $audioDir . "InstallNonLDTAudio.txt";
    $fp = fopen( $bashFile, "w");

    $command = LaraEnv . " " . PythonCmnd . " " . PythonDir . "lara_run_for_portal.py install_non_ldt_audio_zipfile  " .
        $audioDir . "audio.zip " .  $configFile . " 2>&1" ;
    fwrite($fp, $command);

    $LogID = ExternalCmndLog(EL_TypePythonCmnd, $command, $contentID, 'content');
    $output = shell_exec('bash < '  . $bashFile );
    $LogID = ExternalCmndLog(EL_TypePythonRes, $output, $contentID, 'content');

    if(strpos($output, "Error") === false)
    {
        return true;
    }
    else
    {
        return false;
    }
}

function CreatePageFiles($corpusDir, $contentID)
{
    $bashFile = $corpusDir . "CreatePagesCommand.txt";
    $fp = fopen( $bashFile, "w");

    $command = LaraEnv . " " . PythonCmnd . " " . PythonDir . "lara_run_for_portal.py word_pages  " . $corpusDir . "local_config.json  2>&1";
    fwrite($fp, $command);

    $LogID = ExternalCmndLog(EL_TypePythonCmnd, $command, $contentID, 'content');
    $output = shell_exec('bash < '  . $bashFile );
    $LogID = ExternalCmndLog(EL_TypePythonRes, $output, $contentID, 'content');

    if(strpos($output, "Error") === false)
        return true;
    else
        return false;
}

function CopyToWeb($CompileDir, $dirName, $contentID)
{
    $bashFile = $CompileDir . "CopyCommand.txt";
    $fp = fopen($bashFile, "w");

    if( is_dir(CallectorDir . $dirName) === false )
    {
        mkdir(CallectorDir . $dirName);
    }
    $command = "scp -r " . $CompileDir . $dirName . "/* " . CallectorDir . $dirName . "/  2>&1";
    fwrite($fp, $command);
    fclose($fp);

    $LogID = ExternalCmndLog(EL_TypePythonCmnd, $command, $contentID, 'content');
    $output = shell_exec('bash < '  . $bashFile );
    $LogID = ExternalCmndLog(EL_TypePythonRes, $output, $contentID, 'content');

    if ($output == '')
        return true;
    else
        return false;
}

function CreateConstructionLog($LogType, $LogDesc, $ContentID, $ContentStatus)
{
    $ExternalLog = new ContentConstructionLogs();
    $ExternalLog->LogType = $LogType;
    $ExternalLog->LogDesc = $LogDesc;
    $ExternalLog->LogDateTime = (new DateTime('now'))->format('Y-m-d H:i:s');
    $ExternalLog->UserID = $_SESSION['UserID'];
    $ExternalLog->ContentID = $ContentID;
    $ExternalLog->ContentStatus = $ContentStatus;

    $ExternalLog->insert();

    return true;
}

function CreateEmbeddedItem($ItemType, $ItemName, $ContentID)
{
    $EmbeddedItem = new ContentEmbeddedItem();

    $EmbeddedItem->ItemType = $ItemType;
    $EmbeddedItem->ItemName = $ItemName;
    $EmbeddedItem->IsUploaded = 'NO';
    $EmbeddedItem->ContentID = $ContentID;
    $EmbeddedItem->ItemState = "NEW";

    $EmbeddedItem->insert();

    return true;
}

function forHani(){

    $resultArray = array();
    $resultArray[0]["resultMsg"] = "done";
    $resultArray[0]["id"] = -1;

    if(file_exists($_FILES['TaggedText']['tmp_name']) && is_uploaded_file($_FILES['TaggedText']['tmp_name']))
    {
        $pageObj = new Content_ResourcePage();
        $segObj = new Content_PageSegment();
        //$pageObj->ContentResourceID = $_REQUEST["ContentID"];
        $pageObj->ContentResourceID = 7;

        $where = "ContentResourceID = :cri";
        $whereParam = array(":cri" => $pageObj->ContentResourceID);
        Content_ResourcePage::delete($where, $whereParam);

        $fileContent = file_get_contents($_FILES['TaggedText']['tmp_name']);
        $pages = explode("<page>",$fileContent);
        for($i = 0; $i < count($pages); $i++)
        {
            echo "PAGE START";
            $pageObj->PageOrder = $i+1;
            $pageObj->insert();
            $segObj->PageID = $pageObj->PageID = Content_ResourcePage::lastID();
            $pageContent = $pages[$i];
            $segments = explode("||",$pageContent);
            for($j = 0; $j < count($segments); $j++)
            {
                $segObj->SegmentOrder = $j+1;
                $segObj->insert();
                $segmentContent = nl2br($segments[$j]);
                echo $segmentContent . "*****\n";
            }

        }
    }
    $result = CreateResponse($resultArray);
    echo $result;
    die();
}

function DeleteContent()
{
    $resultArray = array();
    $resultArray[0]["resultMsg"] = "notSetYet";

    $where = " ContentID = :contentID";
    $whereParam = array(":contentID" => $_GET["contentID"]);
    $info = Content::SearchContent($where, $whereParam);
    $contentObj = FillItems($info[0]);

    $resultArray[0]["id"] = $contentObj->ContentID;

    $where = " contentID = :contentID";
    $whereParam = array(":contentID" => $contentObj->ContentID);

    ContentConfig::delete($where, $whereParam);
    ContentEmbeddedItem::delete($where, $whereParam);
    ContentTranslationSegment::delete($where, $whereParam);
    ContentWord::delete($where, $whereParam);

    $setPart = "IsDeleted = 'YES'";
    Content::PartialUpdate($setPart, $where, $whereParam);
    $dirName = LaraContentDir . $contentObj->DirName;
    RemoveDir($dirName);
    if(!empty($contentObj->WebAddress))
    {
        $vocabDirName = CallectorDir . str_replace(" ", "_", $contentObj->ContentName) . "vocabpages";
        RemoveDir($vocabDirName);
    }

    $resultArray[0]["resultMsg"] = "SuccessfulDelete";
    $result = CreateResponse($resultArray);
    echo $result;
    die();
}

function PublishContent()
{
    $resultArray = array();
    $resultArray[0]["resultMsg"] = "notSetYet";

    $where = " ContentID = :contentID";
    $whereParam = array(":contentID" => $_GET["contentID"]);
    $info = Content::SearchContent($where, $whereParam);
    $contentObj = FillItems($info[0]);

    $resultArray[0]["id"] = $contentObj->ContentID;

    $L2Name = Language::getLanguageName($contentObj->L2ID);

    if(AddMetaData($contentObj, $L2Name))
    {
        $CompileDir = ContentTmpDirectory . $contentObj->DirName . "/" . SubDirNamesContentTmp["compiled"] . "/";
        $dirName = $contentObj->DirName;
        $bashFile = $CompileDir . "CopyResourceCommand.txt";
        $fp = fopen($bashFile, "w");

        //Copy the content package from LaraData to LaraResource
        if (is_dir(DistributedDir . $dirName) === false) {
            mkdir(DistributedDir . $dirName);
        }
        $command = "scp -r " . LaraContentDir . $dirName . "/* " . DistributedDir . $dirName . "/  2>&1";
        fwrite($fp, $command);
        fclose($fp);
        $output = shell_exec('bash < ' . $bashFile);

        if ($output != '')
        {
            $resultArray[0]["resultMsg"] = "FailedToCopyResource";
            $result = CreateResponse($resultArray);
            echo $result;
            die();
        }

        //Copy the language package from LaraData to LaraResource
        $bashFile = $CompileDir . "CopyLangResourceCommand.txt";
        $fp = fopen($bashFile, "w");

        if (is_dir(DistributedDir . $L2Name ) === false)
            mkdir(DistributedDir . $L2Name );


        $command = "scp -r " . LaraContentDir . $L2Name . "/* " .DistributedDir . $L2Name . "/  2>&1";
        fwrite($fp, $command);
        fclose($fp);
        $output = shell_exec('bash < ' . $bashFile);

        $langCopyResFile = $CompileDir . "CopyLangResourceRes.txt";
        $fp = fopen($langCopyResFile, "w");
        fwrite($fp, $output);
        fclose($fp);

        if ($output != '')
        {
            $resultArray[0]["resultMsg"] = "FailedToCopyLangResource";
            $result = CreateResponse($resultArray);
            echo $result;
            die();
        }

        $intendedWebAddress = DistributedWebRoot . $L2Name ;
        $LangResRegCheck = DistributedResource::isLanguageResourceRegistered($intendedWebAddress);
        if( $LangResRegCheck == "-1")
        {
            $lRscObj = new DistributedResource();
            $lRscObj->ResourceName =  $L2Name;
            $lRscObj->WebAddress = DistributedWebRoot . $L2Name ;
            $lRscObj->ResourceType = "Language";
            $lRscObj->UserID = $contentObj->CreatorID;
            $lRscObj->L2ID = $contentObj->L2ID;
            $lRscObj->insert();
            $lRscObj->ResourceID = DistributedResource::lastID();
            $parentID = $lRscObj->ResourceID;
        }
        else
        {
            $parentID = $LangResRegCheck;
        }

        //PageNamesShouldBeExtractedAgain
        if(!empty($contentObj->DistributedResourceID))
        {
            $where = "ResourceID = :rID";
            $whereParam = array(":rID" => $contentObj->DistributedResourceID);
            DistributedResourcePage::delete($where, $whereParam);
        }

        $rscObj = new DistributedResource();
        $rscObj->ResourceName = str_replace(" ","_",$contentObj->ContentName);
        $rscObj->WebAddress = DistributedWebRoot . $dirName ;
        $rscObj->ResourceType = "Content";
        $rscObj->UserID =  $contentObj->CreatorID;
        $rscObj->L2ID =  $contentObj->L2ID;
        $rscObj->ParentID = $parentID;

        if($_REQUEST["publishType"] == "Insert")
        {
            $rscObj->insert();
            $rscObj->ResourceID = DistributedResource::lastID();
        }
        else if($_REQUEST["publishType"] == "Update")
        {
            $rscObj->ResourceID = $contentObj->DistributedResourceID;
            $rscObj->update();
        }
        else if($_REQUEST["publishType"] == "Reinsert")
        {
            $where = "ResourceID = :rID";
            $whereParam = array(":rID" => $contentObj->DistributedResourceID);
            DistributedResource::delete($where, $whereParam);
            $rscObj->insert();
            $rscObj->ResourceID = DistributedResource::lastID();
        }

        $setPart = "DistributedResourceID = :drID";
        $wherePart = "ContentID = :contentID";
        $params = array(":drID" => $rscObj->ResourceID, ":contentID" => $contentObj->ContentID);
        Content::PartialUpdate($setPart, $wherePart, $params);

        if (!ExtractResourcePageNames($CompileDir, $rscObj, $contentObj->ContentID))
        {
            $resultArray[0]["resultMsg"] = "FailedToExtractPageNames";
            $result = CreateResponse($resultArray);
            echo $result;
            die();
        }
        $resultArray[0]["resultMsg"] = "SuccessfulPublish";
    }
    else
    {
        $resultArray[0]["resultMsg"] = "FailedPublish";
    }

    $result = CreateResponse($resultArray);
    echo $result;
    die();
}

function AddMetaData($contentObj, $L2Name)
{
    $corpusDir = LaraContentDir . $contentObj->DirName . "/" . SubDirNames["corpus"] . "/";
    $ResourceDir = LaraContentDir . $contentObj->DirName ;
    $bashFile = $corpusDir . "AddMetadataCmnd.txt";
    $fp = fopen( $bashFile, "w");
    $command = LaraEnv . " " . PythonCmnd . " " . PythonDir . "lara_run_for_portal.py add_metadata " .
        $ResourceDir  . " corpus 2>&1";
    fwrite($fp, $command);

    $LogID = ExternalCmndLog(EL_TypePythonCmnd, $command, $contentObj->ContentID, 'content');
    $output = shell_exec('bash < '  . $bashFile);
    $LogID = ExternalCmndLog(EL_TypePythonRes, $output, $contentObj->ContentID, 'content');

    if(strpos($output, "Error") !== false)
    {
        return false;
    }
    else
    {
        $corpusDir = LaraContentDir . $contentObj->DirName . "/" . SubDirNames["corpus"] . "/";
        $ResourceDir = LaraContentDir . $L2Name ;
        $bashFile = $corpusDir . "AddMetadataCmndForLangRep.txt";
        $fp = fopen( $bashFile, "w");
        $command = LaraEnv . " " . PythonCmnd . " " . PythonDir . "lara_run_for_portal.py add_metadata " .
            $ResourceDir  . " language 2>&1";
        fwrite($fp, $command);

        $LogID = ExternalCmndLog(EL_TypePythonCmnd, $command, $contentObj->ContentID, 'content');
        $output = shell_exec('bash < '  . $bashFile);
        $LogID = ExternalCmndLog(EL_TypePythonRes, $output, $contentObj->ContentID, 'content');

        if(strpos($output, "Error") !== false)
            return false;
        else
            return true;
    }
}

function ExtractResourcePageNames($compileDir, $rscObj, $contentID)
{
    //1- create resource file
    $resourceFile = $compileDir . "resource.json";
    $fp = fopen($resourceFile, "w");
    $fileContent = '{"' . $rscObj->ResourceID . '_' . $rscObj->ResourceName . '" : ["' .
                $rscObj->WebAddress . '",""]}';
    fwrite($fp, $fileContent);
    fclose($fp);

    //2- create config file
    $configFile = $compileDir . "config.json";
    $fp = fopen($configFile, "w");
    $fileContent = '{"id": "abc", "reading_history": [], 
        "working_tmp_directory" : "' . WorkingTmpDirectory . '", "resource_file" : "' . $resourceFile .'"}';
    fwrite($fp, $fileContent);
    fclose($fp);

    //3- create and run bash command file
    $pageNamesFile = $compileDir . "pageNames.json";
    $bashFile = $compileDir . "PageNamesForResource.txt";
    $fp = fopen( $bashFile, "w");

    $command = LaraEnv . " " . PythonCmnd . " " . PythonDir . "lara_run_for_portal.py " .
                "get_page_names_for_resource  " . $rscObj->ResourceID . '_' . $rscObj->ResourceName .
                " " .  $configFile."  " . $pageNamesFile . " 2>&1";
    fwrite($fp, $command);

    $LogID = ExternalCmndLog(EL_TypePythonCmnd, $command, $contentID, 'content');
    $output = shell_exec('bash < '  . $bashFile );
    $LogID = ExternalCmndLog(EL_TypePythonRes, $output, $contentID, 'content');

    if($output == false || strpos($output, "Error") !== false )
        return false;

    //4- read json file
    $outputString = file_get_contents($pageNamesFile);
    $PagesNamesArray = json_decode($outputString, true); // decode the JSON into an associative array

    //6- save in DistributedResourcePages table
    for($i = 0; $i < count($PagesNamesArray); $i++)
    {
        $resourcePage = new DistributedResourcePage();
        $resourcePage->ResourceID = $rscObj->ResourceID;
        $resourcePage->PageNumber = $PagesNamesArray[$i]['page_number'];
        $resourcePage->PageName = $PagesNamesArray[$i]['base_file'];
        $resourcePage->insert();
    }

    return true;
}

?>