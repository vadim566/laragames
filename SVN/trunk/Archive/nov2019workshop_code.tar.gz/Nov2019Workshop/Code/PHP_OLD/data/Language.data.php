<?php
/**
 * Created by PhpStorm.
 * User: habibih
 * Date: 5/5/2019
 * Time: 01:42 AM
 */

require_once '../class/Language.class.php';

$task = isset($_REQUEST["task"]) ? $_REQUEST["task"] :  "";

switch ($task)
{
    case "hasTreeTagger":
        hasTreeTagger();
}

function hasTreeTagger()
{
    $hasTreeTagger = Language::hasTreeTagger($_POST["LanguageID"]);
    echo $hasTreeTagger;
    die();

}


function FillItems($src)
{
    $langObj = new  Language();
    PdoDataAccess::FillObjectByArray($langObj, $_REQUEST);
    return $langObj;
}
?>