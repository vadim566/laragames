<?php
/**
 * Created by PhpStorm.
 * User: habibih
 * Date: 8/6/2019
 * Time: 11:44 PM
 */

require_once '../top.php';
require_once '../class/DistributedResource.class.php';
require_once '../class/DistributedResourcePage.class.php';
require_once '../class/ExternalCommandsLogs.class.php';

$task = isset($_REQUEST["task"]) ? $_REQUEST["task"] :  "";

switch ($task)
{
    case "AddDistributedResource":
        AddDistributedResource();

    case "DeleteResource":
        DeleteResource();
}

function FillDistributedResourceItems($src)
{
    $rscObj = new DistributedResource();
    PdoDataAccess::FillObjectByArray($rscObj, $src);
    return $rscObj;
}

function MakeEmptyResource()
{
    $obj = new DistributedResource();
    $obj->UserID = $_SESSION['UserID'];
    $obj->ResourceName = "";
    $obj->WebAddress = "";
    $obj->ResourceType = "Content";
    $obj->ParentID = null;
    $obj->IsDeleted = "NO";
    return $obj;
}

function AddDistributedResource()
{
    //json response is created using this array
    $resultArray = array();
    $resultArray[0]["resultMsg"] = "notSetYet";
    $resultArray[0]["id"] = -1;

    $D_R_Obj = FillDistributedResourceItems($_REQUEST);

    //add or update content to database
    if ($D_R_Obj->ResourceID == null)
    {
        //create new data raw in database for new content
        $D_R_Obj->insert();
        $D_R_Obj->ResourceID = $D_R_Obj->lastID();
        $resultArray[0]["id"] = $D_R_Obj->ResourceID;
    }
    else
    {
        $resultArray[0]["id"] = $D_R_Obj->ResourceID;
        $D_R_Obj->update();
    }

    if($D_R_Obj->ResourceType == "Content")
    {
        if (!ExternalResourcePageNames($D_R_Obj))
        {
            $resultArray[0]["resultMsg"] = "FailedToExtractPageNames";
            $result = CreateResponse($resultArray);
            echo $result;
            die();
        }
    }
    $resultArray[0]["resultMsg"] = "ResourceAdded";


    $result = CreateResponse($resultArray);
    echo $result;
    die();

}

function ExternalResourcePageNames($rscObj)
{
    if (is_dir(WorkingTmpDirectory . $rscObj->ResourceID . '_' . $rscObj->ResourceName) === false) {
        mkdir(WorkingTmpDirectory . $rscObj->ResourceID . '_' . $rscObj->ResourceName);
    }
    $compileDir = WorkingTmpDirectory . $rscObj->ResourceID . '_' . $rscObj->ResourceName . "/";
    //1- create resource file
    $resourceFile = $compileDir . "resource.json";
    $fp = fopen($resourceFile, "w");
    $fileContent = '{"' . $rscObj->ResourceID . '_' . $rscObj->ResourceName . '" : ["' .
        $rscObj->WebAddress . '",""]}';
    fwrite($fp, $fileContent);
    fclose($fp);

    //2- create config file
    $configFile = $compileDir . "config.json";
    $fp = fopen($configFile, "w");
    $fileContent = '{"id": "abc", "reading_history": [], 
        "working_tmp_directory" : "' . WorkingTmpDirectory . '", "resource_file" : "' . $resourceFile .'"}';
    fwrite($fp, $fileContent);
    fclose($fp);

    //3- create and run bash command file
    $pageNamesFile = $compileDir . "pageNames.json";
    $bashFile = $compileDir . "PageNamesForResource.txt";
    $fp = fopen( $bashFile, "w");

    $command = LaraEnv . " " . PythonCmnd . " " . PythonDir . "lara_run_for_portal.py " .
        "get_page_names_for_resource  " . $rscObj->ResourceID . '_' . $rscObj->ResourceName .
        " " .  $configFile."  " . $pageNamesFile . " 2>&1";
    fwrite($fp, $command);

    ExternalCmndLog(EL_TypePythonCmnd, $command, $rscObj->ResourceID, 'resource');
    $output = shell_exec('bash < '  . $bashFile );
    ExternalCmndLog(EL_TypePythonRes, $output, $rscObj->ResourceID, 'resource');


    if($output == false)
        return false;

    //4- read json file
    $outputString = file_get_contents($pageNamesFile);
    $PagesNamesArray = json_decode($outputString, true); // decode the JSON into an associative array

    //6- save in DistributedResourcePages table
    for($i = 0; $i < count($PagesNamesArray); $i++)
    {
        $resourcePage = new DistributedResourcePage();
        $resourcePage->ResourceID = $rscObj->ResourceID;
        $resourcePage->PageNumber = $PagesNamesArray[$i]['page_number'];
        $resourcePage->PageName = $PagesNamesArray[$i]['base_file'];
        $resourcePage->insert();
    }

    return true;
}

function DeleteResource()
{
    $resultArray = array();
    $resultArray[0]["resultMsg"] = "notSetYet";

    $where = " ResourceID = :resourceID";
    $whereParam = array(":resourceID" => $_GET["resourceID"]);
    $info = DistributedResource::SearchResource($where, $whereParam);
    $resourceObj = FillDistributedResourceItems($info[0]);

    $resultArray[0]["id"] = $resourceObj->ResourceID;

    DistributedResourcePage::delete($where, $whereParam);

    $setPart = "IsDeleted = 'YES'";
    DistributedResource::PartialUpdate($setPart, $where, $whereParam);

    $resultArray[0]["resultMsg"] = "SuccessfulDelete";
    $result = CreateResponse($resultArray);
    echo $result;
    die();
}






