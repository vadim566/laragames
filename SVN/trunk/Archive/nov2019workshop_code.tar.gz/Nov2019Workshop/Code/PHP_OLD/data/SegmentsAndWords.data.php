<?php
/**
 * Created by PhpStorm.
 * User: habibih
 * Date: 6/6/2019
 * Time: 05:45 PM
 */


require_once '../top.php';
require_once '../class/Content.class.php';
require_once '../class/ContentWord.class.php';
require_once '../class/ContentTranslationSegment.class.php';
require_once '../class/ContentRecordingMetadata.class.php';
require_once '../class/ContentRecordingSegment.class.php';
require_once '../class/Language.class.php';
require_once '../class/ContentConfig.class.php';
require_once ROOT . 'SharedModules/PHPExcel/Classes/PHPExcel.php';

$task = isset($_REQUEST["task"]) ? $_REQUEST["task"] :  "";

switch ($task)
{
    case "saveData":
        saveData();

    case "UploadWordTrnslt":
        UploadSubcontentTranslation("word");

    case "UploadSgmntTrnslt":
        UploadSubcontentTranslation("segment");
}

function saveData()
{
    $resultArray = array();
    $resultArray[0]["resultMsg"] = "notSetYet";
    $resultArray[0]["id"] = $_REQUEST["ContentID"];
    $resultArray[0]["type"] = $_REQUEST["ValueType"];

    $where = "ContentID = :contentID";
    $whereParam = array(":contentID" => $_REQUEST["ContentID"]);
    $contentResult = Content::SearchContent($where, $whereParam);
    $dirName = LaraContentDir . $contentResult[0]["DirName"] ;
    $L1Name =  Language::getLanguageName($contentResult[0]["L1ID"]);
    $L2Name =  Language::getLanguageName($contentResult[0]["L2ID"]);
    $outputFileName = $L2Name . "_" . $L1Name . ".csv";
    if ($_REQUEST["ValueType"] == "word")
    {
        $idIndex = "ContentWordID";
        $l2Index = "WordInL2";
        $obj = new ContentWord();
        $srcFile =  $dirName . "/" . SubDirNames["corpus"] . "/" . 'word_translation.csv';
        $destFolder = LaraContentDir . $L2Name . "/" . SubDirNames["translations"] . "/";
        $destFile = $destFolder . $outputFileName;

    } elseif ($_REQUEST["ValueType"] == "segment")
    {
        $idIndex = "ContentSegmentID";
        $l2Index = "SegmentInL2";
        $obj = new ContentTranslationSegment();
        $srcFile = $dirName . "/" . SubDirNames["corpus"] . "/" . 'segment_translation.csv';
        $destFolder = $dirName . "/" . SubDirNames["translations"] . "/";
        $destFile = $destFolder . $outputFileName;
    }

    $obj->ContentID = $_REQUEST["ContentID"];

    $array_keys = array_keys($_REQUEST);
    foreach ($array_keys as $value)
    {
        if (strpos($value, 'L2Inpit_') === 0)
        {
            $IndexParts = explode('_', $value);
            $obj->{$idIndex} = $IndexParts[1];
            $obj->{$l2Index} = $_REQUEST[$value];
            $obj->update();
        }
    }

    if(FromDatabaseToExcel($obj->ContentID, $dirName,  $_REQUEST["ValueType"]))
    {
        //if(isset($_REQUEST["IsFinished"]) && $_REQUEST["IsFinished"] == "YES")
        if(isset($_REQUEST["SendMode"]) && $_REQUEST["SendMode"] == "SaveAndCopy")
        {
            if (!file_exists($destFolder) && !is_dir($destFolder))
            {
                if(! mkdir($destFolder, 0777, true))
                {
                    return "CreateDIRFailed";
                }
            }

            if(!copy($srcFile,$destFile))
            {
                $resultArray[0]["resultMsg"] = "FinalCopyFailed";
            }
            else
            {
                $resultArray[0]["resultMsg"] = "DataIsSavedAndCopiedForItems";
            }
        }
        else
        {
            $resultArray[0]["resultMsg"] = "DataIsSavedForItems";
        }
    }
    else
    {
        $resultArray[0]["resultMsg"] = "DataIsNOTSavedForItems";
    }

    $result = CreateResponse($resultArray);
    echo $result;
    die();
}

function FromExcelToDatabase($excelFile, $corpusDir, $contentID)
{
    $deleteWhere = "ContentID = :contentID";
    $deleteWhereParam = array(":contentID" => $contentID);

    if($excelFile == 'words')
    {
        $inputFileName = $corpusDir . 'word_translation.csv';
        $obj = new ContentWord();
    }
    elseif ($excelFile == "segments")
    {
        $inputFileName = $corpusDir . 'segment_translation.csv';
        $obj = new ContentTranslationSegment();
    }

    $obj->delete($deleteWhere, $deleteWhereParam);
    $obj->ContentID = $contentID;

    $inputFileType = 'CSV';
    $objReader = PHPExcel_IOFactory::createReader($inputFileType)->setDelimiter("\t");;
    $objPHPExcel = $objReader->load($inputFileName);
    $worksheet = $objPHPExcel->getActiveSheet();
    $maxRow = $worksheet->getHighestRow();

    for($row=2; $row<=$maxRow ; $row++)
    {
        if($excelFile == 'words') {
            $obj->WordInL1 = $worksheet->getCellByColumnAndRow(0, $row)->getValue();
            $obj->WordInL2 = $worksheet->getCellByColumnAndRow(1, $row)->getValue();
        }
        elseif ($excelFile == "segments"){
            $obj->SegmentInL1 = $worksheet->getCellByColumnAndRow(0, $row)->getValue();
            $obj->SegmentInL2 = $worksheet->getCellByColumnAndRow(1, $row)->getValue();
        }
        if( $worksheet->getCellByColumnAndRow(2, $row)->getValue() == 'current')
            $obj->InCurrent = 'YES';

        $obj->insert();
    }
    return true;
}

function FromDatabaseToExcel($contentID, $dirName, $type)
{
    $where = "ContentID = :contentID";
    $whereParam = array(":contentID" => $contentID);

    if($type == 'word')
    {
        $subContentResult = ContentWord::SearchContentWord($where, $whereParam);
        $outputFileName = 'word_translation.csv';
        $l1Index = "WordInL1";
        $l2Index = "WordInL2";
        $A1Title = "Head word";
    }
    elseif ($type == "segment")
    {
        $subContentResult = ContentTranslationSegment::SearchContentSegment($where, $whereParam);
        $outputFileName = 'segment_translation.csv';
        $l1Index = "SegmentInL1";
        $l2Index = "SegmentInL2";
        $A1Title = "Segment";
    }

    $objPHPExcel = new PHPExcel();
    $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'CSV')->setDelimiter("\t");;
    $row = 1;
    $objPHPExcel->getActiveSheet()->setCellValue('A'.$row, $A1Title);
    $objPHPExcel->getActiveSheet()->setCellValue('B'.$row, 'Translation');
    $objPHPExcel->getActiveSheet()->setCellValue('C'.$row, 'CurrentDomain');

    for($i=0; $i < count($subContentResult) ; $i++)
    {
        $row = $i + 2;
       /* echo $subContentResult[$i][$l1Index] . "---" . $subContentResult[$i][$l2Index] . "---" .
            $subContentResult[$i]["InCurrent"] . "</br>";*/
        $objPHPExcel->getActiveSheet()->setCellValue('A'.$row, $subContentResult[$i][$l1Index]);
        $objPHPExcel->getActiveSheet()->setCellValue('B'.$row, $subContentResult[$i][$l2Index]);
        $objPHPExcel->getActiveSheet()->setCellValue('C'.$row, $subContentResult[$i]["InCurrent"]);
    }
    $objWriter->save($dirName . "/" . SubDirNames["corpus"] . "/" . $outputFileName);
    $excelOutput = str_replace("\"", "", file_get_contents($dirName . "/" . SubDirNames["corpus"] . "/" . $outputFileName));
    file_put_contents($dirName . "/" . SubDirNames["corpus"] . "/" . $outputFileName, $excelOutput);

    return true;
}

function UploadSubcontentTranslation($type)
{
    $resultArray = array();
    $resultArray[0]["resultMsg"] = "notSetYet";
    $resultArray[0]["id"] = $_REQUEST["ContentID"];

    if($type == "word")
    {
        $FileNameParts = explode('.', $_FILES['UploadWordTrnslt']['name']);
        $file = $_FILES['UploadWordTrnslt'];
        $fileName = "word_translation.csv";
    }
    elseif ($type == "segment")
    {
        $FileNameParts = explode('.', $_FILES['UploadSgmntTrnslt']['name']);
        $file = $_FILES['UploadSgmntTrnslt'];
        $fileName = "segment_translation.csv";
    }

    $FileExt = $FileNameParts[count($FileNameParts) - 1];
    $FileExt = strtolower($FileExt);
    if ($FileExt != "csv") {
        $resultArray[0]["resultMsg"] = "fileTypeError";
        $resultArray[0]["id"] = -1;
        $result = CreateResponse($resultArray);
        echo $result;
        die();
    }

    $where = "ContentID = :contentID";
    $whereParam = array(":contentID" => $_REQUEST["ContentID"]);
    $contentResult = Content::SearchContent($where, $whereParam);
    $L1Name =  Language::getLanguageName($contentResult[0]["L1ID"]);
    $L2Name =  Language::getLanguageName($contentResult[0]["L2ID"]);
    $outputFileName = $L2Name . "_" . $L1Name . ".csv";
    $fileDir = LaraContentDir . $contentResult[0]["DirName"] . "/" . SubDirNames["corpus"] . "/";
    if($type == "word")
    {
        $srcFile =  $fileDir . 'word_translation.csv';
        $destFolder = LaraContentDir . $L2Name . "/" . SubDirNames["translations"] . "/";
        $destFile = $destFolder . $outputFileName;

        $excelFile = "words";
    }
    elseif ($type == "segment")
    {
        $srcFile = $fileDir . 'segment_translation.csv';
        $destFolder = LaraContentDir . $contentResult[0]["DirName"] . "/" . SubDirNames["translations"] . "/";
        $destFile = $destFolder . $outputFileName;
        $excelFile = "segments";
    }
    if(UploadExcelFile($fileName, $fileDir, $file))
    {
        if(FromExcelToDatabase($excelFile, $fileDir, $_REQUEST["ContentID"]))
        {
            if (!file_exists( $destFolder ) && !is_dir($destFolder))
            {
                if(! mkdir($destFolder, 0777, true))
                {
                    return "CreateDIRFailed";
                }
            }
            if(!copy($srcFile,$destFile))
            {
                $resultArray[0]["resultMsg"] = "FinalCopyFailed";
            }
            else
            {
                $resultArray[0]["resultMsg"] = "UploadedAndCopied";
            }
        }
        else
        {
            $resultArray[0]["resultMsg"] = "TransferToDbFailed";
        }
    }
    else
    {
        $resultArray[0]["resultMsg"] = "UploadFileFailed";
    }
    $result = CreateResponse($resultArray);
    echo $result;
    die();
}

function UploadExcelFile($fileName, $fileDir, $file)
{
    $fp = fopen($fileDir . $fileName, "w");
    fwrite($fp, fread(fopen($file ['tmp_name'], 'r'), $file['size']));
    fclose($fp);
    return true;
}

function FromMetadataToDatabase($contentID, $type)
{
    $where = " ContentID = :contentID";
    $whereParam = array(":contentID" => $contentID);

    //ConfigInfo
    $configObjInfo = ContentConfig::SearchContentConfig($where, $whereParam);
    if ($configObjInfo != false) {
        require_once 'Content.data.php';
        $configObj = FillConfigItems($configObjInfo);

        $mdObj = new ContentRecordingMetadata();
        $mdObj->ContentID = $contentID;
        $mdObj->RecordingType = $type;

        if ($type == "segment")
        {
            $obj = new ContentRecordingSegment();
            $mdObj->MetadataFileDirectory = $configObj->segment_audio_directory . "/metadata_help.txt";
        }
        else if ($type == "word")
        {
            //todo $obj = new ??????();
            $mdObj->MetadataFileDirectory = $configObj->word_audio_directory . "/metadata_help.txt";
        }

        if($mdObj->IsRegistered() == false)
        {
            $mdObj->insert();
            $mdObj->RecordingMetadataID = ContentRecordingMetadata::lastID();
        }

        $obj->RecordingMetadataID = $mdObj->RecordingMetadataID;

        $fileContent = file_get_contents($mdObj->MetadataFileDirectory);

        $fileContent = str_replace("AudioOutput help any_speaker help/", "<" , $fileContent);
        $fileContent = str_replace("# |", ">" , $fileContent);

        preg_match_all('/<(.*?)>/', $fileContent, $match);

        for($i = 0; $i < count($match[1]); $i++)
        {
            $matchParts= explode(".mp3 ",$match[1][$i]);
            $obj->AudioFileName = $matchParts[0] . ".mp3";
            $obj->SegmentText = $matchParts[1];

            if($obj->IsRegistered() == false)
                $obj->insert();
            else
                $obj->update();
        }
        return true;
    }
    else
    {
        return false;
    }
}