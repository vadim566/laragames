<?php
/**
 * Created by PhpStorm.
 * User: habibih
 * Date: 4/11/2019
 * Time: 12:23 PM
 */

require_once '../class/User.class.php';

$task = isset($_REQUEST["task"]) ? $_REQUEST["task"] :  "";

switch ($task)
{
    case "userSignUp":
        userSignUp();

    case "userLogin":
        userLogin();

    case "userLogout":
        userLogout();
}

function userSignUp()
{
    $userObj = FillItems($_POST);

    $res = $userObj->checkDuplication();
    if($res == "NoDuplication")
    {
        $userObj->PasswordSalt = generateRandomSalt();
        $userObj->Password = password_hash($userObj->Password . $userObj->PasswordSalt, PASSWORD_DEFAULT);
        $userObj->insert();
    }

    echo $res;
    die();
}

function userLogin()
{
    $where = " Username = :userNameEmail or Email = :userNameEmail";
    $whereParam = array(":userNameEmail" => $_POST["UserNameEmail"]);
    $res = User::UserLogin($where, $whereParam);

    if (count($res) == 0)
    {
        echo "UserNotFound";
    } else if (!password_verify(  $_POST["UserPassword"] . $res[0]["PasswordSalt"] , $res[0]["Password"]))
    {
        echo "WrongPassword";
    } else {
        session_start();
        $_SESSION['UserID'] = $res[0]['UserID'];
        $_SESSION['UserName'] = $res[0]['UserName'];
        $_SESSION['Email'] = $res[0]['Email'];
        echo "LoginNow";
    }
    die();
}

function FillItems($src)
{
    $userObj = new  User();
    PdoDataAccess::FillObjectByArray($userObj, $src);
    return $userObj;
}

function generateRandomSalt() {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $randomString = '';
    for ($i = 0; $i < 10; $i++) {
        $randomString .= $characters[rand(0, strlen($characters) - 1)];
    }
    return $randomString;
}

function userLogout()
{
    session_start();
    session_unset();
    session_destroy();
    echo true;
    die();
}

?>