<?php
/**
 * Created by PhpStorm.
 * User: habibih
 * Date: 9/11/2019
 * Time: 03:59 PM
 */

require_once "../data/SegmentsAndWords.data.php";
require_once "../DataLayer/PdoDataAccess.class.php";

$query = "SELECT ContentID, segment_audio_directory
            FROM ContentConfig
            where segment_audio_directory is not null";

$temp = PdoDataAccess::runquery($query);
for($i = 0; $i < count($temp); $i++)
{
    $fileDirectory = $temp[$i]["segment_audio_directory"] . "/metadata_help.txt";
    $contentID = $temp[$i]["ContentID"];
    if(file_exists($fileDirectory))
    {
        FromMetadataToDatabase($contentID, 'segment');
    }
}


echo "Done";


?>