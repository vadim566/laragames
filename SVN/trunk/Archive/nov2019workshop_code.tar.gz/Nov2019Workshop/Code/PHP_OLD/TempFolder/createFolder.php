<?php
/**
 * Created by PhpStorm.
 * User: habibih
 * Date: 8/7/2019
 * Time: 05:20 PM
 */

require_once '../DataLayer/PdoDataAccess.class.php';
require_once '../top.php';


$query = "SELECT DirName FROM `Contents`";
$temp = PdoDataAccess::runquery($query);
for($i = 0 ; $i < count($temp); $i++) {
    $dirAddress = ContentTmpDirectory . $temp[$i][0];
    echo $dirAddress;
    if (!file_exists( $dirAddress ) && !is_dir($dirAddress))
    {
        //if not, try to create the root directory
        if(! mkdir($dirAddress, 0777, true))
        {
            echo "CreateDIRFailed";
        }
        else
        {
            //and then, create 3 sub directories
            for($i = 0; $j < count(SubDirNamesContentTmp); $j++)
            {

                $subDir = $dirAddress . "/" . array_keys(SubDirNamesContentTmp)[$j];
                echo $subDir;
                if( !mkdir($subDir, 0777, true))
                {
                    echo "CreateSubDIRFailed";
                }
            }
            echo "DIRCreated";
        }
    }
    else
    {
        echo "DIRExists";
    }
echo "***********************";
}
