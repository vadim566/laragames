<?php


class DataAudit
{
	private $DataAuditID;
  	private $PersonID; 			// کد شخصی عمل کننده 
 	private $RoleID; 			// کد نقش فرد
  	private $SysCode; 			// کد سیستم جاری
  	private $PageName; 			// نام صفحه ای این دستکاری توسط آن انجام شده
  	private $IPAddress; 		// آدرس آی پی کامپیوتر عمل کننده
  	private $ActionTime; 		// زمان انجام عمل
  	private $IsSecure; 			// ENUM('YES','NO') 'در صورتیکه در زمان اجرای عمل قفل سخت افزاری وجود داشته باشد بلی در غیر اینصورت خیر
  	private $QueryString;
	
  	/**
  	 * ENUM('STAFF','PROF','STUDENT','NONE') نوع فردی که داده دستکاری شده مربوط به اوست
  	 */
	const PersonType_staff = "STAFF";
	const PersonType_prof = "PROF";
	const PersonType_student = "STUDENT";
	const PersonType_none = "NONE";
  	public  $RelatedPersonType = self::PersonType_none;
  	
	/**
  	 * کد شخصی فردی که روی داده او عمل شده
  	 */
  	public  $RelatedPersonID;
  	
  	/**
  	 * شماره دانشجویی که روی داده های او عمل شده
  	 */
  	public  $RelatedStNo;
  	
	/**
	* نام جدولی که عملیات روی آن انجام می شود
  	 */
  	public  $TableName;
  	
	/**
  	 * کد داده اصلی دستکاری شده
  	 */
  	public  $MainObjectID;
  	
	/**
  	 * کد داده فرعی دستکاری شده
  	 */
  	public  $SubObjectID;

	const Action_add = "ADD";
	const Action_delete = "DELETE";
	const Action_update = "UPDATE";
	const Action_replace = "REPLACE";
	const Action_view = "VIEW";
	const Action_search = "SEARCH";
	const Action_send = "SEND";
	const Action_return = "RETURN";
	const Action_confirm = "CONFIRM";
	const Action_reject = "REJECT";
	const Action_other = "OTHER";
	/**
	* 	نوع عمل
  	*/
  	public  $ActionType;
  	
	/**
  	 * توضیحات بیشتر
  	 */
  	public  $description;
	
	/**
  	 * کوئری اجرا شده
  	 */
  	
  	public function execute($pdo = null)
  	{
  		//------------------- fill data members --------------------
  		$this->DataAuditID = PDONULL;
  		$this->PersonID = isset($_SESSION["PersonID"]) ? $_SESSION["PersonID"] : "";
  		$this->RoleID = isset($_SESSION["UserRole"]) ? $_SESSION["UserRole"] : "";
  		
  		$this->SysCode = isset($_SESSION["SystemCode"]) ? $_SESSION["SystemCode"] : "";
  		$this->PageName = isset($_SERVER['HTTP_REFERER']) ? $_SERVER['HTTP_REFERER'] : $_SERVER['SCRIPT_FILENAME'];
  		$this->IPAddress = $_SESSION['LIPAddress'];
  		
  		$this->IsSecure = "No";
  		$this->ActionTime = PDONOW;

		$this->QueryString = PdoDataAccess::GetLatestQueryString();
  		//----------------------------------------------------------
		if(!empty($this->MainObjectID))
			$this->MainObjectID = (int)$this->MainObjectID;
		if(!empty($this->SubObjectID))
			$this->SubObjectID = (int)$this->SubObjectID;
		if(!empty($this->RelatedPersonID))
			$this->RelatedPersonID = (int)$this->RelatedPersonID;
		if(!empty($this->RelatedStNo))
			$this->RelatedStNo = (int)$this->RelatedStNo;
		//----------------------------------------------------------
  		PdoDataAccess::insert("DataAudit", $this, $pdo);
  	}
  	
}


?>