<?php
/**
 * Created by PhpStorm.
 * User: habibih
 * Date: april 2019
 */

/**
 * It's better to move it in a folder which is shared between all projects.
 * But by now, not needed.
 */
class Config{
	//localSetting
	/*public static $db_servers = array(
		'LARA' => array(
			"driver" => 'mysql',
			"host" => 'localhost',
			"user" => 'root',
			"pass" => '',
			"database" => 'LARA-portal'
		));*/

	//serverSetting
	public static $db_servers = array(
		'LARA' => array(
			"driver" => 'mysql',
			"host" => '127.0.0.1',
			"user" => 'laraportaluser',
			"pass" => 'v8jfr3RmhY6Htapd',
			"database" => 'LARA-portal'
		));


	//public static variables will be defined here
}
?>

