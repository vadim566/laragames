<?php
/**
 * Created by PhpStorm.
 * User: habibih
 * Date: april 2019
 */

require_once 'Config.class.php';

class LaraConfig{
	 public static $db_server = array (
	          "driver"   => "",
	          "host"     => "",
	          "database" => "",
	          "user"     => "",
	          "pass"     => ""
	 );

	 public static $page_authorize = true;
}

LaraConfig::$db_server = array (
	"driver" => Config::$db_servers['LARA']["driver"],
	"host" => Config::$db_servers['LARA']["host"],
	"user" => Config::$db_servers['LARA']["user"],
	"pass" => Config::$db_servers['LARA']["pass"],
	"database" => Config::$db_servers['LARA']["database"]

   );


?>
