<?php
/**
 * Created by PhpStorm.
 * User: habibih
 * Date: 8/20/2019
 * Time: 03:17 PM
 */

require_once '../DataLayer/PdoDataAccess.class.php';


class ContentRecordingMetadata
{

    public $RecordingMetadataID;
    public $ContentID;
    public $RecordingType;
    public $MetadataFileDirectory;

    function insert()
    {
        PdoDataAccess::insert("ContentRecordingMetadata", $this);
    }

    static function lastID($where = "", $whereParams = array())
    {
        return PdoDataAccess::GetLastID("ContentRecordingMetadata", "RecordingMetadataID", $where, $whereParams);
    }

    static function delete($where, $whereParams)
    {
        return PdoDataAccess::delete("ContentRecordingMetadata", $where, $whereParams);
    }

    function IsRegistered()
    {
        $query = "Select * from ContentRecordingMetadata where  " .
            "MetadataFileDirectory = :metadataFileDirectory and 
             RecordingType = :recordingType and ContentID = :contentID";

        $whereParams = array(":contentID" => $this->ContentID,
            ":recordingType" => $this->RecordingType,
            ":metadataFileDirectory" => $this->MetadataFileDirectory);

        $temp = PdoDataAccess::runquery($query, $whereParams);

        if(count($temp) == 0)
        {
            return false;
        }
        else
        {
            $this->RecordingMetadataID = $temp[0]["RecordingMetadataID"];
            return true;
        }
    }
}


?>