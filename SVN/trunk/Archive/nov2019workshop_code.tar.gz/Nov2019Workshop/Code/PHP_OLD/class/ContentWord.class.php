<?php
/**
 * Created by PhpStorm.
 * User: habibih
 * Date: juin 2019
 */


require_once '../DataLayer/PdoDataAccess.class.php';

class ContentWord
{
    public $ContentWordID;
    public $ContentID;
    public $WordInL1;
    public $WordInL2;
    public $InCurrent;

    function insert()
    {
        PdoDataAccess::insert("ContentWords", $this);
    }

    static function lastID($where = "", $whereParams = array())
    {
        return PdoDataAccess::GetLastID("ContentWords", "ContentWordID", $where, $whereParams);
    }

    function update()
    {
        $whereParams[":contentWordID"] = $this->ContentWordID;
        PdoDataAccess::update("ContentWords", $this, "ContentWordID=:contentWordID", $whereParams);
    }

    static function delete($where, $whereParams)
    {
        return PdoDataAccess::delete("ContentWords", $where, $whereParams);
    }

    static function SearchContentWord($where = "", $whereParam = array())
    {
        $query = "select * from ContentWords ";

        $query .= (!empty($where)) ? " where " . $where : "";

        if(!empty($whereParam))
            $temp = PdoDataAccess::runquery($query, $whereParam);
        else
            $temp = PdoDataAccess::runquery($query);

        return $temp;
    }

    static function ContentWordsCount($where = "", $whereParam = array())
    {
        $query = "select count(*) from ContentWords ";
        $query .= (!empty($where)) ? " where " . $where : "";

        if(!empty($whereParam))
            $temp = PdoDataAccess::runquery($query, $whereParam);
        else
            $temp = PdoDataAccess::runquery($query);

        $res["totalWords"] =$temp[0][0];

        $query = "select count(*) from ContentWords where WordInL2 is not null  ";
        $query .= (!empty($where)) ? " and " . $where : "";

        if(!empty($whereParam))
            $temp = PdoDataAccess::runquery($query, $whereParam);
        else
            $temp = PdoDataAccess::runquery($query);

        $res["translatedWords"] =$temp[0][0];
        return $res;
    }
}
?>
