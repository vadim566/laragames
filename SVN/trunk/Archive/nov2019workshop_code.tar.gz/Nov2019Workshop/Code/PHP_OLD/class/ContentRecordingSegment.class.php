<?php
/**
 * Created by PhpStorm.
 * User: habibih
 * Date: juin 2019
 */


require_once '../DataLayer/PdoDataAccess.class.php';

class ContentRecordingSegment
{
    public $ContentSegmentID;
    public $RecordingMetadataID;
    public $SegmentText;
    public $AudioFileName;

    function insert()
    {
        PdoDataAccess::insert("ContentRecordingSegments", $this);
    }

    static function lastID($where = "", $whereParams = array())
    {
        return PdoDataAccess::GetLastID("ContentRecordingSegments", "ContentSegmentID", $where, $whereParams);
    }

    function update()
    {
        $whereParams[":contentSegmentID"] = $this->ContentSegmentID;
        PdoDataAccess::update("ContentRecordingSegments", $this, "ContentSegmentID=:contentSegmentID", $whereParams);
    }

    static function delete($where, $whereParams)
    {
        return PdoDataAccess::delete("ContentRecordingSegments", $where, $whereParams);
    }

    static function SearchRecordingSegments($where = "", $whereParam = array())
    {
        $query = "select * from ContentRecordingSegments ";

        $query .= (!empty($where)) ? " where " . $where : "";

        if(!empty($whereParam))
            $temp = PdoDataAccess::runquery($query, $whereParam);
        else
            $temp = PdoDataAccess::runquery($query);

        return $temp;
    }

    function IsRegistered()
    {
        $query = "Select * from ContentRecordingSegments where  " .
            "RecordingMetadataID = :recordingMetadataID and 
             SegmentText = :segmentText";

        $whereParams = array(":recordingMetadataID" => $this->RecordingMetadataID,
            ":segmentText" => $this->SegmentText);

        $temp = PdoDataAccess::runquery($query, $whereParams);

        if(count($temp) == 0)
        {
            return false;
        }
        else
        {
            $this->ContentSegmentID = $temp[0]["ContentSegmentID"];
            return true;
        }
    }

}
?>
