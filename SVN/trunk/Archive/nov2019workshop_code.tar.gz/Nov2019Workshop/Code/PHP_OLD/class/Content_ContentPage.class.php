<?php
/**
 * Created by PhpStorm.
 * User: habibih
 * Date: 4/17/2019
 * Time: 02:38 PM
 */

require_once '../DataLayer/PdoDataAccess.class.php';


class Content_ContentPage
{

    public $PageID;
    public $ContentID;
    public $PageOrder;

    function insert()
    {
        PdoDataAccess::insert("Content_ContentPages", $this);
    }

    static function lastID($where = "", $whereParams = array())
    {
        return PdoDataAccess::GetLastID("Content_ContentPages", "PageID", $where, $whereParams);
    }

    static function delete($where, $whereParams)
    {
        return PdoDataAccess::delete("Content_ContentPages", $where, $whereParams);
    }
}


?>