<?php
/**
 * Created by PhpStorm.
 * User: habibih
 * Date: april 2019
 */


require_once '../DataLayer/PdoDataAccess.class.php';

class Content
{
    public $ContentID;
    public $ContentName;
    public $DirName;
    public $CreatorID;
    public $L1ID;
    public $L2ID;
    public $TreeTaggerStatus;
    public $LangRepType;
    public $WordAudio;
    public $SegmentAudio;
    public $AudioMouseOver;
    public $WordTranslationMouseOver;
    public $SegmentTranslationMouseOver;
    public $L1rtl;
    public $TableOfContents;
    public $KeepComments;
    public $CommentsByDefault;
    public $LinguisticsArticleComments;
    public $ColouredWords;
    public $AudioWordsInColour;
    public $MaxExamplesPerWordPage;
    public $ExtraPageInfo;
    public $Font;
    public $FrequencyListsInMainText;
    public $RawTextFileName;
    public $TaggedTextFileName;
    public $ContentStatus;
    public $WordLdtTaskID;
    public $SegmentLdtTaskID;
    public $HasExternalResources;
    public $HasEmbeddedImage;
    public $HasEmbeddedAudio;
    public $HasEmbeddedCSS;
    public $HasEmbeddedScript;
    public $WebAddress;
    public $IsDeleted;
    public $DistributedResourceID;

    function insert()
    {
        PdoDataAccess::insert("Contents", $this);
    }

    static function lastID($where = "", $whereParams = array())
    {
        return PdoDataAccess::GetLastID("Contents", "ContentID", $where, $whereParams);
    }

    static function SearchContent($where = "", $whereParam = array())
    {
        $query = "select * from Contents ";

        $query .= (!empty($where)) ? " where " . $where : "";

        if(!empty($whereParam))
            $temp = PdoDataAccess::runquery($query, $whereParam);
        else
            $temp = PdoDataAccess::runquery($query);

        return $temp;
    }

    static function FullSelect($where = "", $whereParam = array())
    {
        $query = "select 
                    ContentID,
                    UserName,
                    ContentName,
                    DirName,
                    WebAddress,
                    TreeTaggerStatus,
                    ContentStatus,
                    l1.LanguageName L1Name,
                    l2.LanguageName L2Name 
                from Contents c
                left join Users u on (u.UserID = c.CreatorID)
                left join Languages l1 on (c.L1ID = l1.LanguageID)
                left join Languages l2 on (c.L2ID = l2.LanguageID)";

        $query .= (!empty($where)) ? " where " . $where : "";

        if(!empty($whereParam))
            $temp = PdoDataAccess::runquery($query, $whereParam);
        else
            $temp = PdoDataAccess::runquery($query);

        return $temp;
    }

    function update()
    {
        $whereParams[":contentID"] = $this->ContentID;
        PdoDataAccess::update("Contents", $this, "ContentID=:contentID", $whereParams);
    }

    static function PartialUpdate($setPart, $wherePart, $params)
    {
        $query = "update Contents set " . $setPart . " where " . $wherePart;
        PdoDataAccess::runquery($query, $params);
    }
}
?>
