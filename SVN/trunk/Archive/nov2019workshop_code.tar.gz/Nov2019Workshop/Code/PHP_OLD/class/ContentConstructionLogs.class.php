<?php
/**
 * Created by PhpStorm.
 * User: habibih
 * Date: july 2019
 */


require_once '../DataLayer/PdoDataAccess.class.php';

class ContentConstructionLogs
{
    public $LogID;
    public $LogType;
    public $LogDesc;
    public $LogDateTime;
    public $UserID;
    public $ContentID;
    public $ContentStatus;

    function insert()
    {
        PdoDataAccess::insert("ContentConstructionLogs", $this);
    }

    static function lastID($where = "", $whereParams = array())
    {
        return PdoDataAccess::GetLastID("ContentConstructionLogs", "LogID", $where, $whereParams);
    }

    static function SearchContentConstructionLogs($where = "", $whereParam = array())
    {
        $query = "select * from ContentConstructionLogs ";

        $query .= (!empty($where)) ? " where " . $where : "";

        if(!empty($whereParam))
            $temp = PdoDataAccess::runquery($query, $whereParam);
        else
            $temp = PdoDataAccess::runquery($query);

        return $temp;
    }

}
?>
