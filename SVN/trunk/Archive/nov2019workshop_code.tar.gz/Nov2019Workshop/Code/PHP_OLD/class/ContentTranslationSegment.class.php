<?php
/**
 * Created by PhpStorm.
 * User: habibih
 * Date: juin 2019
 */


require_once '../DataLayer/PdoDataAccess.class.php';

class ContentTranslationSegment
{
    public $ContentSegmentID;
    public $ContentID;
    public $SegmentInL1;
    public $SegmentInL2;
    public $InCurrent;

    function insert()
    {
        PdoDataAccess::insert("ContentTranslationSegments", $this);
    }

    static function lastID($where = "", $whereParams = array())
    {
        return PdoDataAccess::GetLastID("ContentTranslationSegments", "ContentSegmentID", $where, $whereParams);
    }

    function update()
    {
        $whereParams[":contentSegmentID"] = $this->ContentSegmentID;
        PdoDataAccess::update("ContentTranslationSegments", $this, "ContentSegmentID=:contentSegmentID", $whereParams);
    }

    static function delete($where, $whereParams)
    {
        return PdoDataAccess::delete("ContentTranslationSegments", $where, $whereParams);
    }

    static function SearchContentSegment($where = "", $whereParam = array())
    {
        $query = "select * from ContentTranslationSegments ";

        $query .= (!empty($where)) ? " where " . $where : "";

        if(!empty($whereParam))
            $temp = PdoDataAccess::runquery($query, $whereParam);
        else
            $temp = PdoDataAccess::runquery($query);

        return $temp;
    }


    static function ContentSegmentCount($where = "", $whereParam = array())
    {
        $query = "select count(*) from ContentTranslationSegments ";
        $query .= (!empty($where)) ? " where " . $where : "";

        if(!empty($whereParam))
            $temp = PdoDataAccess::runquery($query, $whereParam);
        else
            $temp = PdoDataAccess::runquery($query);

        $res["totalSegs"] =$temp[0][0];

        $query = "select count(*) from ContentTranslationSegments where SegmentInL2 is not null  ";
        $query .= (!empty($where)) ? " and " . $where : "";

        if(!empty($whereParam))
            $temp = PdoDataAccess::runquery($query, $whereParam);
        else
            $temp = PdoDataAccess::runquery($query);

        $res["translatedSegs"] =$temp[0][0];
        return $res;
    }


}
?>
