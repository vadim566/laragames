<?php
/**
 * Created by PhpStorm.
 * User: habibih
 * Date: 4/17/2019
 * Time: 02:38 PM
 */

require_once '../DataLayer/PdoDataAccess.class.php';


class Content_PageSegment
{

    public $SegmentID;
    public $PageID;
    public $SegmentOrder;

    function insert()
    {
        PdoDataAccess::insert("Content_PageSegments", $this);
    }

    static function delete($where, $whereParams)
    {
        return PdoDataAccess::delete("Content_PageSegments", $where, $whereParams);
    }
}


?>