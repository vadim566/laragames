<?php
/**
 * Created by PhpStorm.
 * User: habibih
 * Date: july 2019
 */


require_once ROOT . 'DataLayer/PdoDataAccess.class.php';

class ExternalCommandsLogs
{
    public $LogID;
    public $LogType;
    public $LogData;
    public $LogDateTime;
    public $UserID;
    public $RelatedID;
    public $RelatedPage;

    function insert()
    {
        PdoDataAccess::insert("ExternalCommandsLogs", $this);
    }

    static function lastID($where = "", $whereParams = array())
    {
        return PdoDataAccess::GetLastID("ExternalCommandsLogs", "LogID", $where, $whereParams);
    }

    static function SearchExternalCommandsLogs($RelatedID = "", $RelatedPage = "")
    {
        $query = 'SELECT CONCAT( LogType , " : ", LogData) as LogInfo , 
                         CONCAT( "Executed at : " , LogDateTime) as LogTime 
                         FROM ExternalCommandsLogs
                         where LogType in ("PythonCmnd", "PythonRes") and 
                               RelatedID = :relatedID and RelatedPage = :relatedPage 
                         ORDER BY LogTime DESC';

        $whereParam = array(":relatedID" => $RelatedID, ":relatedPage" => $RelatedPage);
        $temp = PdoDataAccess::runquery($query, $whereParam);
        return $temp;
    }

}
?>
