<?php
/**
 *
 * Created by PhpStorm.
 * User: habibih
 * Date: 8/21/2019
 */


require_once '../DataLayer/PdoDataAccess.class.php';

class ReadingHistory
{
    public $ReadingHistoryID;
    public $ReadingHistoryName;
    public $UserID;
    public $L1ID;
    public $L2ID;
    public $PreferredVoice;
    public $AudioMouseOver;
    public $WordTranslationMouseOver;
    public $SegmentTranslationMouseOver;

    function insert()
    {
        PdoDataAccess::insert("ReadingHistories", $this);
    }

    static function delete($where, $whereParams)
    {
        return PdoDataAccess::delete("ReadingHistories", $where, $whereParams);
    }

    static function lastID($where = "", $whereParams = array())
    {
        return PdoDataAccess::GetLastID("ReadingHistories", "ReadingHistoryID", $where, $whereParams);
    }

    static function SearchReadingHistory($where = "", $whereParam = array())
    {
        $query = "select * from ReadingHistories ";

        $query .= (!empty($where)) ? " where " . $where : "";

        if(!empty($whereParam))
            $temp = PdoDataAccess::runquery($query, $whereParam);
        else
            $temp = PdoDataAccess::runquery($query);

        return $temp;
    }

    static function FullSelect($where = "", $whereParam = array())
    {
        $query = "SELECT rh.*, l1.LanguageName L1Name, l2.LanguageName L2Name
                  FROM ReadingHistories rh 
                  left join Languages l1 on (rh.L1ID = l1.LanguageID)
                  left join Languages l2 on (rh.L2ID = l2.LanguageID)";

        $query .= (!empty($where)) ? " where " . $where : "";

        if(!empty($whereParam))
            $temp = PdoDataAccess::runquery($query, $whereParam);
        else
            $temp = PdoDataAccess::runquery($query);

        return $temp;
    }

    function update()
    {
        $whereParams[":readingHistoryID"] = $this->ReadingHistoryID;
        PdoDataAccess::update("ReadingHistories", $this, "ReadingHistoryID=:readingHistoryID", $whereParams);
    }

    static function PartialUpdate($setPart, $wherePart, $params)
    {
        $query = "update ReadingHistories set " . $setPart . " where " . $wherePart;
        PdoDataAccess::runquery($query, $params);
    }

    function hasAssignedResource()
    {
        $query = "select count(*) from ReadingHistoryResources 
                  where ReadingHistoryID = :readingHistoryID";

        $whereParams[":readingHistoryID"] = $this->ReadingHistoryID;

        $temp = PdoDataAccess::runquery($query, $whereParams);
        if($temp[0][0] == 0)
            return false;
        else
            return true;
    }

    function listOfHistoryResourcesForConfig($where, $whereParam)
    {
        $query = "SELECT concat('[\"', d1.ResourceID, '_', d1.ResourceName, '\",',
				                '\"', d2.ResourceID, '_', d2.ResourceName, '\",',
                                '[1,' , rhr.LastReadPage, ']]') as HistoryResInfo 
                          
				  FROM ReadingHistoryResources rhr
                    left join DistributedResources d1  on (rhr.ResourceID = d1.ResourceID)
                    left join DistributedResources d2 on (d1.ParentID = d2.ResourceID)";

        $query .= (!empty($where)) ? " where " . $where : "";
        if(!empty($whereParam))
            $temp = PdoDataAccess::runquery($query, $whereParam);
        else
            $temp = PdoDataAccess::runquery($query);

        return $temp;
    }
}

?>
