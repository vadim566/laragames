
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="description" content="LARA">
    <meta name=viewport content="width=device-width, initial-scale=1">
    <title>LARA PORTAL</title>

    <link rel="stylesheet" href="../css/index.css">
</head>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script src="../js/index.js"></script>

<body>

<?php
require "header.html";
?>

    <main>
      <div class="wrapper-main" id="mainBody">
        <section class="section-default">
        <?php
            if(isset($_REQUEST['status']) && $_REQUEST['status'] == 'logout')
            {
                echo '<p class="login-status" id="mainContent">You Have Successfully Logged Out.</p>';
            }
            else if(isset($_REQUEST['status']) && $_REQUEST['status'] == 'sessionExpired')
            {
            echo '<p class="login-status" id="mainContent">Session Expired. Please login again to continue.</p>';
            }
            else
            {
                echo '<p class="login-status" id="mainContent">Welcome to LARA Portal</p>';
            }
        ?>
        </section>
      </div>
    </main>


</body>
</html>





