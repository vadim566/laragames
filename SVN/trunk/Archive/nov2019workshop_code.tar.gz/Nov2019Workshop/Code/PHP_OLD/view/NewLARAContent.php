<?php
/**
 * Created by PhpStorm.
 * User: habibih
 * Date: 4/16/2019

 */

?>

<link rel="stylesheet" href="../css/MainContent.css">
<link rel="stylesheet" href="../css/TableToDiv.css">
<link rel="stylesheet" href="../css/jquery-ui.css">
<meta charset="utf-8">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

<?php
    $now = new DateTime();
    echo '<script src="../js/LARAContent.js?' . $now->format('His') . '"></script>';
    echo '<script src="../js/ShowLoading.js?' . $now->format('His') . '"></script>';
    echo '<script src="../js/jquery-1.12.4.js?' . $now->format('His') . '"></script>';
    echo '<script src="../js/jquery-ui.js?' . $now->format('His') . '"></script>';


require_once "../class/Language.class.php";
require_once "../class/User.class.php";
require_once "../class/Content.class.php";
require_once "../data/Content.data.php";
require_once "../class/ContentConfig.class.php";
require_once "../class/ContentWord.class.php";
require_once "../class/ContentTranslationSegment.class.php";
require_once "../class/ContentEmbeddedItem.class.php";
require_once "../class/DistributedResource.class.php";
require_once "../top.php";

if(!isset($_SESSION["UserID"]))
{
    echo "Please Login again. <br />";
    echo "<a href='index.php?status=sessionExpired'>Click Here to Login</a>";
    die();
}

$logInRes = LogIntoLDT();
$logInRes = json_decode($logInRes, true);

if($logInRes["access_token"] == "LDTAuthenticationFailed")
{
    echo "Opps.. Unable to login to LDT. Please contact with Hanieh.";
    die();
}
else
{
    $tokenType = $logInRes["token_type"];
    $accessToken = $logInRes["access_token"];
    $headerInfo = $tokenType . " " . $accessToken ;
    $drp_Word    = User::UserDropBox($headerInfo, "WordAudio");
    $drp_Segment = User::UserDropBox($headerInfo, "SegmentAudio");
}

$drp_L1 = Language::LanguageDropBox("L1ID", true);
$drp_L2 = Language::LanguageDropBox("L2ID", true);
$contentObj = array();
$configObj = array();
$wordAndSegObj = (object) array("wordTotal" => "0",
                                "wordTranslated" => "0",
                                "segTotal"=>"0",
                                "segTranslated"=>"0");

$emItemsObj = (object) array("ImageNames"=>"",
                             "AudioNames"=>"",
                             "cssNames"=>"",
                             "ScriptNames"=>"");

if(isset($_GET["Q0"]))
{
    $where = " ContentID = :contentID";
    $whereParam = array(":contentID" => $_GET["Q0"]);
    $info = Content::SearchContent($where, $whereParam);
	if(count($info) != 0)
	{
        $contentObj = FillItems($info[0]);
        //ConfigInfo
        $configObjInfo = ContentConfig::SearchContentConfig($where, $whereParam);
        if($configObjInfo != false)
        {
            $configObj = FillConfigItems($configObjInfo);
            $jsObjName = "configVal";
            echo objToJS($configObj, $jsObjName);
        }
        //WordAndSegmentInfo
        $wordInfo = ContentWord::ContentWordsCount($where, $whereParam);
        if(count($wordInfo) != 0)
        {
            $wordAndSegObj->wordTotal = $wordInfo["totalWords"];
            $wordAndSegObj->wordTranslated = $wordInfo["translatedWords"];
        }
        $segmentInfo = ContentTranslationSegment::ContentSegmentCount($where, $whereParam);
        if(count($segmentInfo) != 0)
        {
            $wordAndSegObj->segTotal = $segmentInfo["totalSegs"];
            $wordAndSegObj->segTranslated = $segmentInfo["translatedSegs"];
        }
        //EmbeddedItemsInfo
        $emItemsInfo = ContentEmbeddedItem::ListOfContentEItems($_GET["Q0"]);
        if($emItemsInfo != false)
        {
            $emItemsObj->ImageNames = $emItemsInfo["ImageNames"];
            $emItemsObj->AudioNames = $emItemsInfo["AudioNames"];
            $emItemsObj->cssNames = $emItemsInfo["cssNames"];
            $emItemsObj->ScriptNames = $emItemsInfo["ScriptNames"];
        }
        //RelatedReadingHistories
        $UsageInReadingsCount = 0;
        $PublishOptions = '';
        if(!empty($contentObj->DistributedResourceID))
        {
            $UsageInReadingsCount = DistributedResource::UsageInReadingsCount($contentObj->DistributedResourceID);
            if($UsageInReadingsCount != 0)
            {
                $PublishOptions = "<select name='PublishOptions' id='PublishOptions'>";
                $PublishOptions .=  "<option value='Undefined' selected>---</option>";
                $PublishOptions .=  "<option value='Update'>Republish the resource</option>";
                $PublishOptions .=  "<option value='Reinsert'>Publish a new edition and delete the old one.</option>";
                $PublishOptions .= "</select>";
            }
        }
    }
}
else
{
    $UsageInReadingsCount = 0;
    $contentObj = MakeEmptyContent();
}

$jsObjName = "contentVal";
echo objToJS($contentObj, $jsObjName);

$jsObjName = "wordAndSegVal";
echo objToJS($wordAndSegObj, $jsObjName);

$jsObjName = "emItemVal";
echo objToJS($emItemsObj, $jsObjName);

$activeTab = 0;
if(isset($_GET["activeTab"]))
{
    $activeTab = $_GET["activeTab"];
}

$MsgToShow = "notSetYet";
$PythonFailureReturnMsgs = array("TaggedFileFailed", "FailedToExtractExtResFile", "FailToSegmentize", "MergeLanguageResourcesFailed", "FirstCompileStepFailed",
                                "InstallPrvAudioFailed", "InstallZipfileFailed", "InstallNolLDTAudioFailed", "CreatePagesFailed", "FailedToExtractPageNames", "FailedPublish");

if(isset($_GET["activeTab"]))
{
    $MsgToShow = $_GET["msg"];
}

echo '<script>onLoad(' . $activeTab . ',"'. $MsgToShow .'");</script>';
?>

<div class="newLaraContent">

    <div class="table configFileError"  style="display: none">
        <div class="tr">
            <div class="tdInput">
                <p class="ErrorMsg"></p>
            </div>
            <div class="tdTitle">
                <img src='../img/ok-icon.png' title='hide it'
                      onclick='$(".configFileError").css("display", "none");' >
                <?php
                    if(in_array($MsgToShow, $PythonFailureReturnMsgs)){
                        echo "<img src='../img/detail-icon.png' title='show detail' onclick='showPythonOutput();' >";
                    }
                ?>
            </div>
        </div>
    </div>

    <div id="tabs">

    <form method="POST" id="configFileForm" enctype='multipart/form-data'>
        <input type="hidden" id="task" name="task">
        <input type="hidden" id="accessToken" name="accessToken" value="<?php echo $accessToken; ?>">
        <input type="hidden" id="tokenType" name="tokenType" value="<?php echo $tokenType; ?>">
        <input type="hidden" id="ContentID" name="ContentID">
        <input type="hidden" id="DirName" name="DirName">
        <input type="hidden" id="CreatorID" name="CreatorID">
        <input type="hidden" id="RawTextFileName" name="RawTextFileName">
        <input type="hidden" id="TaggedTextFileName" name="TaggedTextFileName">
        <input type="hidden" id="ContentStatus" name="ContentStatus">
        <input type="hidden" id="WordLdtTaskID" name="WordLdtTaskID">
        <input type="hidden" id="SegmentLdtTaskID" name="SegmentLdtTaskID">
        <input type="hidden" id="HasExternalResources" name="HasExternalResources">
        <input type="hidden" id="HasEmbeddedImage" name="HasEmbeddedImage">
        <input type="hidden" id="HasEmbeddedAudio" name="HasEmbeddedAudio">
        <input type="hidden" id="HasEmbeddedCSS" name="HasEmbeddedCSS">
        <input type="hidden" id="HasEmbeddedScript" name="HasEmbeddedScript">
        <input type="hidden" id="WebAddress" name="WebAddress">
        <input type="hidden" id="DistributedResourceID" name="DistributedResourceID">
        <input type="hidden" id="UsageInReadingsCount" name="UsageInReadingsCount" value="<?php echo $UsageInReadingsCount; ?>">

        <ul>
            <li><a href="#firstStepData">Create Resources</a></li>
            <li><a href="#FirstPhaseResultTR">Fill out Resources</a></li>
            <li><a href="#CreatePages">Create Pages</a></li>
        </ul>
        <!--START OF FIRST TAB, ie Uploading ALL necessary data-->
        <div class="table" id="firstStepData">
            <div id="MandatoryDiv" class="table">
                <div class="tr">
                    <div class="tdTitle">Content Name:</div>
                    <div class="tdInput">
                        <input type="text" name="ContentName" id="ContentName"  size="20" value="">
                    </div>
                </div>
                <div class="tr">
                    <div class="tdTitle">L1:</div>
                    <div class="tdInput">
                        <?php echo $drp_L1; ?>
                    </div>
                </div>
                <div class="tr">
                    <div class="tdTitle">L2:</div>
                    <div class="tdInput">
                        <?php echo $drp_L2; ?>
                    </div>
                </div>
            </div>
            <div id="AutomaticTagger" class="table">
                <div class="tr" id="TreeTaggerStatusTR" style="display: none">
                    <div class="tdTitle"></div>
                    <div class="tdInput">
                        <input type="checkbox" id="TreeTaggerStatus" name="TreeTaggerStatus" value="YES">
                        <label for="TreeTaggerStatus">Use Tree Tagger</label>
                    </div>
                </div>
                <div class="tr" id="TreeTaggerResultTR" style="display: none">
                    <div class="tdTitle">Tagged file:</div>
                    <div class="tdInput">
                        <a target="_blank" href="" id="TreeTaggerResultDL">
                            <img src="../img/download-icon.png" title="Click here to download tagged file." >
                        </a>
                    </div>
                </div>
                <div class="tr" id="RawTextTR" style="display: none">
                    <div class="tdTitle">Raw Text:</div>
                    <div class="tdInput">
                        <input type="file" name="RawText" id="RawText" />
                        <label for="RawText" class="uploadButt">upload</label> &nbsp;&nbsp;&nbsp;&nbsp;
                        <span  class="FileUploadMsg" id="rawFileName" style="display: none"></span>
                        <?php if(!empty($contentObj->RawTextFileName)){
                            $href = "../top.php?download=rawFile&fileDir=" . $contentObj->DirName . "/corpus&fileName=" . $contentObj->RawTextFileName ;
                            echo '<a target="_blank" href=' . $href . ' id="TreeTaggerPRV">
                                        <img src="../img/download-icon.png" title="Click here to download raw text file." >
                                  </a>';
                            }
                        ?>
                    </div>
                </div>
            </div>
            <div id="ComplementaryDiv" class="table">
                <div id="ComplementaryDiv_Sec1" class="table">
                    <div class="tr">
                        <div class="tdTitle">Language Resource Type:</div>
                        <div class="tdInput">
                            <input type="radio" id="LangRepType_pub" name="LangRepType"  value="Public" >Public
                            <input type="radio"  id="LangRepType_prv" name="LangRepType"  value="Private" >Private &nbsp;
                        </div>
                    </div>
                    <div class="tr">
                        <div class="tdTitle">Word Audio:</div>
                        <div class="tdInput">
                            <?php echo $drp_Word; ?>
                        </div>
                    </div>
                    <div class="tr">
                        <div class="tdTitle">Segment Audio:</div>
                        <div class="tdInput">
                            <?php echo $drp_Segment; ?>
                        </div>
                    </div>
                    <div class="tr">
                        <div class="tdTitle">L1 is Right to Left:</div>
                        <div class="tdInput">
                            <input type="radio" id="L1rtl_Y" name="L1rtl"  value="YES" >Yes
                            <input type="radio"  id="L1rtl_N" name="L1rtl"  value="NO" >No &nbsp;
                         </div>
                    </div>
                    <div class="tr">
                        <div class="tdTitle">Audio MouseOver:</div>
                        <div class="tdInput">
                            <input type="radio" id="AudioMouseOver_Y" name="AudioMouseOver"  value="YES" >Yes
                            <input type="radio"  id="AudioMouseOver_N" name="AudioMouseOver"  value="NO" >No &nbsp;
                        </div>
                    </div>
                    <div class="tr">
                        <div class="tdTitle">Word Translation MouseOver:</div>
                        <div class="tdInput">
                            <input type="radio"  id="WordTranslationMouseOver_Y" name="WordTranslationMouseOver"  value="YES" >Yes
                            <input type="radio" id="WordTranslationMouseOver_N" name="WordTranslationMouseOver"  value="NO" >No &nbsp;
                        </div>
                    </div>
                    <div class="tr">
                        <div class="tdTitle">Segment Translation MouseOver:</div>
                        <div class="tdInput">
                            <input type="radio" id="SegmentTranslationMouseOver_Y" name="SegmentTranslationMouseOver"  value="YES" >Yes
                            <input type="radio" id="SegmentTranslationMouseOver_N" name="SegmentTranslationMouseOver"  value="NO" >No &nbsp;
                        </div>
                    </div>
                </div>
                <div id="ComplementaryDiv_Sec2" class="table">
                    <div class="tr">
                        <div class="tdCollapsible" id ="OptionalComplementary">
                            <h3>More Config Options</h3>
                            <div class="tableCollapsible">
                                <div class="tr">
                                    <div class="tdTitle">Table of Contents:</div>
                                    <div class="tdInput">
                                        <input type="radio" id="TableOfContents_Y" name="TableOfContents"  value="YES" >Yes
                                        <input type="radio" id="TableOfContents_N" name="TableOfContents"  value="NO" >No &nbsp;
                                    </div>
                                </div>
                                <div class="tr">
                                    <div class="tdTitle">Keep Comments:</div>
                                    <div class="tdInput">
                                        <input type="radio" id="KeepComments_Y" name="KeepComments"  value="YES" >Yes
                                        <input type="radio" id="KeepComments_N" name="KeepComments"  value="NO" >No &nbsp;
                                    </div>
                                </div>
                                <div class="tr">
                                    <div class="tdTitle">Comments by Default:</div>
                                    <div class="tdInput">
                                        <input type="radio" id="CommentsByDefault_Y" name="CommentsByDefault"  value="YES" >Yes
                                        <input type="radio" id="CommentsByDefault_N" name="CommentsByDefault"  value="NO" >No &nbsp;
                                    </div>
                                </div>
                                <div class="tr">
                                    <div class="tdTitle">Linguistics Article Comments:</div>
                                    <div class="tdInput">
                                        <input type="radio" id="LinguisticsArticleComments_Y" name="LinguisticsArticleComments"  value="YES" >Yes
                                        <input type="radio" id="LinguisticsArticleComments_N" name="LinguisticsArticleComments"  value="NO" >No &nbsp;
                                    </div>
                                </div>
                                <div class="tr">
                                    <div class="tdTitle">Coloured Words:</div>
                                    <div class="tdInput">
                                        <input type="radio" id="ColouredWords_Y" name="ColouredWords"  value="YES" >Yes
                                        <input type="radio" id="ColouredWords_N" name="ColouredWords"  value="NO" >No &nbsp;
                                    </div>
                                </div>
                                <div class="tr">
                                    <div class="tdTitle">Audio Words in Colour:</div>
                                    <div class="tdInput">
                                        <input type="radio" id="AudioWordsInColour_Y" name="AudioWordsInColour"  value="YES" >Yes, red
                                        <input type="radio" id="AudioWordsInColour_N" name="AudioWordsInColour"  value="NO" >No &nbsp;
                                    </div>
                                </div>
                                <div class="tr">
                                    <div class="tdTitle">Max Examples per Word Page:</div>
                                    <div class="tdInput">
                                        <input type="radio" id="MaxExamplesPerWordPage_5"  name="MaxExamplesPerWordPage"  value="5" >5
                                        <input type="radio" id="MaxExamplesPerWordPage_10" name="MaxExamplesPerWordPage"  value="10" >10 &nbsp;
                                        <input type="radio" id="MaxExamplesPerWordPage_15" name="MaxExamplesPerWordPage"  value="15" >15
                                    </div>
                                </div>
                                <div class="tr">
                                    <div class="tdTitle">Extra Page Info:</div>
                                    <div class="tdInput">
                                        <input type="radio" id="ExtraPageInfo_Y" name="ExtraPageInfo"  value="YES" >Yes
                                        <input type="radio" id="ExtraPageInfo_N" name="ExtraPageInfo"  value="NO" >No
                                    </div>
                                </div>
                                <div class="tr">
                                    <div class="tdTitle">Font:</div>
                                    <div class="tdInput">
                                        <input type="radio" id="Font_serif"      name="Font"  value="serif" >serif
                                        <input type="radio" id="Font_sans-serif" name="Font"  value="sans-serif" >sans-serif
                                        <input type="radio" id="Font_monospace"  name="Font"  value="monospace" >monospace
                                    </div>
                                </div>
                                <div class="tr">
                                    <div class="tdTitle">Frequency Lists In:</div>
                                    <div class="tdInput">
                                        <input type="radio" id="FrequencyListsInMainText_Y" name="FrequencyListsInMainText"  value="YES" >Main Text Page
                                        <input type="radio" id="FrequencyListsInMainText_N" name="FrequencyListsInMainText"  value="NO" >Word Page &nbsp;
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div id="ComplementaryDiv_Sec3" class="table">
                    <div class="tr">
                        <div class="tdTitle">Tagged Text:</div>
                        <div class="tdInput">
                            <input type="file" name="TaggedText" id="TaggedText" />
                            <label for="TaggedText" class="uploadButt">upload</label>&nbsp;&nbsp;&nbsp;&nbsp;
                            <span id="taggedFileName" class="FileUploadMsg" style="display: none"></span>
                            <?php if(!empty($contentObj->TaggedTextFileName)){
                                $href = "../top.php?download=taggedFile&fileDir=" . $contentObj->DirName . "/corpus&fileName=" . $contentObj->TaggedTextFileName ;
                                echo '<a target="_blank" href=' . $href . ' id="TaggedPRV">
                                        <img src="../img/download-icon.png" title="Click here to download uploaded tagged text file." >
                                  </a>';
                            }
                            ?>
                        </div>
                    </div>
                    <div class="tr">
                        <div class="tdTitle">
                            <input type="checkbox" id="ExternalResourceStatus" name="ExternalResourceStatus" value="YES">
                            <label for="ExternalResourceStatus">Import External Resources</label>
                        </div>
                        <div class="tdInput"></div>
                    </div>
                    <div class="tr" id="ExternalResourceTR" style="display: none">
                        <div class="tdTitle">External Resource:</div>
                        <div class="tdInput">
                            <input type="file" name="ExternalResource" id="ExternalResource" />
                            <label for="ExternalResource" class="uploadButt">upload</label>
                            <span  class="FileUploadMsg"  id="ExternalResFileName" style="display: none"></span>
                        </div>
                    </div>
            </div>
            </div>
            <div id="EmbeddedFilesDesc" class="table" style="display: none;width: 100%">
                <p class="CautionMsg">
                    The uploaded text contains some embedded media.
                    Please upload embedded files in zip format and click "Create Resource" to continue this step.
                </p>
            </div>
            <div id="EmbeddedFiles" class="table">
                <div class="tr" id="EmbeddedAudioTR" style="display: none;">
                    <div class="tdTitle">Embedded Audio:</div>
                    <div class="tdInput">
                        <input type="file" name="EmbeddedAudio" id="EmbeddedAudio" />
                        <label for="EmbeddedAudio" class="uploadButt">upload</label>
                           <span  class="FileUploadMsg"  id="eAudioFileName" style="display: none"></span>
                    </div>
                </div>
                <div class="tr" id="EmbeddedCssTR" style="display: none;">
                    <div class="tdTitle">Embedded CSS:</div>
                    <div class="tdInput">
                        <input type="file" name="EmbeddedCss" id="EmbeddedCss" />
                        <label for="EmbeddedCss" class="uploadButt">upload</label>
                        <span  class="FileUploadMsg"  id="eCssFileName" style="display: none"></span>
                    </div>
                </div>
                <div class="tr" id="EmbeddedImageTR" style="display: none;">
                    <div class="tdTitle">Embedded Image:</div>
                    <div class="tdInput">
                        <input type="file" name="EmbeddedImage" id="EmbeddedImage" />
                        <label for="EmbeddedImage" class="uploadButt">upload</label>
                        <span  class="FileUploadMsg"  id="eImageFileName" style="display: none"></span>
                    </div>
                </div>
                <div class="tr" id="EmbeddedScriptTR" style="display: none;">
                    <div class="tdTitle">Embedded Script:</div>
                    <div class="tdInput">
                        <input type="file" name="EmbeddedScript" id="EmbeddedScript" />
                        <label for="EmbeddedScript" class="uploadButt">upload</label>
                        <span  class="FileUploadMsg"  id="eScriptFileName" style="display: none"></span>
                    </div>
                </div>
            </div>
            <div id="SaveFirstStepInfo" class="table">
                <div class="tr">
                    <div class="tdTXT">
                        <input type="button"  id="OperationButt" name="OperationButt"
                               onclick="createResources()" >
                        <!--input type="button"  id="ForHani" name="ForHani"
                               value = "for Hani" onclick="forHani()" -->
                    </div>
                </div>
            </div>
        </div>
        <!--END OF FIRST TAB-->
        <!--****************************************************************-->
        <!--START OF SECOND TAB, ie result of first phase compile-->
        <div class="table" id="FirstPhaseResultTR" style="display: none">
            <div id="ExternalLinks" class="table">
                <div class="tr">
                    <div class="tdTitle">First Phase Result:</div>
                    <div class="tdInput">
                        <?php if(!empty($configObj) && $configObj->IsLimited == 'no')
                        {
                            echo ' <a target="_blank" href="" id="FirstPhaseResultDL">
                                    <img src="../img/download-icon.png" title="Click here to download first phase results in a zip file." >
                                    </a>';
                        }
                        else
                        {
                            echo '<span  class="FileUploadMsg">
                                       RESOURCES ARE NOT READY TO DOWNLOAD.            
                                    </span>';
                        }
                        ?>
                    </div>
                </div>
                <div class="tr">
                    <div class="tdTitle">Fill out Word Translation:</div>
                    <div class="tdInput">
                        <?php if($wordAndSegObj->wordTotal != 0)
                            {
                                echo '<img src="../img/fillout-icon.png" 
                                id="WordTrnslt" title="Click here to fill out words translation form." >';
                            }
                            else
                            {
                                echo '<span  class="FileUploadMsg">
                                        NO WORD TO TRANSLATE.            
                                        </span>';
                            }
                        ?>
                    </div>
                </div>
                <div class="tr">
                    <div class="tdTitle">Fill out Segment Translation:</div>
                    <div class="tdInput">
                        <?php if($wordAndSegObj->segTotal != 0)
                        {
                            echo '<img src="../img/fillout-icon2.png" 
                                id="SgmntTrnslt" title="Click here to fill out segment translation form." >';
                        }
                        else
                        {
                            echo '<span  class="FileUploadMsg">NO SEGMENT TO TRANSLATE.</span>';
                        }
                        ?>
                    </div>
                </div>
            </div>
            <div id="DirectUploadDesc" class="table" <?php echo (empty($configObj) || $configObj->IsLimited == 'yes') ?  'style="display: none;"':'';?>>
                <div class="tr" >
                    <div class="tdTXT" style="text-align: center">OR you can upload filled-out files here</div>
                </div>
            </div>
            <div  id="DirectUpload" class="table"
                <?php echo (empty($configObj) || $configObj->IsLimited == 'yes') ?  'style="display: none;"':'';?>>
                <div class="tr">
                    <div class="tdTitle">Upload Words Translation:</div>
                    <div class="tdInput">
                        <label for="UploadWordTrnslt">
                            <img src="../img/upload-icon.png" title="Click here to upload words translation file.">
                        </label>
                        <input id="UploadWordTrnslt" name="UploadWordTrnslt" type="file" />
                    </div>
                </div>
                <div class="tr">
                    <div class="tdTitle">Upload Segments Translation:</div>
                    <div class="tdInput">
                        <label for="UploadSgmntTrnslt">
                            <img src="../img/upload-icon.png" title="Click here to upload words segments file.">
                        </label>
                        <input id="UploadSgmntTrnslt" name="UploadSgmntTrnslt" type="file" />
                    </div>
                </div>
            </div>
        </div>
        <!--END OF SECOND TAB-->
        <!--****************************************************************-->
        <!--START OF THIRD TAB, ie checking filled information and creating pages-->
        <div class="table" id="CreatePages">
        <?php if(empty($configObj) || $configObj->IsLimited == 'yes') {?>
            <div class="tr">
                <div class="tdTXT">
                    <p class="CautionMsg">
                        NOT IN THE STEP OF CREATING PAGES YET. PLEASE CREATE AND COMPLETE THE RESOURCES.
                    </p>
                </div>
            </div>
        <?php } else { ?>
            <div class="tr">
                <div class="tdTXT">
                    Here is some information:
                    You have uploaded <?php echo $contentObj->TaggedTextFileName; ?> as the main resource. <br/>
                    This file has <?php echo $wordAndSegObj->wordTotal; ?> words, <?php echo $wordAndSegObj->wordTranslated; ?> translated.<br/>
                    This file has <?php echo $wordAndSegObj->segTotal; ?> segments, <?php echo $wordAndSegObj->segTranslated; ?> translated.<br/>
                </div>
            </div>
            <div class="tr">
                <div class="tdTXT">
                    <input type="checkbox" id="ReadyToCompile" name="ReadyToCompile" value="YES">
                    <label for="ReadyToCompile">Create pages with the above filled resources.</label>
                </div>
            </div>
            <div class="tr">
                <div class="tdTXT">
                    <input type="button" id="PageCreationButt" name="PageCreationButt"
                           value="Create Pages" onclick="createPages()" >
                </div>
            </div>
            <div class="tr" id="WebAddressTR" style="display: none;">
                <div>
                    <div class="tdTXT">
                        Click <a class="CautionMsg" target="_blank" href=<?php echo $contentObj->WebAddress;?>>
                            here </a> to open the created web page. To work offline, click
                        <a target="_blank" href="" id="CompiledFolderDL"> here </a> to download the compiled content.
                    </div>
                </div>
                <div>
                    <?php if($UsageInReadingsCount == 0){ ?>
                        <div class="tdTXT">
                            You also can publish this content as a resource now :
                            <input type="button" id="PublishRsrc" name="PublishRsrc"
                                   value="Publish Resource" onclick="publishResource()" >
                        </div>
                    <?php } else { ?>
                        <div class="tdTXT">
                            Congratulation! Your resource has used used in <?php echo $UsageInReadingsCount; ?> Reading Histories.<br/>
                            Current choices : <?php echo $PublishOptions; ?>
                            <input type="button" id="PublishRsrc" name="PublishRsrc"
                                   value="Publish Resource" onclick="publishResource()" >
                        </div>
                    <?php } ?>
                </div>
            </div>
        <?php }?>
        </div>
        <!--END OF THIRD TAB-->
        <!--****************************************************************-->
    </form>
    </div>
</div>