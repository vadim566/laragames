<?php
/**
 * Created by PhpStorm.
 * User: habibih
 * Date: 8/21/2019
 */

?>

<link rel="stylesheet" href="../css/MainContent.css">
<link rel="stylesheet" href="../css/TableToDiv.css">
<link rel="stylesheet" href="../css/jquery-ui.css">
<meta charset="utf-8">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

<?php
    $now = new DateTime();
    echo '<script src="../js/ReadingHistory.js?' . $now->format('His') . '"></script>';
    echo '<script src="../js/ShowLoading.js?' . $now->format('His') . '"></script>';
    echo '<script src="../js/jquery-1.12.4.js?' . $now->format('His') . '"></script>';
    echo '<script src="../js/jquery-ui.js?' . $now->format('His') . '"></script>';

require_once "../top.php";
require_once "../class/Language.class.php";
require_once "../class/User.class.php";
require_once "../class/ReadingHistory.class.php";
require_once "../class/DistributedResource.class.php";
require_once "../data/ReadingHistory.data.php";

if(!isset($_SESSION["UserID"]))
{
    echo "Please Login again. <br />";
    echo "<a href='index.php?status=sessionExpired'>Click Here to Login</a>";
    die();
}

$drp_L1 = Language::LanguageDropBox("L1ID", true);
$drp_L2 = DistributedResource::LanguagesOfResources("L2ID", true);
$R_H_Obj = array();

if(isset($_GET["Q0"]))
{
    $where = " ReadingHistoryID = :readingHistoryID";
    $whereParam = array(":readingHistoryID" => $_GET["Q0"]);
    $info = ReadingHistory::SearchReadingHistory($where, $whereParam);
	if(count($info) != 0)
	{
        $R_H_Obj = FillItems($info[0]);
    }
    $drp_ContentResources = DistributedResource::ContentResourceDropBox("ResourceID", $R_H_Obj->L2ID);
}
else
{
    $R_H_Obj = MakeEmptyHistory();

    $drp_ContentResources = "<select name='ResourceID' id='ResourceID'>";
    $drp_ContentResources .= "<option value=-1  selected>---</option>";
    $drp_ContentResources .= "</select>";
}

$jsObjName = "R_H_Val";
echo objToJS($R_H_Obj, $jsObjName);

$activeTab = 0;
if(isset($_GET["activeTab"]))
{
    $activeTab = $_GET["activeTab"];
}

$MsgToShow = "notSetYet";
$PythonFailureReturnMsgs = array("RecompileSucceed", "RecompileFailure", "FailedToAddNewPage");

if(isset($_GET["activeTab"]))
{
    $MsgToShow = $_GET["msg"];
}


echo '<script>onLoad(' . $activeTab . ',"'. $MsgToShow .'");</script>';
?>

<div class="newReadingHistory">

    <div class="table readingHistoryError"  style="display: none">
        <div class="tr">
            <div class="tdInput">
                <p class="ErrorMsg"></p>
            </div>
            <div class="tdTitle">
                <img src='../img/ok-icon.png' title='hide it'
                     onclick='$(".readingHistoryError").css("display", "none");' >
                <?php
                if(in_array($MsgToShow, $PythonFailureReturnMsgs)){
                    echo "<img src='../img/detail-icon.png' title='show detail' onclick='showPythonOutput();' >";
                }
                ?>
            </div>
        </div>
    </div>

    <div id="tabs">

    <form method="POST" id="readingHistoryForm" enctype='multipart/form-data'>
        <input type="hidden" id="task" name="task" value="AddReadingHistory">
        <input type="hidden" id="ReadingHistoryID" name="ReadingHistoryID">
        <input type="hidden" id="DirName" name="DirName">
        <input type="hidden" id="UserID" name="UserID">

        <ul>
            <li><a href="#createHistory">Create Reading History</a></li>
            <li><a href="#addResource">Add Resource</a></li>
        </ul>
        <!--START OF FIRST TAB, ie Uploading ALL necessary data-->
        <div class="table" id="createHistory">
            <div id="MandatoryDiv" class="table">
                <div class="tr">
                    <div class="tdTitle">Reading History Name:</div>
                    <div class="tdInput">
                        <input type="text" name="ReadingHistoryName" id="ReadingHistoryName"  size="20" value="">
                    </div>
                </div>
                <div class="tr">
                    <div class="tdTitle">L1:</div>
                    <div class="tdInput">
                        <?php echo $drp_L1; ?>
                    </div>
                </div>
                <div class="tr">
                    <div class="tdTitle">L2:</div>
                    <div class="tdInput">
                        <?php echo $drp_L2; ?>
                    </div>
                </div>
            </div>
            <div id="ComplementaryDiv" class="table">
                <div class="tr">
                    <div class="tdTitle">Preferred Voice:</div>
                    <div class="tdInput">
                        <input type="text" name="PreferredVoice" id="PreferredVoice"  size="20" value="">
                    </div>
                </div>
                <div class="tr">
                    <div class="tdTitle">Audio MouseOver:</div>
                    <div class="tdInput">
                        <input type="radio" id="AudioMouseOver_Y" name="AudioMouseOver"  value="YES" >Yes
                        <input type="radio"  id="AudioMouseOver_N" name="AudioMouseOver"  value="NO" >No &nbsp;
                    </div>
                </div>
                <div class="tr">
                    <div class="tdTitle">Word Translation MouseOver:</div>
                    <div class="tdInput">
                        <input type="radio"  id="WordTranslationMouseOver_Y" name="WordTranslationMouseOver"  value="YES" >Yes
                        <input type="radio" id="WordTranslationMouseOver_N" name="WordTranslationMouseOver"  value="NO" >No &nbsp;
                    </div>
                </div>
                <div class="tr">
                    <div class="tdTitle">Segment Translation MouseOver:</div>
                    <div class="tdInput">
                        <input type="radio" id="SegmentTranslationMouseOver_Y" name="SegmentTranslationMouseOver"  value="YES" >Yes
                        <input type="radio" id="SegmentTranslationMouseOver_N" name="SegmentTranslationMouseOver"  value="NO" >No &nbsp;
                    </div>
                </div>
            </div>
            <div id="SaveFirstStepInfo" class="table">
                <div class="tr">
                    <div class="tdTXT">
                        <input type="button"  id="OperationButt" name="OperationButt"
                               value="Save" onclick="addReadingHistory()" >
                    </div>
                </div>
            </div>
        </div>
        <!--END OF FIRST TAB-->
        <!--****************************************************************-->
        <!--START OF SECOND TAB, ie result of first phase compile-->
        <div class="table" id="addResource" style="display: none">
            <div id="MandatoryDiv" class="table">
                <div class="tr">
                    <div class="tdTitle">Resource Name:</div>
                    <div class="tdInput">
                        <?php echo $drp_ContentResources; ?>
                    </div>
                </div>
            </div>
            <div class="table">
                <div class="tr">
                    <div class="tdTXT">
                        <input type="button"  id="AddHistoryRes" name="AddHistoryRes"
                               value="add" onclick="addHistoryResource()" >
                    </div>
                </div>
            </div>
        </div>
        <!--END OF SECOND TAB-->
        <!--****************************************************************-->
    </form>
    </div>
</div>