<?php
/**
 * Created by PhpStorm.
 * User: habibih
 * Date: 8/10/2019
 * Time: 08:08 PM
 */
?>


<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.19/css/jquery.dataTables.css">
 <script>
        $('.ShowResource').click(function() {
            event.preventDefault();
            $("#mainContentDIV").load(this.getAttribute('href'));
        });
</script>


<?php

$now = new DateTime();
echo '<script type="text/javascript" charset="utf8" src="../js/DistributedResource.js?' . $now->format('His') . '"></script>';
echo '<script type="text/javascript" charset="utf8" src="../js/ShowLoading.js?' . $now->format('His') . '"></script>';
echo '<script type="text/javascript" charset="utf8" src="../js/jquery.dataTables.js?' . $now->format('His') . '"></script>';
echo '<link rel="stylesheet" href="../css/MainContent.css?' . $now->format('His') . '">';

require_once "../top.php";
require_once "../class/DistributedResource.class.php";

if(!isset($_SESSION["UserID"]))
{
    echo "Please Login again. <br />";
    echo "<a href='index.php?status=sessionExpired'>Click Here to Login</a>";
    die();
}

$where = " IsDeleted = 'NO'";
$info = DistributedResource::FullSelect($where);
?>



<div class="LaraContents">
    <table id="TableOfDistributed" class="display" style="width:100%">
        <thead>
        <tr>
            <th>Resource Name</th>
            <th>Resource Type</th>
            <th>Creator</th>
            <th>L2</th>
            <th>Download</th>
            <th>Edit</th>
            <th>Delete</th>
        </tr>
        </thead>
        <tbody>
        <?php
            for($i = 0; $i < count($info); $i++)
            {
                $trString = "<tr>";
                $trString .= "<td style='text-align: center'>" . $info[$i]["ResourceName"] . "</td>";
                $trString .= "<td style='text-align: center'>" . $info[$i]["ResourceType"] . "</td>";
                $trString .= "<td style='text-align: center'>" . $info[$i]["UserName"] . "</td>";
                $trString .= "<td style='text-align: center'>" . $info[$i]["LanguageName"] . "</td>";

                if(strpos($info[$i]["WebAddress"], WebRoot) !== -1)
                {
                    $trString .= "<td style='text-align: center'>";
                    $ZipFolderName = $info[$i]["ResourceName"] . "_TotalPackage.zip";
                    $FolderDir =  str_replace(WebRoot, '', $info[$i]["WebAddress"]);
                    $cmp = "&folderDir=" . $FolderDir . "&zipFolderName=" . $ZipFolderName ;
                    $trString .= "<a target='_blank' id='FinalPackDL'
                                href='../top.php?download=finalResourcePack" . $cmp . "'>
                                <img src='../img/download-icon.png' title='Click here to download'>
                                </a></td>";
                }
                else
                {
                    $trString .= "<td style='text-align: center'>
                                    <img src='../img/forbidden-icon.png' title='Unable To Download' >
                                  </td>";

                }
                if($info[$i]["UserID"] == $_SESSION["UserID"])
                {
                    $trString .= "<td style='text-align: center'>
                                    <a target='_blank' class='ShowResource'
                                        href='NewDistributedResource.php?Q0=" . $info[$i]["ResourceID"] . "'>
                                        <img src='../img/edit-icon.png' title='edit history' >
                                    </a>
                                </td>";
                    //delete is here
                    $trString .= "<td style='text-align: center'>
                               <img src='../img/delete.gif' title='delete from history' 
                                 onclick='deleteResource(\"" . $info[$i]["ResourceID"] . "\",\"" . $info[$i]["ResourceName"] ."\");' >

                            </td>";
                }
                else
                {
                    $trString .= "<td style='text-align: center'>
                                    <img src='../img/forbidden-icon.png' title='edit forbidden' >
                                  </td>";
                    $trString .= "<td style='text-align: center'>
                                    <img src='../img/forbidden-icon.png' title='delete forbidden'>
                                  </td>";
                }

                $trString .= "</tr>";
                echo $trString;
            }
        ?>
        </tbody>
    </table>

<script>
    onLoadDistributedList();
</script>
    <table style="width: 90%; font-weight: bold; font-size: 20px">
        <tr>
            <td ><a target='_blank' id='allResources' href='../top.php?download=allResources'>
                Click here to download allResources.json file. </a></td>
            </td>
        </tr>
    </table>
   </div>

