<?php
/**
 * Created by PhpStorm.
 * User: habibih
 * Date: 6/6/2019

 */

?>


<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

<?php
    $now = new DateTime();
    echo '<link rel="stylesheet" href="../css/MainContent.css?' . $now->format('His') . '">';
    echo '<script src="../js/DataTranslation.js?' . $now->format('His') . '"></script>';
    echo '<script src="../js/ShowLoading.js?' . $now->format('His') . '"></script>';

?>

<?php
require_once "../class/ContentWord.class.php";
require_once "../class/ContentTranslationSegment.class.php";
require_once "../top.php";

//what I have to send : type, to determine word or segment, and contentID to show data

$trCount = 0;
$l1Index = "InL1";
$l2Index = "InL2";

if(!isset($_GET["type"]) || !isset($_GET["contentID"]))
{
        echo '<script>showMessage("Not Valid Information!",-1, 300000);</script>';
}
else
{
    $type = $_GET["type"];
    $contentID = $_GET["contentID"];
    $where = " ContentID = :cntntID";
    $whereParam = array(":cntntID" => $contentID);

    if ($type == 'word') {
        $info = ContentWord::SearchContentWord($where, $whereParam);
        $idIndex = "ContentWordID";
        $l1Index = "WordInL1";
        $l2Index = "WordInL2";
    }
    elseif ($type == 'segment') {
        $info = ContentTranslationSegment::SearchContentSegment($where, $whereParam);
        $idIndex = "ContentSegmentID";
        $l1Index = "SegmentInL1";
        $l2Index = "SegmentInL2";
    }

    $trCount = count($info);
}

?>



<div class="dataTranslation">
    <form method="POST" id="dataTranslationForm" enctype='multipart/form-data'>
        <input type="hidden" id="ContentID" name="ContentID" value="<?php echo $_GET["contentID"] ?>">
        <input type="hidden" id="ValueType" name="ValueType" value="<?php echo $_GET["type"] ?>">
        <input type="hidden" id="SendMode" name="SendMode">
        <table width="700">
            <tr style="width: 100%">
                <td>
                    <table class="responstable" style="width: 100%">
                        <tr>
                            <th><?php echo $l1Index;?></th>
                            <th><?php echo $l2Index;?></th>
                        </tr>
                        <!-- A FOR LOOP TO CREATE FORM TR-->
                        <?php
                            for($i = 0; $i < $trCount; $i++)
                            {
                                $thisRow = $info[$i];
                                $id = $thisRow[$idIndex];
                                $valueInL1 = $thisRow[$l1Index];
                                $valueInL2 = $thisRow[$l2Index];

                                $rowString  = "<tr>";
                                $rowString .= "<td>" . $valueInL1 . "</td>";
                                $rowString .= "<td>
                                                    <input type='text' name='L2Inpit_" . $id . "' id='L2Inpit_" . $id . "' 
                                                    value='". htmlspecialchars($valueInL2, ENT_QUOTES) ."'>
                                                </td>";
                                $rowString .= "</tr>";
                                echo $rowString;
                            }
                        ?>
                        </table>
                    </td>
                </tr>
                <!--tr>
                    <td>
                        <input type="checkbox" id="IsFinished" name="IsFinished" value="YES">
                        <label for="IsFinished">Finished adding resources for now.</label>
                    </td>
                </tr-->
                <tr id="translationError"  style="display: none">
                    <td>
                        <p class="ErrorMsg"></p>
                    </td>
                </tr>
                <tr>
                    <td align="center">
                        <input type="button"  id="SendButton" name="SendButton"
                               value="Save Translations" onclick="sendTranslation('JustSave')">
                        <input type="button"  id="SendAndCopyButton" name="SendAndCopyButton"
                               value="Save and Use" onclick="sendTranslation('SaveAndCopy')">
                        <input type="button"  id="ReturnButton" name="ReturnButton"
                               value="Return To Content" onclick="returnToContent()">
                    </td>
                </tr>
            </table>
    </form>
</div>

