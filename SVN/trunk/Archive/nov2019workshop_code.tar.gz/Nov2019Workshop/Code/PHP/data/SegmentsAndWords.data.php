<?php
/**
 * Created by PhpStorm.
 * User: habibih
 * Date: 6/6/2019
 * Time: 05:45 PM
 */


require_once '../Config.php';
require_once '../class/Content.class.php';
require_once '../data/Content.data.php';
require_once '../class/ParolPair.class.php';
require_once '../class/ContentParol.class.php';
require_once '../class/ContentRecordingMetadata.class.php';
require_once '../class/ContentRecordingSegment.class.php';
require_once '../class/Language.class.php';
require_once '../class/LanguagePair.class.php';
require_once '../class/ContentConfig.class.php';
require_once '../SharedModules/PHPExcel/Classes/PHPExcel.php';
require_once '../SharedModules/ExtraModules.class.php';

$task = isset($_REQUEST["task"]) ? $_REQUEST["task"] :  "";

switch ($task)
{
    case "saveData":
        saveData();

    case "UploadWordTrnslt":
        UploadSubcontentTranslation("word");

    case "UploadSgmntTrnslt":
        UploadSubcontentTranslation("segment");
}

function saveData()
{
    $resultArray = array();
    $resultArray[0]["resultMsg"] = "notSetYet";
    $resultArray[0]["id"] = $_REQUEST["ContentID"];
    $resultArray[0]["type"] = $_REQUEST["ValueType"];

    $where = "ContentID = :contentID";
    $whereParam = array(":contentID" => $_REQUEST["ContentID"]);
    $contentResult = Content::SearchContent($where, $whereParam);
    $contentID = $contentResult[0]["ContentID"];
    $dirName = LaraContentDir . $contentResult[0]["DirName"] ;
    $L1Name =  Language::getLanguageName($contentResult[0]["L1ID"]);
    $L2Name =  Language::getLanguageName($contentResult[0]["L2ID"]);
    $LanguagePairID = LanguagePair::getLanguagePairID($contentResult[0]["L1ID"], $contentResult[0]["L2ID"]);
    $outputFileName = $L2Name . "_" . $L1Name . ".csv";

    $array_keys = array_keys($_REQUEST);
    foreach ($array_keys as $value)
    {
        if (strpos($value, 'L1Input_') === 0)
        {
            $IndexParts = explode('_', $value);
            $obj = new ParolPair();
            $obj->ParolPairID = $IndexParts[1];
            $obj->ParolType = $_REQUEST["ValueType"];
            $obj->ParolInL1 = $_REQUEST[$value];
            $obj->update();
        }
    }

    if ($_REQUEST["ValueType"] == "word")
    {
        $wordDbToXsl = FromDatabaseToExcel($contentID, $dirName,  "word", $LanguagePairID);
        $totalDbToXsl = FromDatabaseToExcel($contentID, $dirName,  "wordTotal", $LanguagePairID);
        $srcFile =  $dirName . "/" . SubDirNames["corpus"] . "/" . 'total_word_translation.csv';
        $destFolder = LaraContentDir . $L2Name . "/" . SubDirNames["translations"] . "/";
        $destFile = $destFolder . $outputFileName;
        $dbToXsl = $wordDbToXsl && $totalDbToXsl;

    } elseif ($_REQUEST["ValueType"] == "segment")
    {
        $dbToXsl = FromDatabaseToExcel($contentID, $dirName,  "segment", $LanguagePairID);
        $srcFile = $dirName . "/" . SubDirNames["corpus"] . "/" . 'segment_translation.csv';
        $destFolder = $dirName . "/" . SubDirNames["translations"] . "/";
        $destFile = $destFolder . $outputFileName;
    }

    if($dbToXsl)
    {
        if(isset($_REQUEST["SendMode"]) && $_REQUEST["SendMode"] == "SaveAndExit")
        {
            if (!file_exists($destFolder) && !is_dir($destFolder))
            {
                if(! mkdir($destFolder, 0777, true))
                {
                    return "CreateDIRFailed";
                }
            }

            if(!copy($srcFile,$destFile))
            {
                $resultArray[0]["resultMsg"] = "FinalCopyFailed";
            }
            else
            {
                $resultArray[0]["resultMsg"] = "DataIsSavedAndCopiedForItems";
            }
        }
        else
        {
            $resultArray[0]["resultMsg"] = "DataIsSavedForItems";
        }
    }
    else
    {
        $resultArray[0]["resultMsg"] = "DataIsNOTSavedForItems";
    }
    ExtraModules::UserActivityLog(ContentRelatedPage, $resultArray);
    ExtraModules::KillProcess($resultArray);
}

function FromExcelToDatabase($excelFile, $corpusDir, $contentID)
{
    if($excelFile == 'words')
    {
        $inputFileName = $corpusDir . 'word_translation.csv';
        $ParolType = "word";
    }
    elseif ($excelFile == "segments")
    {
        $inputFileName = $corpusDir . 'segment_translation.csv';
        $ParolType = "segment";
    }

    ContentParol::delete($contentID, $ParolType);

    $where = " ContentID = :contentID";
    $whereParam = array(":contentID" => $contentID);
    $info = Content::SearchContent($where, $whereParam);
    $contentObj = FillItems($info[0]);

    $lpObj= new LanguagePair();
    $lpObj->L1ID = $contentObj->L1ID;;
    $lpObj->L2ID = $contentObj->L2ID;;

    if($lpObj->LanguagePairExists() == false)
    {
        $lpObj->insert();
        $lpObj->LanguagePairID = LanguagePair::lastID();
    }

    $inputFileType = 'CSV';
    $objReader = PHPExcel_IOFactory::createReader($inputFileType)->setDelimiter("\t");;
    $objPHPExcel = $objReader->load($inputFileName);
    $worksheet = $objPHPExcel->getActiveSheet();
    $maxRow = $worksheet->getHighestRow();

    for($row=2; $row<=$maxRow ; $row++)
    {
        $ppObj= new ParolPair();
        $ppObj->LanguagePairID = $lpObj->LanguagePairID;
        $ppObj->ParolInL2 = $worksheet->getCellByColumnAndRow(0, $row)->getValue();
        $ppObj->ParolInL1 = $worksheet->getCellByColumnAndRow(1, $row)->getValue();
        $ppObj->ParolType = $ParolType;

        if($ppObj->ParolPairExists() == false)
        {
            $ppObj->insert();
            $ppObj->ParolPairID = ParolPair::lastID();
        }
        else
        {
            $ppObj->update();
        }
        $cpObj = new ContentParol();
        $cpObj->ContentID = $contentID;
        $cpObj->ParolPairID = $ppObj->ParolPairID;
        $cpObj->insert();
    }
    return true;
}

function FromDatabaseToExcel($contentID, $dirName, $type, $LanguagePairID)
{
    if($type == 'wordTotal')
    {
        $where = "LanguagePairID = :languagePairID and ParolType = 'word'";
        $whereParam = array(":languagePairID" => $LanguagePairID);
        $subContentResult = ContentParol::SearchLanguagePairWord($where, $whereParam);
        $outputFileName = 'total_word_translation.csv';
        $A1Title = "Head word";
    }
    elseif($type == 'word')
    {
        $where = "ContentID = :contentID and pp.ParolType = 'word'";
        $whereParam = array(":contentID" => $contentID);
        $subContentResult = ContentParol::SearchContentParol($where, $whereParam);
        $outputFileName = 'word_translation.csv';
        $A1Title = "Head word";
    }
    elseif ($type == "segment")
    {
        $where = "ContentID = :contentID and pp.ParolType = 'segment'";
        $whereParam = array(":contentID" => $contentID);
        $subContentResult = ContentParol::SearchContentParol($where, $whereParam);
        $outputFileName = 'segment_translation.csv';
        $A1Title = "Segment";
    }

    $objPHPExcel = new PHPExcel();
    $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'CSV')->setDelimiter("\t");;
    $row = 1;
    $objPHPExcel->getActiveSheet()->setCellValue('A'.$row, $A1Title);
    $objPHPExcel->getActiveSheet()->setCellValue('B'.$row, 'Translation');

    for($i=0; $i < count($subContentResult) ; $i++)
    {
        $row = $i + 2;
        $objPHPExcel->getActiveSheet()->setCellValue('A'.$row, $subContentResult[$i]["ParolInL2"]);
        $objPHPExcel->getActiveSheet()->setCellValue('B'.$row, $subContentResult[$i]["ParolInL1"]);
    }
    $objWriter->save($dirName . "/" . SubDirNames["corpus"] . "/" . $outputFileName);
    $excelOutput = str_replace("\"", "", file_get_contents($dirName . "/" . SubDirNames["corpus"] . "/" . $outputFileName));
    file_put_contents($dirName . "/" . SubDirNames["corpus"] . "/" . $outputFileName, $excelOutput);

    return true;
}

function UploadSubcontentTranslation($type)
{
    $resultArray = array();
    $resultArray[0]["resultMsg"] = "notSetYet";
    $resultArray[0]["id"] = $_REQUEST["ContentID"];

    if($type == "word")
    {
        $FileNameParts = explode('.', $_FILES['UploadWordTrnslt']['name']);
        $file = $_FILES['UploadWordTrnslt'];
        $fileName = "word_translation.csv";
    }
    elseif ($type == "segment")
    {
        $FileNameParts = explode('.', $_FILES['UploadSgmntTrnslt']['name']);
        $file = $_FILES['UploadSgmntTrnslt'];
        $fileName = "segment_translation.csv";
    }

    $FileExt = $FileNameParts[count($FileNameParts) - 1];
    $FileExt = strtolower($FileExt);
    if ($FileExt != "csv") {
        $resultArray[0]["resultMsg"] = "fileTypeError";
        ExtraModules::UserActivityLog(ContentRelatedPage, $resultArray);
        //$resultArray[0]["id"] = -1;
        ExtraModules::KillProcess($resultArray);
    }

    $where = "ContentID = :contentID";
    $whereParam = array(":contentID" => $_REQUEST["ContentID"]);
    $contentResult = Content::SearchContent($where, $whereParam);
    $contentID = $contentResult[0]["ContentID"];
    $L1Name =  Language::getLanguageName($contentResult[0]["L1ID"]);
    $L2Name =  Language::getLanguageName($contentResult[0]["L2ID"]);
    $outputFileName = $L2Name . "_" . $L1Name . ".csv";
    $dirName = LaraContentDir . $contentResult[0]["DirName"] ;

    $fileDir = LaraContentDir . $contentResult[0]["DirName"] . "/" . SubDirNames["corpus"] . "/";
    if($type == "word")
    {
        $srcFile =  $fileDir . 'total_word_translation.csv';
        $destFolder = LaraContentDir . $L2Name . "/" . SubDirNames["translations"] . "/";
        $destFile = $destFolder . $outputFileName;
        $excelFile = "words";
    }
    elseif ($type == "segment")
    {
        $srcFile = $fileDir . 'segment_translation.csv';
        $destFolder = LaraContentDir . $contentResult[0]["DirName"] . "/" . SubDirNames["translations"] . "/";
        $destFile = $destFolder . $outputFileName;
        $excelFile = "segments";
    }
    if(UploadExcelFile($fileName, $fileDir, $file))
    {
        if(FromExcelToDatabase($excelFile, $fileDir, $_REQUEST["ContentID"])) {
            if ($type == "word")
            {
                $LanguagePairID = LanguagePair::getLanguagePairID($contentResult[0]["L1ID"], $contentResult[0]["L2ID"]);
                FromDatabaseToExcel($contentID, $dirName,  "wordTotal", $LanguagePairID);
            }
            if (!file_exists( $destFolder ) && !is_dir($destFolder))
            {
                if(! mkdir($destFolder, 0777, true))
                {
                    return "CreateDIRFailed";
                }
            }
            if(!copy($srcFile,$destFile))
            {
                $resultArray[0]["resultMsg"] = "FinalCopyFailed";
            }
            else
            {
                $resultArray[0]["resultMsg"] = "UploadedAndCopied";
            }
        }
        else
        {
            $resultArray[0]["resultMsg"] = "TransferToDbFailed";
        }
    }
    else
    {
        $resultArray[0]["resultMsg"] = "UploadFileFailed";
    }
    ExtraModules::UserActivityLog(ContentRelatedPage, $resultArray);
    ExtraModules::KillProcess($resultArray);
}

function UploadExcelFile($fileName, $fileDir, $file)
{
    $fp = fopen($fileDir . $fileName, "w");
    fwrite($fp, fread(fopen($file ['tmp_name'], 'r'), $file['size']));
    fclose($fp);
    return true;
}

function FromMetadataToDatabase($contentID, $type)
{
    $where = " ContentID = :contentID";
    $whereParam = array(":contentID" => $contentID);

    //ConfigInfo
    $configObjInfo = ContentConfig::SearchContentConfig($where, $whereParam);
    if ($configObjInfo != false) {
        require_once 'Content.data.php';
        $configObj = FillConfigItems($configObjInfo);

        $mdObj = new ContentRecordingMetadata();
        $mdObj->ContentID = $contentID;
        $mdObj->RecordingType = $type;

        if ($type == "segment")
        {
            $obj = new ContentRecordingSegment();
            $mdObj->MetadataFileDirectory = $configObj->segment_audio_directory . "/metadata_help.txt";
        }
        else if ($type == "word")
        {
            //todo $obj = new ??????();
            $mdObj->MetadataFileDirectory = $configObj->word_audio_directory . "/metadata_help.txt";
        }

        if($mdObj->IsRegistered() == false)
        {
            $mdObj->insert();
            $mdObj->RecordingMetadataID = ContentRecordingMetadata::lastID();
        }

        $obj->RecordingMetadataID = $mdObj->RecordingMetadataID;

        $fileContent = file_get_contents($mdObj->MetadataFileDirectory);

        $fileContent = str_replace("AudioOutput help any_speaker help/", "<" , $fileContent);
        $fileContent = str_replace("# |", ">" , $fileContent);

        preg_match_all('/<(.*?)>/', $fileContent, $match);

        for($i = 0; $i < count($match[1]); $i++)
        {
            $matchParts= explode(".mp3 ",$match[1][$i]);
            $obj->AudioFileName = $matchParts[0] . ".mp3";
            $obj->SegmentText = $matchParts[1];

            if($obj->IsRegistered() == false)
                $obj->insert();
            else
                $obj->update();
        }
        return true;
    }
    else
    {
        return false;
    }
}
