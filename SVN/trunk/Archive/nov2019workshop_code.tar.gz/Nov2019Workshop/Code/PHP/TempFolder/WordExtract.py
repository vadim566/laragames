import os
import sys
from nltk.tokenize import sent_tokenize, word_tokenize

data =sys.argv[1]

words = word_tokenize(data)

print(words)
