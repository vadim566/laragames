<?php
/**
 * Created by PhpStorm.
 * User: habibih
 * Date: 8/5/2019
 * Time: 02:35 PM
 */


echo shell_exec('2>&1 svn update /export/data/www/issco-site/en/research/projects/LARA-portal/trunk/Code/PHP/img --non-interactive');

?>