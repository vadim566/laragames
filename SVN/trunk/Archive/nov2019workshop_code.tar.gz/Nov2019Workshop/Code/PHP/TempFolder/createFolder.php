<?php
/**
 * Created by PhpStorm.
 * User: habibih
 * Date: 8/7/2019
 * Time: 05:20 PM
 */

require_once '../SharedModules/PdoDataAccess.class.php';
require_once '../Config.php';

if (!file_exists( ImportContentsDirectory ) && !is_dir(ImportContentsDirectory))
{
    //if not, try to create the root directory
    if(! mkdir(ImportContentsDirectory, 0777, true))
    {
        echo "CreateDIRFailed";
    }
    else
    {
       echo "DIRCreated";
    }
}
else
{
    echo "DIRExists";
}
die();


$query = "SELECT DirName FROM `Contents`";
$temp = PdoDataAccess::runquery($query);
for($i = 0 ; $i < count($temp); $i++) {
    $dirAddress = ContentTmpDirectory . $temp[$i][0];
    echo $dirAddress;
    if (!file_exists( $dirAddress ) && !is_dir($dirAddress))
    {
        //if not, try to create the root directory
        if(! mkdir($dirAddress, 0777, true))
        {
            echo "CreateDIRFailed";
        }
        else
        {
          $subDir = $dirAddress . "/compiled/";
            echo $subDir;
            if( !mkdir($subDir, 0777, true))
            {
                echo "CreateSubDIR1Failed";
            }
            $subDir = $dirAddress . "/laraTmpDirectory/";
            echo $subDir;
            if( !mkdir($subDir, 0777, true))
            {
                echo "CreateSubDIR2Failed";
            }

            echo "DIRCreated";
        }
    }
    else
    {
        echo "DIRExists";
    }
echo "***********************";
}
